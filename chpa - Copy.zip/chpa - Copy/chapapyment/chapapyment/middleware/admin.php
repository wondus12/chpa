<?php
/**
 * Admin Authentication Middleware
 * Include this at the top of admin-only pages
 */

require_once __DIR__ . '/../session_config.php';
require_once __DIR__ . '/../config.php';

// Start session
startSecureSession();

// Check if user is authenticated
$currentUserId = $_SESSION['user_id'] ?? null;
$currentUserRole = $_SESSION['user_role'] ?? null;

if (!$currentUserId) {
    // Redirect to login page
    header('Location: /login.php');
    exit;
}

// Check if user is admin
if ($currentUserRole !== 'admin') {
    // Log unauthorized access attempt
    Logger::warning('Unauthorized admin access attempt', [
        'user_id' => $currentUserId,
        'requested_page' => $_SERVER['REQUEST_URI']
    ]);
    
    // Redirect to unauthorized page
    http_response_code(403);
    echo json_encode([
        'success' => false,
        'error' => 'Access denied. Admin privileges required.'
    ]);
    exit;
}
?>
