# Chapa Payment Telegram Bot

This is a Telegram bot implementation for the Chapa payment system that allows users to make deposits and withdrawals through Telegram.

## Setup Instructions

### 1. Create a Telegram Bot

1. Open Telegram and search for @BotFather
2. Start a chat with BotFather
3. Send `/newbot` command
4. Follow the instructions to create a new bot
5. Copy the bot token provided by BotFather

### 2. Configure Environment Variables

Update the `.env` file with your Telegram bot token:

```env
BOT_TOKEN=YOUR_TELEGRAM_BOT_TOKEN_HERE
```

### 3. Database Setup

Make sure MySQL is running and the database is set up:

```sql
CREATE DATABASE IF NOT EXISTS chapa_banking;
```

The bot will automatically create the required tables when it starts.

### 4. Install Dependencies

```bash
npm install
```

### 5. Run the Bot

```bash
node telegram-bot.js
```

## Bot Commands

### User Commands

- `/start` - Start the bot and get welcome message
- `/help` - Show help message with available commands
- `/balance` - Check your current balance
- `/deposit` - Initiate a deposit transaction
- `/withdraw` - Request a withdrawal
- `/transactions` - View recent transactions
- `/cancel` - Cancel current operation

## How It Works

### Deposit Process

1. User sends `/deposit` command
2. Bot asks for deposit amount
3. User enters amount
4. Bot generates a transaction reference
5. Bot creates a transaction record
6. Bot provides a Chapa payment link
7. User completes payment through Chapa
8. Balance is updated automatically

### Withdrawal Process

1. User sends `/withdraw` command
2. Bot checks user balance
3. Bot asks for withdrawal amount
4. User enters amount
5. Bot validates amount against balance
6. Bot creates transaction record
7. Bot updates user balance
8. Withdrawal request is submitted

## Database Tables

### telegram_users

Stores Telegram user information:

```sql
CREATE TABLE telegram_users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  telegram_id BIGINT UNIQUE NOT NULL,
  username VARCHAR(100),
  first_name VARCHAR(100),
  last_name VARCHAR(100),
  balance DECIMAL(10, 2) DEFAULT 0.00,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

### telegram_transactions

Stores transaction records:

```sql
CREATE TABLE telegram_transactions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  telegram_user_id BIGINT NOT NULL,
  transaction_type ENUM('deposit', 'withdrawal') NOT NULL,
  amount DECIMAL(10, 2) NOT NULL,
  status ENUM('pending', 'completed', 'failed', 'cancelled') DEFAULT 'pending',
  tx_ref VARCHAR(100) UNIQUE,
  chapa_tx_ref VARCHAR(100),
  payment_method VARCHAR(50),
  description TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_telegram_user_id (telegram_user_id),
  INDEX idx_tx_ref (tx_ref),
  INDEX idx_status (status)
);
```

## Chapa Integration

The bot uses the Chapa payment gateway for deposits:

- Public Key: `CHAPUBK_TEST-tMMPxq88nzQ8jgNUvDkvcOVi7q56LDXH`
- Secret Key: `CHASECK_TEST-AIE8fYv5RgxoM7T3suc2MhVi0SrXedBf`

## Security Features

- User authentication via Telegram ID
- Transaction reference uniqueness
- Balance validation for withdrawals
- Input validation and sanitization
- Error handling and logging

## Error Handling

The bot includes comprehensive error handling:

- Database connection errors
- Invalid user inputs
- Transaction processing errors
- Network issues
- Graceful shutdown procedures

## Testing

To test the bot:

1. Start the bot with `node telegram-bot.js`
2. Open Telegram and search for your bot
3. Send `/start` to begin
4. Try the various commands

## Troubleshooting

### Common Issues

1. **Bot not responding**: Check if the bot is running and the token is correct
2. **Database errors**: Verify MySQL is running and credentials are correct
3. **Chapa integration issues**: Check API keys in .env file

### Logs

Check the console output for error messages and debugging information.