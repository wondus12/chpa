# How to Run Chapa Banking App - Complete Guide

## Overview
This guide provides multiple methods to run the Chapa Banking App locally without requiring Apache installation.

## Method 1: Using Portable Web Server (Recommended)

### Download Portable XAMPP
1. Download XAMPP Portable from: https://portableapps.com/apps/development/xampp
2. Extract to any folder (e.g., `C:\portable-xampp\`)
3. No installation required - just extract and run

### Setup Steps
1. **Extract XAMPP Portable**
   - Extract to `C:\portable-xampp\` or any preferred location
   
2. **Start Services**
   - Run `xampp-control.exe` from the extracted folder
   - Start Apache and MySQL services
   
3. **Copy Project Files**
   - Copy your entire project folder to `C:\portable-xampp\htdocs\chapa-banking\`
   
4. **Setup Database**
   - Open browser: http://localhost/phpmyadmin
   - Import `database_setup.sql` file
   
5. **Access Application**
   - Open browser: http://localhost/chapa-banking/chapapymentformfile.html

## Method 2: Using Node.js with PHP-CGI

### Prerequisites
1. Install Node.js from: https://nodejs.org/
2. Download PHP (non-thread-safe) from: https://windows.php.net/download/

### Setup Steps
1. **Extract PHP**
   - Extract PHP to `C:\php\`
   - Add `C:\php\` to system PATH
   
2. **Install http-server**
   ```bash
   npm install -g http-server
   ```
   
3. **Create PHP CGI Script**
   Create `server.js` in project root:
   ```javascript
   const http = require('http');
   const fs = require('fs');
   const path = require('path');
   const { spawn } = require('child_process');
   
   const server = http.createServer((req, res) => {
     const filePath = path.join(__dirname, req.url === '/' ? '/chapapymentformfile.html' : req.url);
     
     if (path.extname(filePath) === '.php') {
       // Handle PHP files
       const php = spawn('php', ['-f', filePath]);
       php.stdout.pipe(res);
     } else {
       // Handle static files
       fs.readFile(filePath, (err, data) => {
         if (err) {
           res.writeHead(404);
           res.end('File not found');
         } else {
           res.writeHead(200);
           res.end(data);
         }
       });
     }
   });
   
   server.listen(8000, () => {
     console.log('Server running at http://localhost:8000');
   });
   ```
   
4. **Run Server**
   ```bash
   node server.js
   ```

## Method 3: Using Docker (Advanced)

### Prerequisites
1. Install Docker Desktop from: https://www.docker.com/products/docker-desktop/

### Setup Steps
1. **Create Dockerfile**
   Create `Dockerfile` in project root:
   ```dockerfile
   FROM php:8.0-apache
   
   # Install MySQL extension
   RUN docker-php-ext-install pdo pdo_mysql
   
   # Copy application files
   COPY . /var/www/html/
   
   # Set permissions
   RUN chown -R www-data:www-data /var/www/html/
   RUN chmod -R 755 /var/www/html/
   
   EXPOSE 80
   ```

2. **Create docker-compose.yml**
   ```yaml
   version: '3.8'
   services:
     web:
       build: .
       ports:
         - "8000:80"
       depends_on:
         - db
       volumes:
         - .:/var/www/html
     
     db:
       image: mysql:8.0
       environment:
         MYSQL_ROOT_PASSWORD: root
         MYSQL_DATABASE: chapa_banking
       ports:
         - "3306:3306"
       volumes:
         - ./database_setup.sql:/docker-entrypoint-initdb.d/init.sql
   ```

3. **Run with Docker**
   ```bash
   docker-compose up -d
   ```

## Method 4: Using Online Development Environment

### Replit Setup
1. Go to https://replit.com/
2. Create new PHP project
3. Upload your project files
4. Install MySQL addon
5. Import database schema
6. Run the project

### CodeSandbox Setup
1. Go to https://codesandbox.io/
2. Create new server template
3. Upload project files
4. Configure database connection
5. Run the application

## Method 5: Using Local PHP Installation

### Download PHP
1. Download PHP from: https://windows.php.net/download/
2. Extract to `C:\php\`
3. Add `C:\php\` to system PATH

### Download MySQL
1. Download MySQL Community Server from: https://dev.mysql.com/downloads/mysql/
2. Install MySQL
3. Set root password (or leave empty for development)

### Run Application
1. **Start MySQL**
   ```bash
   net start mysql80
   ```

2. **Import Database**
   ```bash
   mysql -u root -p < database_setup.sql
   ```

3. **Start PHP Server**
   ```bash
   cd "C:\Users\insa\Desktop\projetemp\chpa\chapapyment\chapapyment"
   php -S localhost:8000
   ```

4. **Access Application**
   - Open browser: http://localhost:8000/chapapymentformfile.html

## Configuration Details

### Database Configuration (config.php)
```php
// Already configured for local development
define('DB_HOST', 'localhost');
define('DB_NAME', 'chapa_banking');
define('DB_USER', 'root');
define('DB_PASS', ''); // Empty for XAMPP default
```

### Test Credentials
- **Admin**: admin@example.com / admin123
- **User**: user@example.com / user123

### Test Features
1. **Deposit Simulation**: Use test amounts (100, 500, 1000 ETB)
2. **Withdrawal Requests**: Submit and approve via admin panel
3. **Transaction History**: View with filters and pagination
4. **Balance Updates**: Real-time balance changes

## Troubleshooting

### Common Issues

1. **Database Connection Error**
   - Ensure MySQL is running
   - Check credentials in config.php
   - Verify database exists

2. **PHP Not Found**
   - Install PHP or use portable XAMPP
   - Add PHP to system PATH
   - Use absolute path to PHP executable

3. **Port Already in Use**
   - Change port in config.php (e.g., 8001, 8080)
   - Kill process using the port
   - Use different port number

4. **Permission Errors**
   - Run as administrator
   - Check file permissions
   - Ensure logs directory is writable

### Quick Test Commands

```bash
# Test PHP installation
php --version

# Test MySQL connection
mysql -u root -p -e "SHOW DATABASES;"

# Test web server
curl http://localhost:8000/chapapymentformfile.html
```

## Alternative Solutions

### If All Else Fails
1. **Use Online IDE**: CodePen, JSFiddle, or Replit
2. **Use Virtual Machine**: Install Ubuntu VM with LAMP stack
3. **Use WSL**: Windows Subsystem for Linux with Apache
4. **Use Cloud Hosting**: Deploy to free hosting service

## Support

If you encounter issues:
1. Check the logs in `logs/` directory
2. Verify all prerequisites are installed
3. Ensure ports 8000 and 3306 are available
4. Try alternative methods listed above

The application is fully configured and ready to run once you have a PHP/MySQL environment set up!
