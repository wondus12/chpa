<?php
/**
 * Chapa Payment Verification API
 * Handles server-side payment verification for localhost
 */

// Load configuration
require_once __DIR__ . '/../config.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: ' . DOMAIN_URL);
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

class ChapaVerification {
    
    public function verifyPayment($txRef) {
        $config = getChapaConfig();
        $url = $config['base_url'] . '/transaction/verify/' . $txRef;
        
        $headers = [
            'Authorization: Bearer ' . $config['secret_key'],
            'Content-Type: application/json'
        ];
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        
        if ($error) {
            return [
                'success' => false,
                'error' => 'Network error: ' . $error
            ];
        }
        
        if ($httpCode !== 200) {
            return [
                'success' => false,
                'error' => 'HTTP error: ' . $httpCode
            ];
        }
        
        $data = json_decode($response, true);
        
        if (!$data) {
            return [
                'success' => false,
                'error' => 'Invalid response format'
            ];
        }
        
        // Log the transaction
        $this->logTransaction($txRef, $data);
        
        return [
            'success' => true,
            'status' => $data['status'] ?? 'unknown',
            'data' => $data['data'] ?? null,
            'verified_at' => date('Y-m-d H:i:s')
        ];
    }
    
    public function simulateVerification($txRef) {
        // For testing purposes - simulate Chapa verification
        $success = rand(1, 10) > 1; // 90% success rate
        
        if ($success) {
            $data = [
                'tx_ref' => $txRef,
                'status' => 'success',
                'amount' => rand(100, 5000),
                'currency' => 'ETB',
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ];
            
            $this->logTransaction($txRef, $data);
            
            return [
                'success' => true,
                'status' => 'success',
                'data' => $data,
                'verified_at' => date('Y-m-d H:i:s'),
                'note' => 'Simulated verification for testing'
            ];
        } else {
            return [
                'success' => false,
                'error' => 'Payment verification failed',
                'status' => 'failed'
            ];
        }
    }
    
    private function logTransaction($txRef, $data) {
        $logFile = __DIR__ . '/../logs/transactions.log';
        $logDir = dirname($logFile);
        
        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }
        
        $logEntry = [
            'timestamp' => date('Y-m-d H:i:s'),
            'tx_ref' => $txRef,
            'data' => $data,
            'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown'
        ];
        
        file_put_contents($logFile, json_encode($logEntry) . "\n", FILE_APPEND | LOCK_EX);
    }
}

// Handle the request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input || !isset($input['tx_ref'])) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'error' => 'Transaction reference (tx_ref) is required'
        ]);
        exit;
    }
    
    $txRef = $input['tx_ref'];
    $useSimulation = $input['simulate'] ?? true; // Use simulation by default for testing
    
    $verifier = new ChapaVerification();
    
    if ($useSimulation) {
        $result = $verifier->simulateVerification($txRef);
    } else {
        $result = $verifier->verifyPayment($txRef);
    }
    
    echo json_encode($result);
    
} else {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed. Use POST.'
    ]);
}
?>