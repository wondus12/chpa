<?php
/**
 * Chapa Webhook Handler
 * Processes webhook notifications from Chapa for localhost
 */

// Load configuration
require_once __DIR__ . '/../config.php';

header('Content-Type: application/json');

class ChapaWebhook {
    
    public function handleWebhook() {
        $payload = file_get_contents('php://input');
        $signature = $_SERVER['HTTP_X_CHAPA_SIGNATURE'] ?? '';
        
        // Verify signature
        if (!$this->verifySignature($payload, $signature)) {
            http_response_code(401);
            return [
                'success' => false,
                'error' => 'Invalid signature'
            ];
        }
        
        $data = json_decode($payload, true);
        
        if (!$data) {
            http_response_code(400);
            return [
                'success' => false,
                'error' => 'Invalid JSON payload'
            ];
        }
        
        // Process the webhook
        $result = $this->processWebhookData($data);
        
        // Log the webhook
        $this->logWebhook($payload, $signature, $result);
        
        return $result;
    }
    
    private function verifySignature($payload, $signature) {
        $config = getChapaConfig();
        $expectedSignature = hash_hmac('sha256', $payload, $config['secret_hash']);
        return hash_equals($expectedSignature, $signature);
    }
    
    private function processWebhookData($data) {
        $event = $data['event'] ?? 'unknown';
        $txRef = $data['data']['tx_ref'] ?? null;
        
        switch ($event) {
            case 'payment.success':
                return $this->handlePaymentSuccess($data['data']);
                
            case 'payment.failed':
                return $this->handlePaymentFailed($data['data']);
                
            case 'payment.pending':
                return $this->handlePaymentPending($data['data']);
                
            default:
                return [
                    'success' => true,
                    'message' => 'Event received but not processed: ' . $event
                ];
        }
    }
    
    private function handlePaymentSuccess($paymentData) {
        $txRef = $paymentData['tx_ref'];
        $amount = $paymentData['amount'];
        
        // Update database - add your database logic here
        // $this->updatePaymentStatus($txRef, 'completed', $paymentData);
        
        // Send notification to user
        // $this->notifyUser($paymentData['customer']['email'], 'Payment successful');
        
        return [
            'success' => true,
            'message' => 'Payment success processed',
            'tx_ref' => $txRef
        ];
    }
    
    private function handlePaymentFailed($paymentData) {
        $txRef = $paymentData['tx_ref'];
        
        // Update database
        // $this->updatePaymentStatus($txRef, 'failed', $paymentData);
        
        return [
            'success' => true,
            'message' => 'Payment failure processed',
            'tx_ref' => $txRef
        ];
    }
    
    private function handlePaymentPending($paymentData) {
        $txRef = $paymentData['tx_ref'];
        
        // Update database
        // $this->updatePaymentStatus($txRef, 'pending', $paymentData);
        
        return [
            'success' => true,
            'message' => 'Payment pending processed',
            'tx_ref' => $txRef
        ];
    }
    
    private function logWebhook($payload, $signature, $result) {
        $logFile = __DIR__ . '/../logs/webhooks.log';
        $logDir = dirname($logFile);
        
        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }
        
        $logEntry = [
            'timestamp' => date('Y-m-d H:i:s'),
            'payload' => $payload,
            'signature' => $signature,
            'result' => $result,
            'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown'
        ];
        
        file_put_contents($logFile, json_encode($logEntry) . "\n", FILE_APPEND | LOCK_EX);
    }
}

// Handle the webhook
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $webhook = new ChapaWebhook();
    $result = $webhook->handleWebhook();
    echo json_encode($result);
} else {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed. Use POST.'
    ]);
}
?>