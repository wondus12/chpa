<?php
/**
 * Chapa Approval URL Endpoint
 * Verifies the authenticity of transfer details before processing
 * 
 * When a payment is initiated, Chapa sends payment information along with 
 * a hash generated using the approval_secret to this endpoint.
 * 
 * Response codes:
 * - 200 OK: Transfer approved (status: pending)
 * - 400 Bad Request: Transfer rejected (status: reverted)
 */

// Load configuration
require_once __DIR__ . '/../config.php';

header('Content-Type: application/json');

class ChapaApproval {
    
    public function handleApprovalRequest() {
        // Get the raw POST data
        $payload = file_get_contents('php://input');
        $signature = $_SERVER['HTTP_CHAPA_SIGNATURE'] ?? '';
        
        // Log the approval request
        $this->logApprovalRequest($payload, $signature);
        
        // Verify the signature
        if (!$this->verifyApprovalSignature($payload, $signature)) {
            http_response_code(400);
            return [
                'success' => false,
                'error' => 'Invalid signature - transfer rejected',
                'status' => 'reverted'
            ];
        }
        
        // Parse the payment data
        $paymentData = json_decode($payload, true);
        
        if (!$paymentData) {
            http_response_code(400);
            return [
                'success' => false,
                'error' => 'Invalid JSON payload - transfer rejected',
                'status' => 'reverted'
            ];
        }
        
        // Validate the transfer details
        $validation = $this->validateTransferDetails($paymentData);
        
        if (!$validation['valid']) {
            http_response_code(400);
            return [
                'success' => false,
                'error' => $validation['error'],
                'status' => 'reverted'
            ];
        }
        
        // Approve the transfer
        http_response_code(200);
        return [
            'success' => true,
            'message' => 'Transfer approved',
            'status' => 'pending',
            'tx_ref' => $paymentData['tx_ref'] ?? null
        ];
    }
    
    private function verifyApprovalSignature($payload, $signature) {
        if (empty($signature)) {
            return false;
        }
        
        $config = getChapaConfig();
        $approvalSecret = $config['approval_secret'] ?? $config['secret_hash'];
        
        // Generate expected signature using HMAC SHA256
        $expectedSignature = hash_hmac('sha256', $payload, $approvalSecret);
        
        // Compare signatures securely
        return hash_equals($expectedSignature, $signature);
    }
    
    private function validateTransferDetails($paymentData) {
        // Extract payment details
        $amount = $paymentData['amount'] ?? 0;
        $currency = $paymentData['currency'] ?? '';
        $txRef = $paymentData['tx_ref'] ?? '';
        $email = $paymentData['email'] ?? '';
        
        // Validate required fields
        if (empty($txRef)) {
            return [
                'valid' => false,
                'error' => 'Missing transaction reference'
            ];
        }
        
        if (empty($email)) {
            return [
                'valid' => false,
                'error' => 'Missing customer email'
            ];
        }
        
        // Validate amount
        if (!is_numeric($amount) || $amount <= 0) {
            return [
                'valid' => false,
                'error' => 'Invalid amount'
            ];
        }
        
        // Check amount limits
        if ($amount < MIN_DEPOSIT_AMOUNT || $amount > MAX_DEPOSIT_AMOUNT) {
            return [
                'valid' => false,
                'error' => 'Amount outside allowed limits'
            ];
        }
        
        // Validate currency
        if ($currency !== 'ETB') {
            return [
                'valid' => false,
                'error' => 'Invalid currency - only ETB supported'
            ];
        }
        
        // Check for duplicate transactions
        if ($this->isDuplicateTransaction($txRef)) {
            return [
                'valid' => false,
                'error' => 'Duplicate transaction reference'
            ];
        }
        
        // Fraud detection checks
        $fraudCheck = $this->performFraudChecks($paymentData);
        if (!$fraudCheck['passed']) {
            return [
                'valid' => false,
                'error' => 'Transaction flagged by fraud detection: ' . $fraudCheck['reason']
            ];
        }
        
        // All validations passed
        return [
            'valid' => true,
            'message' => 'Transfer details validated successfully'
        ];
    }
    
    private function isDuplicateTransaction($txRef) {
        // Check if transaction reference already exists
        $logFile = __DIR__ . '/../logs/approved_transactions.log';
        
        if (!file_exists($logFile)) {
            return false;
        }
        
        $logs = file($logFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        
        foreach ($logs as $log) {
            $entry = json_decode($log, true);
            if ($entry && isset($entry['tx_ref']) && $entry['tx_ref'] === $txRef) {
                return true;
            }
        }
        
        return false;
    }
    
    private function performFraudChecks($paymentData) {
        $amount = $paymentData['amount'] ?? 0;
        $email = $paymentData['email'] ?? '';
        $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        
        // Check for suspicious amounts
        if ($amount > 50000) {
            return [
                'passed' => false,
                'reason' => 'Amount exceeds fraud threshold'
            ];
        }
        
        // Check for rapid successive transactions from same IP
        $recentTransactions = $this->getRecentTransactionsByIP($ip);
        if (count($recentTransactions) > 5) {
            return [
                'passed' => false,
                'reason' => 'Too many transactions from same IP'
            ];
        }
        
        // Check for suspicious email patterns
        if (strpos($email, 'test') !== false && IS_PRODUCTION) {
            return [
                'passed' => false,
                'reason' => 'Test email in production environment'
            ];
        }
        
        // All fraud checks passed
        return [
            'passed' => true,
            'reason' => 'No fraud indicators detected'
        ];
    }
    
    private function getRecentTransactionsByIP($ip) {
        $logFile = __DIR__ . '/../logs/approval_requests.log';
        
        if (!file_exists($logFile)) {
            return [];
        }
        
        $recentTransactions = [];
        $cutoffTime = time() - 3600; // Last hour
        
        $logs = file($logFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        
        foreach ($logs as $log) {
            $entry = json_decode($log, true);
            if ($entry && 
                isset($entry['ip']) && 
                $entry['ip'] === $ip && 
                isset($entry['timestamp']) && 
                strtotime($entry['timestamp']) > $cutoffTime) {
                $recentTransactions[] = $entry;
            }
        }
        
        return $recentTransactions;
    }
    
    private function logApprovalRequest($payload, $signature) {
        $logFile = __DIR__ . '/../logs/approval_requests.log';
        $logDir = dirname($logFile);
        
        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }
        
        $logEntry = [
            'timestamp' => date('Y-m-d H:i:s'),
            'payload' => $payload,
            'signature' => $signature,
            'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown'
        ];
        
        file_put_contents($logFile, json_encode($logEntry) . "\n", FILE_APPEND | LOCK_EX);
    }
    
    private function logApprovedTransaction($txRef, $paymentData) {
        $logFile = __DIR__ . '/../logs/approved_transactions.log';
        $logDir = dirname($logFile);
        
        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }
        
        $logEntry = [
            'timestamp' => date('Y-m-d H:i:s'),
            'tx_ref' => $txRef,
            'amount' => $paymentData['amount'] ?? 0,
            'currency' => $paymentData['currency'] ?? 'ETB',
            'email' => $paymentData['email'] ?? '',
            'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown'
        ];
        
        file_put_contents($logFile, json_encode($logEntry) . "\n", FILE_APPEND | LOCK_EX);
    }
}

// Handle the approval request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $approval = new ChapaApproval();
    $result = $approval->handleApprovalRequest();
    
    // Log approved transactions
    if ($result['success'] ?? false) {
        $paymentData = json_decode(file_get_contents('php://input'), true);
        if ($paymentData && isset($paymentData['tx_ref'])) {
            $approval->logApprovedTransaction($paymentData['tx_ref'], $paymentData);
        }
    }
    
    echo json_encode($result);
    
} else {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed. Use POST.',
        'status' => 'reverted'
    ]);
}
?>