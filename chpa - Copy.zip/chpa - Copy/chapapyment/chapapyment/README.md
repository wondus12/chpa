# Chapa Payment Telegram Bot

A complete Telegram bot implementation for Chapa payment integration with deposit and withdrawal functionality.

## Features

- ✅ Deposit via Chapa payment gateway
- ✅ Withdrawal requests
- ✅ Balance management
- ✅ Transaction history
- ✅ SQLite database storage
- ✅ Telegram bot interface

## Setup Instructions

### 1. Prerequisites

- Node.js installed
- Telegram account

### 2. Installation

```bash
# Install dependencies
npm install telegraf sqlite3 sqlite dotenv
```

### 3. Configuration

Update the `.env` file with your credentials:

```env
BOT_TOKEN=1907768592:AAEDDWdiLFkVW6Ye8cXCoskg1V2BQy0H_tw
CHAPA_PUBLIC_KEY=CHAPUBK_TEST-tMMPxq88nzQ8jgNUvDkvcOVi7q56LDXH
CHAPA_SECRET_KEY=CHASECK_TEST-AIE8fYv5RgxoM7T3suc2MhVi0SrXedBf
```

### 4. Initialize Database

```bash
# Create database tables
node init-telegram-db.js
```

### 5. Run the Bot

```bash
# Start the bot
npm run bot
```

## Bot Commands

- `/start` - Start the bot
- `/help` - Show help message
- `/balance` - Check balance
- `/deposit` - Make a deposit
- `/withdraw` - Request withdrawal
- `/transactions` - View transactions
- `/cancel` - Cancel current operation

## Database Structure

### telegram_users Table

```sql
CREATE TABLE telegram_users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  telegram_id INTEGER UNIQUE NOT NULL,
  username TEXT,
  first_name TEXT,
  last_name TEXT,
  balance DECIMAL(10, 2) DEFAULT 0.00,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

### telegram_transactions Table

```sql
CREATE TABLE telegram_transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  telegram_user_id INTEGER NOT NULL,
  transaction_type TEXT NOT NULL,
  amount DECIMAL(10, 2) NOT NULL,
  status TEXT DEFAULT 'pending',
  tx_ref TEXT UNIQUE,
  chapa_tx_ref TEXT,
  payment_method TEXT,
  description TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

## How It Works

### Deposit Process
1. User sends `/deposit`
2. Bot asks for amount
3. User enters amount
4. Bot generates transaction reference
5. Bot creates transaction record
6. Bot provides Chapa payment link
7. User completes payment
8. Balance updates automatically

### Withdrawal Process
1. User sends `/withdraw`
2. Bot checks balance
3. Bot asks for amount
4. User enters amount
5. Bot validates amount
6. Bot creates transaction record
7. Bot updates balance
8. Withdrawal request submitted

## Testing

```bash
# Test database initialization
node init-telegram-db.js

# Test database functionality
node test-bot.js

# Run the bot
npm run bot
```

## Security

- Environment-based configuration (never commit .env)
- Input validation
- Session management
- Error handling

## License

MIT