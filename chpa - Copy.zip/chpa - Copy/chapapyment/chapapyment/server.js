const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');

// Simple .env parser
function loadEnv() {
  try {
    const envContent = fs.readFileSync(path.join(__dirname, '.env'), 'utf8');
    const envVars = {};
    envContent.split('\n').forEach(line => {
      if (line.trim() && !line.startsWith('#')) {
        const [key, value] = line.split('=');
        if (key && value) {
          envVars[key.trim()] = value.trim().replace(/['"]/g, '');
        }
      }
    });
    return envVars;
  } catch (err) {
    console.log('No .env file found or error reading it');
    return {};
  }
}

const envVars = loadEnv();
const PORT = envVars.PORT || process.env.PORT || 8000;
const CHAPA_PUBLIC_KEY = envVars.CHAPA_PUBLIC_KEY || 'CHAPUBK_TEST-xxxxxxxxxxxxxxxxxxxx';

const server = http.createServer((req, res) => {
  const parsedUrl = url.parse(req.url, true);
  const pathname = parsedUrl.pathname;
  
  // Handle API endpoints
  if (pathname.startsWith('/chapapyment/api/') || pathname.startsWith('/api/')) {
    handleApiRequest(req, res, pathname, parsedUrl.query);
    return;
  }
  
  // Serve static files
  let filePath = path.join(__dirname, pathname);
  
  // Default to chapapymentformfile.html for root path
  if (pathname === '/' || pathname === '/chapapymentformfile.html') {
    filePath = path.join(__dirname, 'chapapymentformfile.html');
  }
  
  // Determine content type based on file extension
  const extname = path.extname(filePath);
  let contentType = 'text/html';
  
  switch (extname) {
    case '.js':
      contentType = 'text/javascript';
      break;
    case '.css':
      contentType = 'text/css';
      break;
    case '.json':
      contentType = 'application/json';
      break;
    case '.png':
      contentType = 'image/png';
      break;
    case '.jpg':
      contentType = 'image/jpg';
      break;
  }
  
  fs.readFile(filePath, (err, data) => {
    if (err) {
      // File not found, serve the main HTML file
      fs.readFile(path.join(__dirname, 'chapapymentformfile.html'), (err, data) => {
        if (err) {
          res.writeHead(404);
          res.end('File not found');
        } else {
          // For HTML files, inject the Chapa public key
          if (contentType === 'text/html') {
            let htmlContent = data.toString();
            // Replace placeholder with actual Chapa public key
            htmlContent = htmlContent.replace(
              'CHAPUBK_TEST-v8gO0BwmSBFgAUpaMktUcwfm3YDCzA',
              CHAPA_PUBLIC_KEY
            );
            res.writeHead(200, { 'Content-Type': 'text/html' });
            res.end(htmlContent);
          } else {
            res.writeHead(200, { 'Content-Type': contentType });
            res.end(data);
          }
        }
      });
    } else {
      // For HTML files, inject the Chapa public key
      if (contentType === 'text/html') {
        let htmlContent = data.toString();
        // Replace placeholder with actual Chapa public key
        htmlContent = htmlContent.replace(
          'CHAPUBK_TEST-v8gO0BwmSBFgAUpaMktUcwfm3YDCzA',
          CHAPA_PUBLIC_KEY
        );
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end(htmlContent);
      } else {
        res.writeHead(200, { 'Content-Type': contentType });
        res.end(data);
      }
    }
  });
});

function handleApiRequest(req, res, pathname, query) {
  // Remove /chapapyment prefix if present
  const cleanPath = pathname.replace('/chapapyment', '');
  
  // Simulate API responses for testing
  if (cleanPath === '/api/webhook.php') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ status: 'success', message: 'Webhook received' }));
  } else if (cleanPath === '/api/verify-payment.php') {
    let body = '';
    req.on('data', chunk => {
      body += chunk.toString();
    });
    req.on('end', () => {
      try {
        const requestData = JSON.parse(body);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ 
          status: 'success', 
          message: 'Payment verified',
          data: { 
            amount: requestData.amount || 1000, 
            tx_ref: requestData.tx_ref || 'tx-demo-' + Date.now()
          }
        }));
      } catch (e) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ 
          status: 'error', 
          message: 'Invalid request data'
        }));
      }
    });
  } else {
    res.writeHead(404, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ status: 'error', message: 'API endpoint not found' }));
  }
}

server.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
  console.log('Chapa Public Key loaded:', CHAPA_PUBLIC_KEY.substring(0, 15) + '...');
  console.log('Note: This is a simplified server for demonstration purposes.');
  console.log('For full functionality, please install PHP and use a proper web server.');
});