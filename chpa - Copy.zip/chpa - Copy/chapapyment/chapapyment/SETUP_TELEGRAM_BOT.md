# Complete Setup Guide for Chapa Payment Telegram Bot

This guide will walk you through setting up the Chapa Payment Telegram Bot with deposit and withdrawal functionality.

## Prerequisites

1. Node.js installed
2. Telegram account

## Step-by-Step Setup

### 1. Install Dependencies

```bash
# Install required packages
npm install telegraf sqlite3 sqlite dotenv
```

### 2. Create Telegram Bot

1. Open Telegram
2. Search for @BotFather
3. Start a chat with BotFather
4. Send `/newbot` command
5. Follow instructions to create your bot
6. Copy the bot token when provided

### 3. Configure Environment Variables

Update the `.env` file with your credentials:

```env
# Chapa API Credentials (Test)
CHAPA_PUBLIC_KEY=CHAPUBK_TEST-tMMPxq88nzQ8jgNUvDkvcOVi7q56LDXH
CHAPA_SECRET_KEY=CHASECK_TEST-AIE8fYv5RgxoM7T3suc2MhVi0SrXedBf

# Telegram Bot Token (Get from @BotFather)
BOT_TOKEN=YOUR_TELEGRAM_BOT_TOKEN_HERE
```

### 4. Initialize Database

```bash
# Run database initialization script
node init-telegram-db.js
```

This will create an SQLite database file `chapa_telegram.db` with the required tables:
- `telegram_users` - Stores Telegram user information
- `telegram_transactions` - Stores transaction records

### 5. Database Table Structure

#### telegram_users Table

```sql
CREATE TABLE telegram_users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  telegram_id INTEGER UNIQUE NOT NULL,
  username TEXT,
  first_name TEXT,
  last_name TEXT,
  balance DECIMAL(10, 2) DEFAULT 0.00,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

#### telegram_transactions Table

```sql
CREATE TABLE telegram_transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  telegram_user_id INTEGER NOT NULL,
  transaction_type TEXT NOT NULL,
  amount DECIMAL(10, 2) NOT NULL,
  status TEXT DEFAULT 'pending',
  tx_ref TEXT UNIQUE,
  chapa_tx_ref TEXT,
  payment_method TEXT,
  description TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

### 6. Run the Bot

```bash
# Start the Telegram bot
npm run bot
```

Or directly:

```bash
node telegram-bot.js
```

## Bot Commands

### User Commands

```bash
# Start the bot
/start

# Show help
/help

# Check balance
/balance

# Make a deposit
/deposit

# Request withdrawal
/withdraw

# View transactions
/transactions

# Cancel current operation
/cancel
```

### Deposit Process

1. User sends `/deposit`
2. Bot asks for amount
3. User enters amount (e.g., `1000`)
4. Bot generates transaction reference
5. Bot creates transaction record
6. Bot provides Chapa payment link
7. User completes payment
8. Balance updates automatically

### Withdrawal Process

1. User sends `/withdraw`
2. Bot checks balance
3. Bot asks for amount
4. User enters amount (e.g., `500`)
5. Bot validates amount
6. Bot creates transaction record
7. Bot updates balance
8. Withdrawal request submitted

## Testing the Bot

### Manual Database Testing

You can verify the database tables were created correctly:

```bash
# Check if database file exists
ls -la chapa_telegram.db

# Use sqlite3 to inspect database
sqlite3 chapa_telegram.db

# In SQLite prompt:
.tables
.schema telegram_users
.schema telegram_transactions
.quit
```

### Bot Testing Commands

```bash
# Start the bot
npm run bot

# In Telegram:
/start
/help
/balance
/deposit
/withdraw
/transactions
/cancel
```

## Chapa Payment Integration

The bot integrates with Chapa payment gateway:

- Public Key: `CHAPUBK_TEST-tMMPxq88nzQ8jgNUvDkvcOVi7q56LDXH`
- Secret Key: `CHASECK_TEST-AIE8fYv5RgxoM7T3suc2MhVi0SrXedBf`

Payment flow:
1. Bot generates transaction reference
2. Bot creates Chapa payment link
3. User completes payment on Chapa
4. Chapa sends webhook to your server
5. Server updates transaction status
6. User balance is updated

## Security Considerations

1. Never commit `.env` file to version control
2. Use strong database credentials
3. Validate all user inputs
4. Implement rate limiting
5. Log all transactions
6. Secure webhook endpoints

## Troubleshooting

### Common Issues

1. **Bot not responding**
   ```bash
   # Check if bot is running
   ps aux | grep node
   
   # Check bot logs
   node telegram-bot.js
   ```

2. **Database connection errors**
   ```bash
   # Check if database file exists
   ls -la chapa_telegram.db
   
   # Check file permissions
   ls -l chapa_telegram.db
   ```

3. **Missing dependencies**
   ```bash
   # Reinstall dependencies
   npm install
   ```

### Database Verification

```bash
# Connect to SQLite database
sqlite3 chapa_telegram.db

# Check tables
.tables

# Verify telegram_users table
.schema telegram_users

# Verify telegram_transactions table
.schema telegram_transactions

# Check for data
SELECT * FROM telegram_users LIMIT 5;
SELECT * FROM telegram_transactions LIMIT 5;

# Exit SQLite
.quit
```

## Advanced Configuration

### Environment Variables

All configurable options:

```env
# Required
BOT_TOKEN=your_telegram_bot_token
CHAPA_PUBLIC_KEY=your_chapa_public_key
CHAPA_SECRET_KEY=your_chapa_secret_key

# Optional
NODE_ENV=production
LOG_LEVEL=info
```

### Customization Options

1. Modify deposit/withdrawal limits in `telegram-bot.js`
2. Add new commands in the bot implementation
3. Customize transaction status handling
4. Add admin commands for transaction management

## Monitoring and Maintenance

### Log Monitoring

```bash
# Check bot logs
tail -f bot.log
```

### Database Maintenance

```bash
# Check database size
ls -la chapa_telegram.db

# Backup database
cp chapa_telegram.db chapa_telegram_backup.db

# Check database integrity
sqlite3 chapa_telegram.db "PRAGMA integrity_check;"
```

## Backup and Recovery

### Database Backup

```bash
# Backup database
cp chapa_telegram.db chapa_telegram_backup_$(date +%Y%m%d).db

# Restore database
cp chapa_telegram_backup_$(date +%Y%m%d).db chapa_telegram.db
```

### Configuration Backup

```bash
# Backup environment file
cp .env .env.backup

# Restore environment file
cp .env.backup .env
```

## Support

For issues with the setup:

1. Check the console output for error messages
2. Verify all environment variables are set correctly
3. Ensure Telegram bot token is valid
4. Check Chapa API keys are correct

For additional help, refer to:
- [Telegraf Documentation](https://telegraf.js.org/)
- [Chapa API Documentation](https://developer.chapa.co/)
- [SQLite Documentation](https://www.sqlite.org/docs.html)