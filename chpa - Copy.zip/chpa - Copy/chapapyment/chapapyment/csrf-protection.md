# CSRF Protection Implementation

## Security Implementation

### CSRF Token Generation and Validation (security/csrf.php)
```php
<?php
/**
 * CSRF Protection Implementation
 * Provides functions for generating and validating CSRF tokens
 */

require_once __DIR__ . '/../session_config.php';

/**
 * Generate a CSRF token
 */
function generateCSRFToken() {
    // Start session if not already started
    startSecureSession();
    
    // Generate token if it doesn't exist or if forced regeneration is requested
    if (!isset($_SESSION['csrf_token']) || isset($_GET['regenerate_csrf'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    
    return $_SESSION['csrf_token'];
}

/**
 * Validate a CSRF token
 */
function validateCSRFToken($token) {
    // Start session if not already started
    startSecureSession();
    
    // Check if token exists in session
    if (!isset($_SESSION['csrf_token'])) {
        return false;
    }
    
    // Validate token using hash_equals for timing attack protection
    return hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Generate hidden input field with CSRF token for forms
 */
function csrfField() {
    $token = generateCSRFToken();
    return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars($token) . '">';
}

/**
 * Middleware function to validate CSRF token for POST requests
 */
function validateCSRFMiddleware() {
    // Only validate POST requests
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        return true;
    }
    
    // Get token from request
    $token = $_POST['csrf_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    
    // Validate token
    if (!validateCSRFToken($token)) {
        // Log CSRF attempt
        Logger::security('CSRF token validation failed', [
            'ip' => $_SERVER['REMOTE_ADDR'],
            'user_agent' => $_SERVER['HTTP_USER_AGENT'],
            'request_uri' => $_SERVER['REQUEST_URI']
        ]);
        
        return false;
    }
    
    return true;
}

/**
 * Generate CSRF token for AJAX requests
 */
function getCSRFTokenForAjax() {
    return generateCSRFToken();
}
?>
```

### Updated Session Configuration with CSRF Support (session_config.php)
```php
<?php
/**
 * Updated Session Configuration with CSRF Support
 */

// Start a secure session
function startSecureSession() {
    // Check if session is already started
    if (session_status() === PHP_SESSION_NONE) {
        // Set session cookie parameters for security
        session_set_cookie_params([
            'lifetime' => 3600, // 1 hour
            'path' => '/',
            'domain' => '', // Current domain
            'secure' => isset($_SERVER['HTTPS']), // Only over HTTPS if available
            'httponly' => true, // Prevent JavaScript access
            'samesite' => 'Strict' // CSRF protection
        ]);
        
        // Start session
        session_start();
        
        // Regenerate session ID periodically to prevent session fixation
        if (!isset($_SESSION['last_regeneration'])) {
            $_SESSION['last_regeneration'] = time();
        }
        
        if (time() - $_SESSION['last_regeneration'] > 300) { // Every 5 minutes
            session_regenerate_id(true);
            $_SESSION['last_regeneration'] = time();
        }
    }
}

// Destroy session securely
function destroySession() {
    // Unset all session variables
    $_SESSION = [];
    
    // Delete session cookie
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    
    // Destroy session
    session_destroy();
}
?>
```

### Updated API Endpoints with CSRF Protection

#### Verify Payment API with CSRF Protection (api/verify-payment.php)
```php
<?php
/**
 * Updated Chapa Payment Verification API with CSRF Protection
 */

require_once __DIR__ . '/../session_config.php';
require_once __DIR__ . '/../security/csrf.php';
require_once __DIR__ . '/../config.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: ' . DOMAIN_URL);
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-CSRF-Token');
header('Access-Control-Allow-Credentials: true');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// Validate CSRF token for POST requests
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !validateCSRFMiddleware()) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => 'Invalid CSRF token'
    ]);
    exit;
}

class ChapaVerification {
    // ... existing code ...
}

// Handle the request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // ... existing implementation ...
} else {
    // ... existing implementation ...
}
?>
```

#### Webhook API with Enhanced Security (api/webhook.php)
```php
<?php
/**
 * Updated Chapa Webhook Handler with Enhanced Security
 */

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../security/csrf.php'; // Not needed for webhooks, but included for consistency

header('Content-Type: application/json');

class ChapaWebhook {
    // ... existing code ...
    
    private function verifySignature($payload, $signature) {
        $config = getChapaConfig();
        
        // Enhanced signature verification with timing attack protection
        $expectedSignature = hash_hmac('sha256', $payload, $config['secret_hash']);
        return hash_equals($expectedSignature, $signature);
    }
    
    // ... existing code ...
}

// Handle the webhook (no CSRF validation needed for webhooks)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // ... existing implementation ...
} else {
    // ... existing implementation ...
}
?>
```

#### Withdrawal API with CSRF Protection (api/withdraw.php)
```php
<?php
/**
 * Withdrawal API with CSRF Protection
 */

require_once __DIR__ . '/../session_config.php';
require_once __DIR__ . '/../security/csrf.php';
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../models/Transaction.php';
require_once __DIR__ . '/../models/WithdrawalRequest.php';
require_once __DIR__ . '/../security/FraudDetector.php';

header('Content-Type: application/json');

// Validate CSRF token
if (!validateCSRFMiddleware()) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => 'Invalid CSRF token'
    ]);
    exit;
}

// Validate user authentication
$user_id = $_SESSION['user_id'] ?? null;
if (!$user_id) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'error' => 'User not authenticated'
    ]);
    exit;
}

// Get request data
$input = json_decode(file_get_contents('php://input'), true);
$amount = floatval($input['amount'] ?? 0);
$accountDetails = $input['account_details'] ?? '';
$paymentMethod = $input['payment_method'] ?? 'bank_transfer';

if ($amount <= 0 || empty($accountDetails)) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => 'Amount and account details are required'
    ]);
    exit;
}

// Initialize database connection
$database = new Database();
$db = $database->getConnection();

// Validate withdrawal amount
$user = new User($db);
$userData = $user->getUserById($user_id);

if (!$userData) {
    http_response_code(404);
    echo json_encode([
        'success' => false,
        'error' => 'User not found'
    ]);
    exit;
}

if ($amount > $userData['balance']) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => 'Insufficient balance'
    ]);
    exit;
}

// Perform fraud checks
$fraudDetector = new FraudDetector($db);
$fraudCheck = $fraudDetector->checkTransaction($user_id, $amount, 'withdrawal', $_SERVER['REMOTE_ADDR']);

if (!$fraudCheck['passed']) {
    http_response_code(403);
    echo json_encode([
        'success' => false,
        'error' => 'Transaction flagged by fraud detection',
        'fraud_level' => $fraudCheck['fraud_level'],
        'warnings' => $fraudCheck['warnings']
    ]);
    exit;
}

// Create withdrawal request
$withdrawalRequest = new WithdrawalRequest($db);
$requestCreated = $withdrawalRequest->createRequest($user_id, $amount, $accountDetails, $paymentMethod);

if ($requestCreated) {
    // Deduct amount from user balance
    $user->updateBalance($user_id, $amount, 'subtract');
    
    echo json_encode([
        'success' => true,
        'message' => 'Withdrawal request submitted successfully',
        'request_id' => $requestCreated
    ]);
} else {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Failed to submit withdrawal request'
    ]);
}
?>
```

## Frontend Implementation

### Updated JavaScript with CSRF Token Handling
```javascript
// CSRF Protection for Frontend Requests
class CSRFProtection {
    constructor() {
        this.token = null;
    }
    
    // Get CSRF token from server
    async getCSRFToken() {
        try {
            const response = await fetch('/api/csrf-token.php');
            const result = await response.json();
            
            if (result.success && result.token) {
                this.token = result.token;
                return this.token;
            } else {
                throw new Error('Failed to get CSRF token');
            }
        } catch (error) {
            console.error('Error getting CSRF token:', error);
            // Generate a fallback token (in production, always get from server)
            this.token = this.generateFallbackToken();
            return this.token;
        }
    }
    
    // Generate fallback token (for development only)
    generateFallbackToken() {
        return 'fallback_csrf_token_' + Date.now();
    }
    
    // Add CSRF token to fetch request headers
    addCSRFHeader(headers = {}) {
        if (this.token) {
            headers['X-CSRF-Token'] = this.token;
        }
        return headers;
    }
    
    // Add CSRF token to form data
    addCSRFToFormData(formData) {
        if (this.token) {
            formData.append('csrf_token', this.token);
        }
        return formData;
    }
}

// Initialize CSRF protection
const csrfProtection = new CSRFProtection();

// Get CSRF token when page loads
document.addEventListener('DOMContentLoaded', async function() {
    await csrfProtection.getCSRFToken();
});
```

### CSRF Token API Endpoint (api/csrf-token.php)
```php
<?php
/**
 * CSRF Token API Endpoint
 * Provides CSRF tokens for frontend requests
 */

require_once __DIR__ . '/../session_config.php';
require_once __DIR__ . '/../security/csrf.php';

header('Content-Type: application/json');

// Generate CSRF token
$token = generateCSRFToken();

echo json_encode([
    'success' => true,
    'token' => $token
]);
?>
```

### Updated Transaction Processing with CSRF Protection
```javascript
// Updated transaction processing with CSRF protection

// In your deposit processing function
async function initiateDeposit() {
    // Ensure we have a CSRF token
    if (!csrfProtection.token) {
        await csrfProtection.getCSRFToken();
    }
    
    // ... existing deposit code ...
    
    try {
        // Process the deposit with CSRF token
        const response = await fetch(CHAPA_CONFIG.baseUrl + 'verify-payment.php', {
            method: 'POST',
            headers: csrfProtection.addCSRFHeader({
                'Content-Type': 'application/json',
            }),
            body: JSON.stringify({
                tx_ref: txRef,
                payment_type: 'deposit'
            })
        });
        
        const result = await response.json();
        
        if (result.status === 'success') {
            showPaymentMessage('deposit-success-message', 'Deposit successful!', 'success');
        } else {
            showPaymentMessage('deposit-error-message', 'Deposit failed. Please try again.', 'error');
        }
    } catch (error) {
        console.error('Error processing deposit:', error);
        showPaymentMessage('deposit-error-message', 'Unable to process deposit. Please try again.', 'error');
    }
}

// In your withdrawal processing function
async function processWithdrawal(amount, accountDetails) {
    // Ensure we have a CSRF token
    if (!csrfProtection.token) {
        await csrfProtection.getCSRFToken();
    }
    
    try {
        const response = await fetch(CHAPA_CONFIG.baseUrl + 'withdraw.php', {
            method: 'POST',
            headers: csrfProtection.addCSRFHeader({
                'Content-Type': 'application/json',
            }),
            body: JSON.stringify({
                amount: amount,
                account_details: accountDetails,
                payment_method: 'bank_transfer'
            })
        });
        
        const result = await response.json();
        
        if (response.ok && result.success) {
            showPaymentMessage('withdraw-success-message', result.message, 'success');
        } else {
            showPaymentMessage('withdraw-error-message', result.error || 'Withdrawal failed', 'error');
        }
    } catch (error) {
        console.error('Error processing withdrawal:', error);
        showPaymentMessage('withdraw-error-message', 'Unable to process withdrawal. Please try again.', 'error');
    }
}
```

### Updated HTML Forms with CSRF Tokens
```html
<!-- Add CSRF token to all forms -->
<form id="withdrawal-form" method="POST" action="/api/withdraw.php">
    <!-- Generate CSRF token field -->
    <?php echo csrfField(); ?>
    
    <div class="form-group">
        <label for="withdrawal-amount">Amount (ETB)</label>
        <input type="number" class="form-control" id="withdrawal-amount" name="amount" required>
    </div>
    
    <div class="form-group">
        <label for="account-details">Account Details</label>
        <input type="text" class="form-control" id="account-details" name="account_details" required>
    </div>
    
    <div class="form-group">
        <label for="payment-method">Payment Method</label>
        <select class="form-control" id="payment-method" name="payment_method">
            <option value="bank_transfer">Bank Transfer</option>
            <option value="mobile_money">Mobile Money</option>
        </select>
    </div>
    
    <button type="submit" class="btn btn-primary">Submit Withdrawal Request</button>
</form>

<!-- For AJAX forms, include the token in a data attribute -->
<form id="ajax-withdrawal-form" data-csrf-token="<?php echo generateCSRFToken(); ?>">
    <div class="form-group">
        <label for="ajax-withdrawal-amount">Amount (ETB)</label>
        <input type="number" class="form-control" id="ajax-withdrawal-amount" required>
    </div>
    
    <div class="form-group">
        <label for="ajax-account-details">Account Details</label>
        <input type="text" class="form-control" id="ajax-account-details" required>
    </div>
    
    <button type="button" class="btn btn-primary" onclick="submitAjaxWithdrawal()">Submit Withdrawal</button>
</form>
```

### Updated AJAX Form Submission
```javascript
// Submit AJAX form with CSRF protection
async function submitAjaxWithdrawal() {
    const form = document.getElementById('ajax-withdrawal-form');
    const amount = document.getElementById('ajax-withdrawal-amount').value;
    const accountDetails = document.getElementById('ajax-account-details').value;
    
    if (!amount || !accountDetails) {
        showToast('Please fill in all required fields', 'error');
        return;
    }
    
    // Ensure we have a CSRF token
    if (!csrfProtection.token) {
        await csrfProtection.getCSRFToken();
    }
    
    try {
        const response = await fetch('/api/withdraw.php', {
            method: 'POST',
            headers: csrfProtection.addCSRFHeader({
                'Content-Type': 'application/json',
            }),
            body: JSON.stringify({
                amount: parseFloat(amount),
                account_details: accountDetails,
                payment_method: 'bank_transfer'
            })
        });
        
        const result = await response.json();
        
        if (response.ok && result.success) {
            showToast(result.message, 'success');
            // Reset form
            form.reset();
        } else {
            showToast(result.error || 'Withdrawal failed', 'error');
        }
    } catch (error) {
        console.error('Error submitting withdrawal:', error);
        showToast('Failed to submit withdrawal request', 'error');
    }
}
```

## Security Best Practices

### Double Submit Cookie Pattern Implementation
```php
<?php
/**
 * Alternative CSRF Protection using Double Submit Cookie Pattern
 */

// Generate CSRF token and set as cookie
function generateCSRFCookieToken() {
    $token = bin2hex(random_bytes(32));
    setcookie('csrf_token', $token, [
        'expires' => time() + 3600, // 1 hour
        'path' => '/',
        'secure' => isset($_SERVER['HTTPS']),
        'httponly' => false, // Must be accessible by JavaScript
        'samesite' => 'Strict'
    ]);
    return $token;
}

// Validate CSRF token using double submit pattern
function validateDoubleSubmitCSRF($token) {
    // Get token from cookie
    $cookieToken = $_COOKIE['csrf_token'] ?? '';
    
    // Validate both tokens
    if (empty($cookieToken) || empty($token)) {
        return false;
    }
    
    return hash_equals($cookieToken, $token);
}
?>
```

### Synchronizer Token Pattern (Primary Implementation)
```php
<?php
/**
 * Synchronizer Token Pattern Implementation
 * This is the primary CSRF protection method used in our system
 */

// Generate and store CSRF token in session
function generateSynchronizerToken() {
    startSecureSession();
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

// Validate CSRF token against session
function validateSynchronizerToken($token) {
    startSecureSession();
    $sessionToken = $_SESSION['csrf_token'] ?? '';
    
    if (empty($sessionToken) || empty($token)) {
        return false;
    }
    
    // Use hash_equals to prevent timing attacks
    return hash_equals($sessionToken, $token);
}

// Regenerate CSRF token (for additional security)
function regenerateCSRFToken() {
    startSecureSession();
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf_token'];
}
?>
```

## Summary

This CSRF protection implementation provides:

1. **Synchronizer Token Pattern**:
   - Secure token generation using cryptographically strong random bytes
   - Session-based token storage
   - Timing-attack resistant validation using hash_equals()

2. **Double Submit Cookie Pattern** (alternative):
   - Cookie-based token storage
   - Additional layer of protection

3. **Middleware Integration**:
   - Automatic CSRF validation for POST requests
   - Proper error handling and logging
   - Session management integration

4. **Frontend Support**:
   - JavaScript library for token management
   - AJAX request integration
   - Form submission handling

5. **API Endpoint Protection**:
   - All POST endpoints protected
   - Token regeneration capabilities
   - Comprehensive error responses

6. **Security Best Practices**:
   - Secure session configuration
   - Proper token expiration
   - Logging of failed attempts
   - Defense against timing attacks

The implementation ensures that all state-changing operations are protected against CSRF attacks while maintaining usability for legitimate users.