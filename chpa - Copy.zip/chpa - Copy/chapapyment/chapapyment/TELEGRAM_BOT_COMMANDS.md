# Chapa Payment Telegram Bot - Complete Command Reference

This document provides all the commands needed to set up, run, and interact with the Chapa Payment Telegram Bot.

## Setup Commands

### 1. Install Dependencies

```bash
# Install all required packages
npm install telegraf sqlite3 sqlite dotenv
```

### 2. Configure Environment

```bash
# Create/edit .env file with your credentials
echo "BOT_TOKEN=YOUR_TELEGRAM_BOT_TOKEN_HERE
CHAPA_PUBLIC_KEY=CHAPUBK_TEST-tMMPxq88nzQ8jgNUvDkvcOVi7q56LDXH
CHAPA_SECRET_KEY=CHASECK_TEST-AIE8fYv5RgxoM7T3suc2MhVi0SrXedBf" > .env
```

### 3. Initialize Database

```bash
# Create and initialize SQLite database
node init-telegram-db.js
```

### 4. Test Database

```bash
# Verify database structure and functionality
node test-bot.js
```

## Database Table Creation Commands

### Telegram Users Table

```sql
CREATE TABLE telegram_users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  telegram_id INTEGER UNIQUE NOT NULL,
  username TEXT,
  first_name TEXT,
  last_name TEXT,
  balance DECIMAL(10, 2) DEFAULT 0.00,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

### Telegram Transactions Table

```sql
CREATE TABLE telegram_transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  telegram_user_id INTEGER NOT NULL,
  transaction_type TEXT NOT NULL,
  amount DECIMAL(10, 2) NOT NULL,
  status TEXT DEFAULT 'pending',
  tx_ref TEXT UNIQUE,
  chapa_tx_ref TEXT,
  payment_method TEXT,
  description TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

## Running the Bot

### Start the Bot

```bash
# Using npm script
npm run bot

# Or directly
node telegram-bot.js
```

### Stop the Bot

```bash
# Press Ctrl+C in the terminal where the bot is running
# Or send SIGINT signal
kill -INT <process_id>
```

## Telegram Bot Commands

### User Commands

```bash
# Start the bot and get welcome message
/start

# Show help message with available commands
/help

# Check current account balance
/balance

# Initiate a deposit transaction
/deposit

# Request a withdrawal
/withdraw

# View recent transactions
/transactions

# Cancel current operation
/cancel
```

### Deposit Process Commands

```bash
# 1. Start deposit process
/deposit

# 2. Enter amount when prompted (example)
1000

# 3. Complete payment via Chapa link
# (Click the provided link and complete payment)

# 4. Check updated balance
/balance
```

### Withdrawal Process Commands

```bash
# 1. Start withdrawal process
/withdraw

# 2. Check available balance
/balance

# 3. Enter amount when prompted (example)
500

# 4. Confirm withdrawal
# (Bot will confirm successful withdrawal)

# 5. Check updated balance
/balance
```

## Database Management Commands

### SQLite Database Commands

```bash
# Connect to database
sqlite3 chapa_telegram.db

# List all tables
.tables

# Show table structure
.schema telegram_users
.schema telegram_transactions

# Query data
SELECT * FROM telegram_users;
SELECT * FROM telegram_transactions;

# Count records
SELECT COUNT(*) FROM telegram_users;
SELECT COUNT(*) FROM telegram_transactions;

# Exit SQLite
.quit
```

### Database Backup Commands

```bash
# Create backup
cp chapa_telegram.db chapa_telegram_backup.db

# Restore from backup
cp chapa_telegram_backup.db chapa_telegram.db

# Create timestamped backup
cp chapa_telegram.db chapa_telegram_backup_$(date +%Y%m%d_%H%M%S).db
```

### Database Maintenance Commands

```bash
# Check database integrity
sqlite3 chapa_telegram.db "PRAGMA integrity_check;"

# Optimize database
sqlite3 chapa_telegram.db "VACUUM;"

# Check database size
ls -la chapa_telegram.db
```

## Testing Commands

### Unit Testing

```bash
# Run database initialization test
node init-telegram-db.js

# Run comprehensive database test
node test-bot.js
```

### Functional Testing

```bash
# Test all bot functionalities
# 1. Start bot
npm run bot

# 2. In Telegram:
/start
/help
/balance
/deposit
# Enter amount: 1000
/withdraw
# Enter amount: 500
/transactions
/balance
/cancel
```

## Environment Configuration Commands

### View Environment Variables

```bash
# On Linux/Mac
cat .env

# On Windows
type .env
```

### Set Environment Variables

```bash
# On Linux/Mac
export BOT_TOKEN="your_telegram_bot_token"
export CHAPA_PUBLIC_KEY="your_chapa_public_key"
export CHAPA_SECRET_KEY="your_chapa_secret_key"

# On Windows (Command Prompt)
set BOT_TOKEN=your_telegram_bot_token
set CHAPA_PUBLIC_KEY=your_chapa_public_key
set CHAPA_SECRET_KEY=your_chapa_secret_key

# On Windows (PowerShell)
$env:BOT_TOKEN="your_telegram_bot_token"
$env:CHAPA_PUBLIC_KEY="your_chapa_public_key"
$env:CHAPA_SECRET_KEY="your_chapa_secret_key"
```

## Monitoring Commands

### Check Running Processes

```bash
# On Linux/Mac
ps aux | grep node

# On Windows
tasklist | findstr node
```

### View Logs

```bash
# View recent log entries
tail -f /path/to/bot/log/file

# View last 50 log lines
tail -50 /path/to/bot/log/file
```

## Troubleshooting Commands

### Common Issues Resolution

```bash
# Check if required packages are installed
npm list telegraf sqlite3 sqlite dotenv

# Reinstall dependencies
rm -rf node_modules
npm install

# Check Node.js version
node --version

# Check npm version
npm --version
```

### Database Issues

```bash
# Check if database file exists
ls -la chapa_telegram.db

# Check database permissions
ls -l chapa_telegram.db

# Check if tables exist
sqlite3 chapa_telegram.db ".tables"

# Repair database (if corrupted)
sqlite3 chapa_telegram.db "PRAGMA integrity_check;"
```

## Security Commands

### Secure Configuration

```bash
# Set proper permissions for .env file
chmod 600 .env

# Set proper permissions for database file
chmod 600 chapa_telegram.db

# Verify permissions
ls -l .env chapa_telegram.db
```

### Backup and Recovery

```bash
# Create secure backup
cp .env .env.backup.$(date +%Y%m%d)
cp chapa_telegram.db chapa_telegram.db.backup.$(date +%Y%m%d)

# Verify backups
ls -la *.backup*
```

## Advanced Commands

### Custom Queries

```bash
# Find users with high balances
sqlite3 chapa_telegram.db "SELECT telegram_id, username, balance FROM telegram_users WHERE balance > 10000 ORDER BY balance DESC;"

# Find recent transactions
sqlite3 chapa_telegram.db "SELECT * FROM telegram_transactions WHERE created_at > datetime('now', '-7 days') ORDER BY created_at DESC;"

# Count transactions by type
sqlite3 chapa_telegram.db "SELECT transaction_type, COUNT(*) as count FROM telegram_transactions GROUP BY transaction_type;"
```

### Performance Monitoring

```bash
# Check system resources
top -p $(pgrep -f telegram-bot.js)

# Check memory usage
ps -o pid,vsz,rss,comm -p $(pgrep -f telegram-bot.js)
```

## Summary

With these commands, you can:

1. Set up the Chapa Payment Telegram Bot from scratch
2. Run and manage the bot
3. Interact with users through Telegram commands
4. Manage the database and transactions
5. Monitor and troubleshoot the system
6. Maintain security and backups

The bot provides a complete payment solution with deposit and withdrawal functionality integrated with the Chapa payment gateway.