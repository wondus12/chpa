# Chapa Banking App - Local Setup Instructions

## Quick Start Guide

I've configured your project for local development. Here's how to run it:

## Prerequisites

You need to install a local web server with PHP and MySQL. Choose one of these options:

### Option 1: XAMPP (Recommended)
1. Download XAMPP from https://www.apachefriends.org/
2. Install XAMPP
3. Start Apache and MySQL from XAMPP Control Panel

### Option 2: WAMP (Windows)
1. Download WAMP from https://www.wampserver.com/
2. Install WAMP
3. Start WAMP services

### Option 3: MAMP (Mac/Windows)
1. Download MAMP from https://www.mamp.info/
2. Install MAMP
3. Start MAMP services

## Database Setup

1. Open phpMyAdmin (usually at http://localhost/phpmyadmin)
2. Import the database schema:
   - Click "Import" tab
   - Choose file: `database_setup.sql`
   - Click "Go"

This will create:
- Database: `chapa_banking`
- Sample admin user: admin@example.com (password: admin123)
- Sample regular user: user@example.com (password: user123)

## Running the Application

### Method 1: Using XAMPP/WAMP/MAMP
1. Copy your project folder to the web server directory:
   - XAMPP: `C:\xampp\htdocs\chapa-banking\`
   - WAMP: `C:\wamp64\www\chapa-banking\`
   - MAMP: `/Applications/MAMP/htdocs/chapa-banking/`

2. Access the application at:
   - http://localhost/chapa-banking/chapapymentformfile.html

### Method 2: Using PHP Built-in Server (if PHP is installed)
1. Open Command Prompt/Terminal in the project directory
2. Run: `php -S localhost:8000`
3. Access the application at: http://localhost:8000/chapapymentformfile.html

## Configuration

The `config.php` file has been set up for local development with:
- Database: localhost/chapa_banking (root user, no password)
- Domain: http://localhost:8000
- Development mode enabled
- Error reporting enabled
- Test Chapa keys configured

## Testing the Application

### Login Credentials
- **Admin**: admin@example.com / admin123
- **User**: user@example.com / user123

### Features to Test
1. **Deposit**: Select amount and test Chapa payment integration
2. **Withdrawal**: Request withdrawal (requires admin approval)
3. **Transaction History**: View payment history with filters
4. **Admin Panel**: Login as admin to approve/reject withdrawals

## File Structure
```
chapapyment/
├── config.php                 # Configuration file (updated for local)
├── chapapymentformfile.html   # Main application file
├── database_setup.sql         # Database schema and sample data
├── api/                       # API endpoints
│   ├── verify-payment.php
│   ├── webhook.php
│   └── ...
├── logs/                      # Application logs
└── vendor/                    # Dependencies
```

## Troubleshooting

### Database Connection Issues
- Ensure MySQL is running
- Check database credentials in config.php
- Verify database exists and tables are created

### PHP Errors
- Check error logs in logs/errors.log
- Ensure PHP extensions are enabled (PDO, MySQL)

### Chapa Integration
- The app uses test Chapa keys for development
- Payment simulation will work without real transactions

## Next Steps

1. Start your web server (XAMPP/WAMP/MAMP)
2. Import the database schema
3. Access the application in your browser
4. Test with the provided login credentials

The application is now ready to run locally with all security features and functionality intact!
