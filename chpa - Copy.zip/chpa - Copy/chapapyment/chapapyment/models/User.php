<?php
/**
 * User Model
 */

class User {
    private $conn;
    private $table_name = "users";
    
    public $id;
    public $username;
    public $email;
    public $password_hash;
    public $balance;
    public $role;
    public $created_at;
    public $updated_at;
    
    public function __construct($db) {
        $this->conn = $db;
    }
    
    // Create a new user
    public function createUser($userData) {
        $query = "INSERT INTO " . $this->table_name . " 
                  (username, email, password_hash, role) 
                  VALUES (:username, :email, :password_hash, :role)";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':username', $userData['username']);
        $stmt->bindParam(':email', $userData['email']);
        $stmt->bindParam(':password_hash', $userData['password_hash']);
        $stmt->bindParam(':role', $userData['role'] ?? 'user');
        
        return $stmt->execute();
    }
    
    // Get user by ID
    public function getUserById($user_id) {
        $query = "SELECT * FROM " . $this->table_name . " WHERE id = :user_id LIMIT 1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->execute();
        
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    // Get user by email
    public function getUserByEmail($email) {
        $query = "SELECT * FROM " . $this->table_name . " WHERE email = :email LIMIT 1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':email', $email);
        $stmt->execute();
        
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    // Update user balance with notification
    public function updateBalance($user_id, $amount, $operation = 'add') {
        try {
            // Start transaction
            $this->conn->beginTransaction();
            
            if ($operation === 'add') {
                $query = "UPDATE " . $this->table_name . " SET balance = balance + :amount, updated_at = CURRENT_TIMESTAMP WHERE id = :user_id";
            } else {
                $query = "UPDATE " . $this->table_name . " SET balance = balance - :amount, updated_at = CURRENT_TIMESTAMP WHERE id = :user_id";
            }
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':amount', $amount);
            $stmt->bindParam(':user_id', $user_id);
            
            $result = $stmt->execute();
            
            if ($result) {
                // Get the new balance
                $userData = $this->getUserById($user_id);
                $newBalance = $userData['balance'] ?? 0.0;
                
                // Commit transaction
                $this->conn->commit();
                
                return true;
            } else {
                $this->conn->rollBack();
                return false;
            }
        } catch (Exception $e) {
            $this->conn->rollBack();
            error_log("Balance update failed: " . $e->getMessage());
            return false;
        }
    }
    
    // Verify user password
    public function verifyPassword($email, $password) {
        $user = $this->getUserByEmail($email);
        if ($user && password_verify($password, $user['password_hash'])) {
            return $user;
        }
        return false;
    }
    
    // Update user password
    public function updatePassword($user_id, $new_password) {
        $password_hash = password_hash($new_password, PASSWORD_DEFAULT);
        
        $query = "UPDATE " . $this->table_name . " SET password_hash = :password_hash, updated_at = CURRENT_TIMESTAMP WHERE id = :user_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':password_hash', $password_hash);
        $stmt->bindParam(':user_id', $user_id);
        
        return $stmt->execute();
    }
}
?>
