<?php
/**
 * Transaction Model with Filtering
 */

class Transaction {
    private $conn;
    private $table_name = "transactions";
    
    public $id;
    public $user_id;
    public $transaction_type;
    public $amount;
    public $status;
    public $tx_ref;
    public $chapa_tx_ref;
    public $payment_method;
    public $description;
    public $created_at;
    public $updated_at;
    
    public function __construct($db) {
        $this->conn = $db;
    }
    
    // Create a new transaction
    public function createTransaction($user_id, $type, $amount, $tx_ref, $chapa_tx_ref = null, $payment_method = null, $description = null) {
        $query = "INSERT INTO " . $this->table_name . " 
                  (user_id, transaction_type, amount, tx_ref, chapa_tx_ref, payment_method, description, status) 
                  VALUES (:user_id, :transaction_type, :amount, :tx_ref, :chapa_tx_ref, :payment_method, :description, 'pending')";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->bindParam(':transaction_type', $type);
        $stmt->bindParam(':amount', $amount);
        $stmt->bindParam(':tx_ref', $tx_ref);
        $stmt->bindParam(':chapa_tx_ref', $chapa_tx_ref);
        $stmt->bindParam(':payment_method', $payment_method);
        $stmt->bindParam(':description', $description);
        
        return $stmt->execute();
    }
    
    // Update transaction status
    public function updateStatus($tx_ref, $status) {
        $query = "UPDATE " . $this->table_name . " SET status = :status, updated_at = CURRENT_TIMESTAMP WHERE tx_ref = :tx_ref";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':status', $status);
        $stmt->bindParam(':tx_ref', $tx_ref);
        
        return $stmt->execute();
    }
    
    // Get transaction by reference
    public function getTransactionByRef($tx_ref) {
        $query = "SELECT * FROM " . $this->table_name . " WHERE tx_ref = :tx_ref LIMIT 1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':tx_ref', $tx_ref);
        $stmt->execute();
        
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    // Get user transactions with basic pagination
    public function getUserTransactions($user_id, $limit = 10) {
        $query = "SELECT * FROM " . $this->table_name . " 
                  WHERE user_id = :user_id 
                  ORDER BY created_at DESC 
                  LIMIT :limit";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // Get user transactions with advanced filtering
    public function getUserTransactionsWithFilters($user_id, $filters = []) {
        $query = "SELECT t.* FROM " . $this->table_name . " t";
        
        $params = [':user_id' => $user_id];
        $whereClauses = ["t.user_id = :user_id"];
        
        // Add date filters
        if (!empty($filters['date_from'])) {
            $whereClauses[] = "t.created_at >= :date_from";
            $params[':date_from'] = $filters['date_from'];
        }
        
        if (!empty($filters['date_to'])) {
            $whereClauses[] = "t.created_at <= :date_to";
            $params[':date_to'] = $filters['date_to'];
        }
        
        // Add status filter
        if (!empty($filters['status'])) {
            $whereClauses[] = "t.status = :status";
            $params[':status'] = $filters['status'];
        }
        
        // Add type filter
        if (!empty($filters['type'])) {
            $whereClauses[] = "t.transaction_type = :type";
            $params[':type'] = $filters['type'];
        }
        
        // Add search filter
        if (!empty($filters['search'])) {
            $searchTerm = '%' . $filters['search'] . '%';
            $whereClauses[] = "(t.tx_ref LIKE :search OR t.description LIKE :search OR t.payment_method LIKE :search)";
            $params[':search'] = $searchTerm;
        }
        
        // Add where clause if needed
        if (!empty($whereClauses)) {
            $query .= " WHERE " . implode(" AND ", $whereClauses);
        }
        
        // Add ordering and pagination
        $query .= " ORDER BY t.created_at DESC";
        
        if (isset($filters['limit'])) {
            $query .= " LIMIT :limit OFFSET :offset";
            $params[':limit'] = $filters['limit'];
            $params[':offset'] = $filters['offset'];
        }
        
        $stmt = $this->conn->prepare($query);
        
        // Bind parameters
        foreach ($params as $key => $value) {
            if ($key === ':limit' || $key === ':offset') {
                $stmt->bindValue($key, $value, PDO::PARAM_INT);
            } else {
                $stmt->bindValue($key, $value);
            }
        }
        
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // Get user transaction count with filters
    public function getUserTransactionCount($user_id, $filters = []) {
        $query = "SELECT COUNT(*) as count FROM " . $this->table_name . " t";
        
        $params = [':user_id' => $user_id];
        $whereClauses = ["t.user_id = :user_id"];
        
        // Add date filters
        if (!empty($filters['date_from'])) {
            $whereClauses[] = "t.created_at >= :date_from";
            $params[':date_from'] = $filters['date_from'];
        }
        
        if (!empty($filters['date_to'])) {
            $whereClauses[] = "t.created_at <= :date_to";
            $params[':date_to'] = $filters['date_to'];
        }
        
        // Add status filter
        if (!empty($filters['status'])) {
            $whereClauses[] = "t.status = :status";
            $params[':status'] = $filters['status'];
        }
        
        // Add type filter
        if (!empty($filters['type'])) {
            $whereClauses[] = "t.transaction_type = :type";
            $params[':type'] = $filters['type'];
        }
        
        // Add search filter
        if (!empty($filters['search'])) {
            $searchTerm = '%' . $filters['search'] . '%';
            $whereClauses[] = "(t.tx_ref LIKE :search OR t.description LIKE :search OR t.payment_method LIKE :search)";
            $params[':search'] = $searchTerm;
        }
        
        // Add where clause if needed
        if (!empty($whereClauses)) {
            $query .= " WHERE " . implode(" AND ", $whereClauses);
        }
        
        $stmt = $this->conn->prepare($query);
        
        // Bind parameters
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['count'] ?? 0;
    }
}
?>
