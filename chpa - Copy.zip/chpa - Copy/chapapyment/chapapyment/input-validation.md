# Input Validation and Sanitization Implementation

## Security Implementation

### Input Validation Library (security/InputValidator.php)
```php
<?php
/**
 * Input Validation and Sanitization Library
 * Provides comprehensive input validation and sanitization functions
 */

class InputValidator {
    /**
     * Validate and sanitize email address
     */
    public static function validateEmail($email) {
        $email = filter_var(trim($email), FILTER_SANITIZE_EMAIL);
        if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return $email;
        }
        return false;
    }
    
    /**
     * Validate and sanitize numeric amount
     */
    public static function validateAmount($amount) {
        // Remove any non-numeric characters except decimal point
        $amount = preg_replace('/[^0-9.]/', '', $amount);
        
        // Validate as float
        if (filter_var($amount, FILTER_VALIDATE_FLOAT) !== false) {
            $floatAmount = floatval($amount);
            // Ensure positive amount
            if ($floatAmount > 0) {
                return $floatAmount;
            }
        }
        return false;
    }
    
    /**
     * Validate and sanitize transaction reference
     */
    public static function validateTxRef($txRef) {
        // Remove any potentially dangerous characters
        $txRef = preg_replace('/[^a-zA-Z0-9-_]/', '', $txRef);
        
        // Ensure it's not empty and within reasonable length
        if (!empty($txRef) && strlen($txRef) <= 100) {
            return $txRef;
        }
        return false;
    }
    
    /**
     * Validate and sanitize account details
     */
    public static function validateAccountDetails($accountDetails) {
        // Trim and remove extra whitespace
        $accountDetails = trim(preg_replace('/\s+/', ' ', $accountDetails));
        
        // Ensure it's not empty and within reasonable length
        if (!empty($accountDetails) && strlen($accountDetails) <= 255) {
            return $accountDetails;
        }
        return false;
    }
    
    /**
     * Validate and sanitize username
     */
    public static function validateUsername($username) {
        // Remove any non-alphanumeric characters except underscore and hyphen
        $username = preg_replace('/[^a-zA-Z0-9_-]/', '', $username);
        
        // Ensure it's between 3-30 characters
        if (strlen($username) >= 3 && strlen($username) <= 30) {
            return $username;
        }
        return false;
    }
    
    /**
     * Validate and sanitize phone number
     */
    public static function validatePhoneNumber($phone) {
        // Remove any non-digit characters except + for international format
        $phone = preg_replace('/[^0-9+]/', '', $phone);
        
        // Validate E.164 format (starts with +, 7-15 digits)
        if (preg_match('/^\+[1-9]\d{6,14}$/', $phone)) {
            return $phone;
        }
        
        // Validate Ethiopian phone format (10 digits starting with 09)
        if (preg_match('/^09\d{8}$/', $phone)) {
            return $phone;
        }
        
        return false;
    }
    
    /**
     * Validate and sanitize payment method
     */
    public static function validatePaymentMethod($method) {
        $allowedMethods = ['bank_transfer', 'mobile_money', 'chapa', 'telebirr'];
        if (in_array($method, $allowedMethods)) {
            return $method;
        }
        return false;
    }
    
    /**
     * Validate and sanitize date
     */
    public static function validateDate($date) {
        // Remove any non-date characters
        $date = preg_replace('/[^0-9\-\/: ]/', '', $date);
        
        // Try to parse the date
        $timestamp = strtotime($date);
        if ($timestamp !== false) {
            return date('Y-m-d H:i:s', $timestamp);
        }
        return false;
    }
    
    /**
     * Validate and sanitize string input
     */
    public static function validateString($string, $maxLength = 255) {
        // Trim and sanitize string
        $string = trim(filter_var($string, FILTER_SANITIZE_STRING, FILTER_FLAG_NO_ENCODE_QUOTES));
        
        // Ensure it's not empty and within length limit
        if (!empty($string) && strlen($string) <= $maxLength) {
            return $string;
        }
        return false;
    }
    
    /**
     * Validate and sanitize integer input
     */
    public static function validateInteger($integer) {
        // Remove any non-numeric characters
        $integer = preg_replace('/[^0-9]/', '', $integer);
        
        // Validate as integer
        if (filter_var($integer, FILTER_VALIDATE_INT) !== false) {
            return intval($integer);
        }
        return false;
    }
    
    /**
     * Validate and sanitize URL
     */
    public static function validateUrl($url) {
        $url = filter_var(trim($url), FILTER_SANITIZE_URL);
        if (filter_var($url, FILTER_VALIDATE_URL)) {
            return $url;
        }
        return false;
    }
    
    /**
     * Validate and sanitize JSON input
     */
    public static function validateJson($json) {
        $data = json_decode($json, true);
        if (json_last_error() === JSON_ERROR_NONE) {
            return $data;
        }
        return false;
    }
    
    /**
     * Validate and sanitize array input
     */
    public static function validateArray($array, $allowedKeys = []) {
        if (!is_array($array)) {
            return false;
        }
        
        // If allowed keys are specified, filter the array
        if (!empty($allowedKeys)) {
            $array = array_intersect_key($array, array_flip($allowedKeys));
        }
        
        // Sanitize each value in the array
        foreach ($array as $key => $value) {
            if (is_string($value)) {
                $array[$key] = self::validateString($value);
            } elseif (is_numeric($value)) {
                $array[$key] = filter_var($value, FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
            }
        }
        
        return $array;
    }
}
?>
```

### Updated API Endpoints with Input Validation

#### Verify Payment API with Input Validation (api/verify-payment.php)
```php
<?php
/**
 * Updated Chapa Payment Verification API with Input Validation
 */

require_once __DIR__ . '/../session_config.php';
require_once __DIR__ . '/../security/csrf.php';
require_once __DIR__ . '/../security/InputValidator.php';
require_once __DIR__ . '/../config.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: ' . DOMAIN_URL);
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-CSRF-Token');
header('Access-Control-Allow-Credentials: true');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// Validate CSRF token for POST requests
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !validateCSRFMiddleware()) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => 'Invalid CSRF token'
    ]);
    exit;
}

class ChapaVerification {
    // ... existing code ...
    
    public function verifyPayment($txRef) {
        // Validate transaction reference
        $validatedTxRef = InputValidator::validateTxRef($txRef);
        if (!$validatedTxRef) {
            return [
                'success' => false,
                'error' => 'Invalid transaction reference'
            ];
        }
        
        $config = getChapaConfig();
        $url = $config['base_url'] . '/transaction/verify/' . $validatedTxRef;
        
        // ... rest of existing implementation with validated input ...
    }
    
    // ... existing code ...
}

// Handle the request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input || !isset($input['tx_ref'])) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'error' => 'Transaction reference (tx_ref) is required'
        ]);
        exit;
    }
    
    // Validate input
    $txRef = InputValidator::validateTxRef($input['tx_ref']);
    if (!$txRef) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'error' => 'Invalid transaction reference format'
        ]);
        exit;
    }
    
    $useSimulation = filter_var($input['simulate'] ?? false, FILTER_VALIDATE_BOOLEAN);
    
    $verifier = new ChapaVerification();
    
    if ($useSimulation) {
        $result = $verifier->simulateVerification($txRef);
    } else {
        $result = $verifier->verifyPayment($txRef);
    }
    
    echo json_encode($result);
    
} else {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed. Use POST.'
    ]);
}
?>
```

#### Webhook API with Enhanced Input Validation (api/webhook.php)
```php
<?php
/**
 * Updated Chapa Webhook Handler with Enhanced Input Validation
 */

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../security/InputValidator.php';
require_once __DIR__ . '/../security/csrf.php'; // Not needed for webhooks, but included for consistency

header('Content-Type: application/json');

class ChapaWebhook {
    public function handleWebhook() {
        $payload = file_get_contents('php://input');
        
        // Validate JSON payload
        $data = InputValidator::validateJson($payload);
        if (!$data) {
            http_response_code(400);
            return [
                'success' => false,
                'error' => 'Invalid JSON payload'
            ];
        }
        
        $signature = $_SERVER['HTTP_X_CHAPA_SIGNATURE'] ?? '';
        
        // Verify signature
        if (!$this->verifySignature($payload, $signature)) {
            http_response_code(401);
            return [
                'success' => false,
                'error' => 'Invalid signature'
            ];
        }
        
        // Process the webhook with validated data
        $result = $this->processWebhookData($data);
        
        // Log the webhook
        $this->logWebhook($payload, $signature, $result);
        
        return $result;
    }
    
    private function processWebhookData($data) {
        // Validate event type
        $event = InputValidator::validateString($data['event'] ?? 'unknown');
        if (!$event) {
            return [
                'success' => false,
                'error' => 'Invalid event data'
            ];
        }
        
        // Validate transaction reference
        $txRef = InputValidator::validateTxRef($data['data']['tx_ref'] ?? null);
        if (!$txRef) {
            return [
                'success' => false,
                'error' => 'Invalid transaction reference'
            ];
        }
        
        // Validate amount
        $amount = InputValidator::validateAmount($data['data']['amount'] ?? 0);
        if (!$amount) {
            return [
                'success' => false,
                'error' => 'Invalid amount'
            ];
        }
        
        switch ($event) {
            case 'payment.success':
                return $this->handlePaymentSuccess($data['data']);
                
            case 'payment.failed':
                return $this->handlePaymentFailed($data['data']);
                
            case 'payment.pending':
                return $this->handlePaymentPending($data['data']);
                
            default:
                return [
                    'success' => true,
                    'message' => 'Event received but not processed: ' . $event
                ];
        }
    }
    
    // ... rest of existing implementation ...
}

// Handle the webhook
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $webhook = new ChapaWebhook();
    $result = $webhook->handleWebhook();
    echo json_encode($result);
} else {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed. Use POST.'
    ]);
}
?>
```

#### Withdrawal API with Input Validation (api/withdraw.php)
```php
<?php
/**
 * Withdrawal API with Input Validation
 */

require_once __DIR__ . '/../session_config.php';
require_once __DIR__ . '/../security/csrf.php';
require_once __DIR__ . '/../security/InputValidator.php';
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../models/Transaction.php';
require_once __DIR__ . '/../models/WithdrawalRequest.php';
require_once __DIR__ . '/../security/FraudDetector.php';

header('Content-Type: application/json');

// Validate CSRF token
if (!validateCSRFMiddleware()) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => 'Invalid CSRF token'
    ]);
    exit;
}

// Validate user authentication
$user_id = $_SESSION['user_id'] ?? null;
if (!$user_id) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'error' => 'User not authenticated'
    ]);
    exit;
}

// Get request data
$input = json_decode(file_get_contents('php://input'), true);

// Validate amount
$amount = InputValidator::validateAmount($input['amount'] ?? 0);
if (!$amount) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => 'Invalid amount format'
    ]);
    exit;
}

// Validate account details
$accountDetails = InputValidator::validateAccountDetails($input['account_details'] ?? '');
if (!$accountDetails) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => 'Invalid account details'
    ]);
    exit;
}

// Validate payment method
$paymentMethod = InputValidator::validatePaymentMethod($input['payment_method'] ?? 'bank_transfer');
if (!$paymentMethod) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => 'Invalid payment method'
    ]);
    exit;
}

// Initialize database connection
$database = new Database();
$db = $database->getConnection();

// Validate withdrawal amount against user balance
$user = new User($db);
$userData = $user->getUserById($user_id);

if (!$userData) {
    http_response_code(404);
    echo json_encode([
        'success' => false,
        'error' => 'User not found'
    ]);
    exit;
}

if ($amount > $userData['balance']) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => 'Insufficient balance'
    ]);
    exit;
}

// Perform fraud checks
$fraudDetector = new FraudDetector($db);
$fraudCheck = $fraudDetector->checkTransaction($user_id, $amount, 'withdrawal', $_SERVER['REMOTE_ADDR']);

if (!$fraudCheck['passed']) {
    http_response_code(403);
    echo json_encode([
        'success' => false,
        'error' => 'Transaction flagged by fraud detection',
        'fraud_level' => $fraudCheck['fraud_level'],
        'warnings' => $fraudCheck['warnings']
    ]);
    exit;
}

// Create withdrawal request
$withdrawalRequest = new WithdrawalRequest($db);
$requestCreated = $withdrawalRequest->createRequest($user_id, $amount, $accountDetails, $paymentMethod);

if ($requestCreated) {
    // Deduct amount from user balance
    $user->updateBalance($user_id, $amount, 'subtract');
    
    echo json_encode([
        'success' => true,
        'message' => 'Withdrawal request submitted successfully',
        'request_id' => $requestCreated
    ]);
} else {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Failed to submit withdrawal request'
    ]);
}
?>
```

#### Admin API Endpoints with Input Validation

##### Approve Withdrawal Request with Input Validation (api/admin/approve-withdrawal.php)
```php
<?php
/**
 * Approve Withdrawal Request API with Input Validation
 */

require_once __DIR__ . '/../../middleware/admin.php';
require_once __DIR__ . '/../../db.php';
require_once __DIR__ . '/../../models/WithdrawalRequest.php';
require_once __DIR__ . '/../../security/csrf.php';
require_once __DIR__ . '/../../security/InputValidator.php';

header('Content-Type: application/json');

// Validate CSRF token
if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => 'Invalid request token'
    ]);
    exit;
}

// Get and validate request data
$requestId = InputValidator::validateInteger($_POST['request_id'] ?? 0);
$adminNotes = InputValidator::validateString($_POST['admin_notes'] ?? '', 500);

if (!$requestId) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => 'Request ID is required'
    ]);
    exit;
}

// Initialize database connection
$database = new Database();
$db = $database->getConnection();

// Approve the withdrawal request
$withdrawalRequest = new WithdrawalRequest($db);
$approved = $withdrawalRequest->approveRequest($requestId, $currentUserId, $adminNotes);

if ($approved) {
    echo json_encode([
        'success' => true,
        'message' => 'Withdrawal request approved successfully'
    ]);
    
    // Log the action
    Logger::info('Admin approved withdrawal request', [
        'admin_id' => $currentUserId,
        'request_id' => $requestId
    ]);
} else {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Failed to approve withdrawal request'
    ]);
}
?>
```

##### Reject Withdrawal Request with Input Validation (api/admin/reject-withdrawal.php)
```php
<?php
/**
 * Reject Withdrawal Request API with Input Validation
 */

require_once __DIR__ . '/../../middleware/admin.php';
require_once __DIR__ . '/../../db.php';
require_once __DIR__ . '/../../models/WithdrawalRequest.php';
require_once __DIR__ . '/../../security/csrf.php';
require_once __DIR__ . '/../../security/InputValidator.php';

header('Content-Type: application/json');

// Validate CSRF token
if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => 'Invalid request token'
    ]);
    exit;
}

// Get and validate request data
$requestId = InputValidator::validateInteger($_POST['request_id'] ?? 0);
$adminNotes = InputValidator::validateString($_POST['admin_notes'] ?? '', 500);

if (!$requestId) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => 'Request ID is required'
    ]);
    exit;
}

if (empty($adminNotes)) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => 'Rejection reason is required'
    ]);
    exit;
}

// Initialize database connection
$database = new Database();
$db = $database->getConnection();

// Reject the withdrawal request
$withdrawalRequest = new WithdrawalRequest($db);
$rejected = $withdrawalRequest->rejectRequest($requestId, $currentUserId, $adminNotes);

if ($rejected) {
    echo json_encode([
        'success' => true,
        'message' => 'Withdrawal request rejected successfully'
    ]);
    
    // Log the action
    Logger::info('Admin rejected withdrawal request', [
        'admin_id' => $currentUserId,
        'request_id' => $requestId
    ]);
} else {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Failed to reject withdrawal request'
    ]);
}
?>
```

## Frontend Implementation

### Updated JavaScript with Input Validation
```javascript
// Input Validation for Frontend
class InputValidator {
    // Validate email format
    static validateEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email) ? email.trim() : false;
    }
    
    // Validate amount (positive number with up to 2 decimal places)
    static validateAmount(amount) {
        // Remove any non-numeric characters except decimal point
        const cleanedAmount = amount.toString().replace(/[^0-9.]/g, '');
        
        // Validate as float
        if (!isNaN(cleanedAmount) && parseFloat(cleanedAmount) > 0) {
            // Ensure only up to 2 decimal places
            const parts = cleanedAmount.split('.');
            if (parts.length <= 2 && (parts[1]?.length <= 2 || parts[1] === undefined)) {
                return parseFloat(cleanedAmount);
            }
        }
        return false;
    }
    
    // Validate account details
    static validateAccountDetails(details) {
        // Trim and remove extra whitespace
        const cleanedDetails = details.trim().replace(/\s+/g, ' ');
        
        // Ensure it's not empty and within reasonable length
        if (cleanedDetails.length > 0 && cleanedDetails.length <= 255) {
            return cleanedDetails;
        }
        return false;
    }
    
    // Validate phone number (Ethiopian format)
    static validatePhoneNumber(phone) {
        // Remove any non-digit characters
        const cleanedPhone = phone.toString().replace(/[^0-9]/g, '');
        
        // Validate Ethiopian phone format (10 digits starting with 09)
        if (/^09\d{8}$/.test(cleanedPhone)) {
            return cleanedPhone;
        }
        
        return false;
    }
    
    // Sanitize string input
    static sanitizeString(str, maxLength = 255) {
        if (typeof str !== 'string') {
            return false;
        }
        
        // Remove potentially dangerous characters
        let sanitized = str.trim();
        sanitized = sanitized.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '');
        sanitized = sanitized.replace(/<\/?[^>]+(>|$)/g, '');
        
        // Ensure within length limit
        if (sanitized.length > 0 && sanitized.length <= maxLength) {
            return sanitized;
        }
        return false;
    }
}

// Updated transaction processing with input validation

// In your deposit processing function
async function initiateDeposit() {
    const amount = document.getElementById('deposit-amount').value;
    
    // Validate amount
    const validatedAmount = InputValidator.validateAmount(amount);
    if (!validatedAmount) {
        showPaymentMessage('deposit-error-message', 'Please enter a valid amount', 'error');
        return;
    }
    
    // Ensure we have a CSRF token
    if (!csrfProtection.token) {
        await csrfProtection.getCSRFToken();
    }
    
    // ... rest of existing implementation ...
}

// In your withdrawal processing function
async function processWithdrawal() {
    const amountInput = document.getElementById('withdraw-amount');
    const accountDetailsInput = document.getElementById('account-details');
    
    const amount = amountInput.value;
    const accountDetails = accountDetailsInput.value;
    
    // Validate inputs
    const validatedAmount = InputValidator.validateAmount(amount);
    if (!validatedAmount) {
        showPaymentMessage('withdraw-error-message', 'Please enter a valid amount', 'error');
        return;
    }
    
    const validatedAccountDetails = InputValidator.validateAccountDetails(accountDetails);
    if (!validatedAccountDetails) {
        showPaymentMessage('withdraw-error-message', 'Please enter valid account details', 'error');
        return;
    }
    
    // Ensure we have a CSRF token
    if (!csrfProtection.token) {
        await csrfProtection.getCSRFToken();
    }
    
    try {
        const response = await fetch(CHAPA_CONFIG.baseUrl + 'withdraw.php', {
            method: 'POST',
            headers: csrfProtection.addCSRFHeader({
                'Content-Type': 'application/json',
            }),
            body: JSON.stringify({
                amount: validatedAmount,
                account_details: validatedAccountDetails,
                payment_method: 'bank_transfer'
            })
        });
        
        const result = await response.json();
        
        if (response.ok && result.success) {
            showPaymentMessage('withdraw-success-message', result.message, 'success');
            // Reset form
            amountInput.value = '';
            accountDetailsInput.value = '';
        } else {
            showPaymentMessage('withdraw-error-message', result.error || 'Withdrawal failed', 'error');
        }
    } catch (error) {
        console.error('Error processing withdrawal:', error);
        showPaymentMessage('withdraw-error-message', 'Unable to process withdrawal. Please try again.', 'error');
    }
}
```

### Updated HTML Forms with Frontend Validation
```html
<!-- Add frontend validation to forms -->
<form id="withdrawal-form">
    <div class="form-group">
        <label for="withdrawal-amount">Amount (ETB)</label>
        <input type="number" class="form-control" id="withdrawal-amount" 
               placeholder="Enter amount" step="0.01" min="50" max="50000" required>
        <div class="invalid-feedback" id="amount-error"></div>
    </div>
    
    <div class="form-group">
        <label for="account-details">Account Details</label>
        <input type="text" class="form-control" id="account-details" 
               placeholder="Enter account details" required>
        <div class="invalid-feedback" id="account-error"></div>
    </div>
    
    <div class="form-group">
        <label for="payment-method">Payment Method</label>
        <select class="form-control" id="payment-method">
            <option value="bank_transfer">Bank Transfer</option>
            <option value="mobile_money">Mobile Money</option>
        </select>
    </div>
    
    <button type="button" class="btn btn-primary" onclick="validateAndSubmitWithdrawal()">
        Submit Withdrawal Request
    </button>
</form>

<script>
// Validate form before submission
function validateAndSubmitWithdrawal() {
    const amountInput = document.getElementById('withdrawal-amount');
    const accountInput = document.getElementById('account-details');
    
    // Reset validation states
    amountInput.classList.remove('is-invalid');
    accountInput.classList.remove('is-invalid');
    
    // Validate amount
    const amount = amountInput.value;
    const validatedAmount = InputValidator.validateAmount(amount);
    if (!validatedAmount) {
        amountInput.classList.add('is-invalid');
        document.getElementById('amount-error').textContent = 'Please enter a valid amount between 50 and 50,000 ETB';
        return;
    }
    
    // Validate account details
    const accountDetails = accountInput.value;
    const validatedAccount = InputValidator.validateAccountDetails(accountDetails);
    if (!validatedAccount) {
        accountInput.classList.add('is-invalid');
        document.getElementById('account-error').textContent = 'Please enter valid account details';
        return;
    }
    
    // If validation passes, submit the withdrawal
    processWithdrawal();
}
</script>
```

## Database Security

### Prepared Statements for All Database Queries
```php
<?php
/**
 * Example of using prepared statements for database security
 */

class SecureDatabaseQueries {
    private $conn;
    
    public function __construct($dbConnection) {
        $this->conn = $dbConnection;
    }
    
    // Secure user lookup by ID
    public function getUserById($userId) {
        $query = "SELECT id, username, email, balance, role FROM users WHERE id = :user_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    // Secure transaction creation
    public function createTransaction($userId, $type, $amount, $txRef, $chapaTxRef = null, $paymentMethod = null, $description = null) {
        $query = "INSERT INTO transactions (user_id, transaction_type, amount, tx_ref, chapa_tx_ref, payment_method, description, status) 
                  VALUES (:user_id, :type, :amount, :tx_ref, :chapa_tx_ref, :payment_method, :description, 'pending')";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
        $stmt->bindParam(':type', $type, PDO::PARAM_STR);
        $stmt->bindParam(':amount', $amount, PDO::PARAM_STR);
        $stmt->bindParam(':tx_ref', $txRef, PDO::PARAM_STR);
        $stmt->bindParam(':chapa_tx_ref', $chapaTxRef, PDO::PARAM_STR);
        $stmt->bindParam(':payment_method', $paymentMethod, PDO::PARAM_STR);
        $stmt->bindParam(':description', $description, PDO::PARAM_STR);
        
        return $stmt->execute();
    }
    
    // Secure withdrawal request creation
    public function createWithdrawalRequest($userId, $amount, $accountDetails, $paymentMethod) {
        $query = "INSERT INTO withdrawal_requests (user_id, amount, account_details, payment_method, status) 
                  VALUES (:user_id, :amount, :account_details, :payment_method, 'pending')";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
        $stmt->bindParam(':amount', $amount, PDO::PARAM_STR);
        $stmt->bindParam(':account_details', $accountDetails, PDO::PARAM_STR);
        $stmt->bindParam(':payment_method', $paymentMethod, PDO::PARAM_STR);
        
        return $stmt->execute();
    }
}
?>
```

## Security Best Practices

### XSS Prevention
```php
<?php
/**
 * XSS Prevention Functions
 */

// Safe output function
function safeOutput($data) {
    return htmlspecialchars($data, ENT_QUOTES | ENT_HTML5, 'UTF-8');
}

// Safe JSON output
function safeJsonOutput($data) {
    // Ensure all string values are properly escaped
    array_walk_recursive($data, function(&$value) {
        if (is_string($value)) {
            $value = htmlspecialchars($value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        }
    });
    
    return json_encode($data);
}
?>
```

### SQL Injection Prevention
```php
<?php
/**
 * SQL Injection Prevention Guidelines
 */

// Always use prepared statements:
// GOOD:
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = :id");
$stmt->bindParam(':id', $userId, PDO::PARAM_INT);
$stmt->execute();

// BAD (vulnerable to SQL injection):
$query = "SELECT * FROM users WHERE id = " . $userId;
$stmt = $pdo->query($query);

// When using dynamic column names or table names:
// GOOD:
$allowedTables = ['users', 'transactions', 'withdrawal_requests'];
if (in_array($tableName, $allowedTables)) {
    $query = "SELECT * FROM " . $tableName . " WHERE id = :id";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':id', $userId, PDO::PARAM_INT);
    $stmt->execute();
}
?>
```

## Summary

This input validation and sanitization implementation provides:

1. **Comprehensive Validation Library**:
   - Email validation and sanitization
   - Numeric amount validation
   - Transaction reference validation
   - Account details validation
   - Username validation
   - Phone number validation
   - Payment method validation
   - Date validation
   - String and integer validation

2. **API Endpoint Protection**:
   - All endpoints validate and sanitize inputs
   - Proper error handling for invalid inputs
   - Logging of validation failures

3. **Frontend Validation**:
   - JavaScript validation library
   - Form validation before submission
   - User-friendly error messages

4. **Database Security**:
   - Prepared statements for all queries
   - Parameter binding for all user inputs
   - Protection against SQL injection

5. **XSS Prevention**:
   - HTML entity encoding for all outputs
   - Safe JSON output functions
   - Content Security Policy considerations

6. **Security Best Practices**:
   - Input validation at every layer
   - Sanitization of user-provided data
   - Proper error handling without information leakage
   - Comprehensive logging of security events

The implementation ensures that all user inputs are properly validated and sanitized before processing, providing robust protection against common web vulnerabilities.