// Simple test script to verify bot functionality
require('dotenv').config();
const sqlite3 = require('sqlite3').verbose();
const { open } = require('sqlite');

async function testDatabase() {
  console.log('Testing database connection and structure...');
  
  try {
    // Open database
    const db = await open({
      filename: './chapa_telegram.db',
      driver: sqlite3.Database
    });
    
    console.log('✓ Connected to SQLite database');
    
    // Test telegram_users table
    const usersTable = await db.get(`
      SELECT name FROM sqlite_master WHERE type='table' AND name='telegram_users'
    `);
    
    if (usersTable) {
      console.log('✓ telegram_users table exists');
      
      // Get table info
      const usersInfo = await db.all(`PRAGMA table_info(telegram_users)`);
      console.log('  Columns:');
      usersInfo.forEach(col => {
        console.log(`    - ${col.name} (${col.type})`);
      });
    } else {
      console.log('✗ telegram_users table does not exist');
    }
    
    // Test telegram_transactions table
    const transactionsTable = await db.get(`
      SELECT name FROM sqlite_master WHERE type='table' AND name='telegram_transactions'
    `);
    
    if (transactionsTable) {
      console.log('✓ telegram_transactions table exists');
      
      // Get table info
      const transactionsInfo = await db.all(`PRAGMA table_info(telegram_transactions)`);
      console.log('  Columns:');
      transactionsInfo.forEach(col => {
        console.log(`    - ${col.name} (${col.type})`);
      });
    } else {
      console.log('✗ telegram_transactions table does not exist');
    }
    
    // Test inserting a sample user
    try {
      await db.run(`
        INSERT OR IGNORE INTO telegram_users 
        (telegram_id, username, first_name, last_name, balance) 
        VALUES (?, ?, ?, ?, ?)
      `, [123456789, 'testuser', 'Test', 'User', 1000.00]);
      
      console.log('✓ Sample user inserted successfully');
      
      // Retrieve the user
      const user = await db.get(`
        SELECT * FROM telegram_users WHERE telegram_id = ?
      `, [123456789]);
      
      if (user) {
        console.log('✓ Sample user retrieved successfully');
        console.log(`  User: ${user.first_name} ${user.last_name} (@${user.username})`);
        console.log(`  Balance: ${user.balance} ETB`);
      }
    } catch (insertError) {
      console.log('✗ Error inserting sample user:', insertError.message);
    }
    
    // Close database
    await db.close();
    console.log('✓ Database connection closed');
    
  } catch (error) {
    console.error('✗ Database test failed:', error.message);
    process.exit(1);
  }
}

// Run the test
testDatabase();