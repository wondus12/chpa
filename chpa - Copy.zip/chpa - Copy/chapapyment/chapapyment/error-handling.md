# Error Handling and User Feedback Implementation

## Error Handling Strategy

### Backend Error Handling

#### Global Error Handler
Create a global error handling mechanism:

```php
<?php
// error_handler.php - Global error handling

class ErrorHandler {
    public static function handleException($exception) {
        // Log the error
        error_log("Exception: " . $exception->getMessage() . " in " . $exception->getFile() . " on line " . $exception->getLine());
        
        // Return appropriate response based on environment
        if (defined('IS_PRODUCTION') && IS_PRODUCTION) {
            // Don't expose sensitive information in production
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'error' => 'Internal server error'
            ]);
        } else {
            // Detailed error information for development
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'error' => $exception->getMessage(),
                'file' => $exception->getFile(),
                'line' => $exception->getLine()
            ]);
        }
    }
    
    public static function handleError($errno, $errstr, $errfile, $errline) {
        // Log the error
        error_log("Error: " . $errstr . " in " . $errfile . " on line " . $errline);
        
        // Return appropriate response
        if (defined('IS_PRODUCTION') && IS_PRODUCTION) {
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'error' => 'Internal server error'
            ]);
        } else {
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'error' => $errstr,
                'file' => $errfile,
                'line' => $errline
            ]);
        }
    }
}

// Set error handlers
set_exception_handler(['ErrorHandler', 'handleException']);
set_error_handler(['ErrorHandler', 'handleError']);

// Ensure errors are logged
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/../logs/errors.log');
?>
```

#### API Error Responses
Standardize API error responses:

```php
<?php
// api_helpers.php - API helper functions

/**
 * Send success response
 */
function sendSuccess($data = [], $message = 'Success', $code = 200) {
    http_response_code($code);
    echo json_encode([
        'success' => true,
        'message' => $message,
        'data' => $data
    ]);
}

/**
 * Send error response
 */
function sendError($message = 'Error', $code = 400, $data = []) {
    http_response_code($code);
    echo json_encode([
        'success' => false,
        'error' => $message,
        'data' => $data
    ]);
}

/**
 * Validate required fields
 */
function validateRequiredFields($data, $requiredFields) {
    $missingFields = [];
    
    foreach ($requiredFields as $field) {
        if (!isset($data[$field]) || empty($data[$field])) {
            $missingFields[] = $field;
        }
    }
    
    if (!empty($missingFields)) {
        return [
            'valid' => false,
            'error' => 'Missing required fields: ' . implode(', ', $missingFields)
        ];
    }
    
    return ['valid' => true];
}

/**
 * Validate numeric amount
 */
function validateAmount($amount, $min = 0, $max = PHP_FLOAT_MAX) {
    if (!is_numeric($amount)) {
        return [
            'valid' => false,
            'error' => 'Amount must be a number'
        ];
    }
    
    $amount = floatval($amount);
    
    if ($amount < $min) {
        return [
            'valid' => false,
            'error' => "Amount must be at least {$min}"
        ];
    }
    
    if ($amount > $max) {
        return [
            'valid' => false,
            'error' => "Amount must not exceed {$max}"
        ];
    }
    
    return ['valid' => true];
}
?>
```

### Frontend Error Handling

#### Enhanced JavaScript Error Handling
Improve error handling in JavaScript:

```javascript
// Enhanced error handling functions
function handleApiError(error, defaultMessage = 'An error occurred. Please try again.') {
    console.error('API Error:', error);
    
    // Check if it's a network error
    if (error instanceof TypeError && error.message.includes('fetch')) {
        return 'Network error. Please check your connection and try again.';
    }
    
    // Check if it's a JSON parsing error
    if (error instanceof SyntaxError) {
        return 'Server response error. Please try again later.';
    }
    
    // Return the default message
    return defaultMessage;
}

// Enhanced fetch wrapper with error handling
async function apiRequest(url, options = {}) {
    try {
        const response = await fetch(url, {
            ...options,
            headers: {
                'Content-Type': 'application/json',
                ...options.headers
            }
        });
        
        // Check if response is OK
        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            throw new Error(errorData.error || `HTTP ${response.status}: ${response.statusText}`);
        }
        
        return await response.json();
    } catch (error) {
        // Handle different types of errors
        if (error.name === 'AbortError') {
            throw new Error('Request timed out. Please try again.');
        }
        
        throw error;
    }
}

// Enhanced payment verification with better error handling
async function verifyPayment(txRef, paymentType) {
    try {
        const result = await apiRequest(CHAPA_CONFIG.baseUrl + 'verify-payment.php', {
            method: 'POST',
            body: JSON.stringify({
                tx_ref: txRef,
                payment_type: paymentType
            })
        });
        
        if (result.status === 'success') {
            console.log('Payment verified successfully:', result);
            
            // Add to payments table if exists
            if (document.getElementById('payments-table')) {
                addPaymentToTable({
                    date: new Date().toLocaleString(),
                    amount: result.data.amount + ' ETB',
                    type: paymentType,
                    tx_ref: txRef
                }, 'Completed');
            }
            
            return result;
        } else {
            throw new Error(result.error || 'Payment verification failed');
        }
    } catch (error) {
        const errorMessage = handleApiError(error, 'Unable to verify payment. Please contact support.');
        showPaymentMessage(`${paymentType}-error-message`, errorMessage, 'error');
        throw error;
    }
}

// Enhanced withdrawal processing with better error handling
async function processWithdrawal(amount, accountDetails) {
    try {
        // Show loading state
        toggleLoading('withdraw-btn', 'withdraw-spinner', true);
        showPaymentMessage('withdraw-info-message', 'Processing withdrawal request...', 'info');
        hidePaymentMessage('withdraw-error-message');
        hidePaymentMessage('withdraw-success-message');
        
        const result = await apiRequest(CHAPA_CONFIG.baseUrl + 'withdraw.php', {
            method: 'POST',
            body: JSON.stringify({
                amount: amount,
                account_details: accountDetails,
                payment_method: 'bank_transfer'
            })
        });
        
        // Hide loading
        toggleLoading('withdraw-btn', 'withdraw-spinner', false);
        hidePaymentMessage('withdraw-info-message');
        
        if (result.success) {
            showPaymentMessage('withdraw-success-message', result.message, 'success');
            
            // Reset form after success
            setTimeout(() => {
                document.getElementById('withdraw-amount').value = '200';
                document.getElementById('withdraw-account').value = '';
                hidePaymentMessage('withdraw-success-message');
            }, 5000);
            
            return result;
        } else {
            throw new Error(result.error || 'Withdrawal failed');
        }
    } catch (error) {
        // Hide loading
        toggleLoading('withdraw-btn', 'withdraw-spinner', false);
        hidePaymentMessage('withdraw-info-message');
        
        const errorMessage = handleApiError(error, 'Unable to process withdrawal. Please try again.');
        showPaymentMessage('withdraw-error-message', errorMessage, 'error');
        
        throw error;
    }
}
```

## User Feedback System

### Enhanced Feedback Messages
Improve the visual feedback system:

```css
/* Enhanced payment message styles */
.payment-message {
    padding: 15px;
    border-radius: 8px;
    margin: 15px 0;
    display: none;
    font-weight: 500;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    position: relative;
    padding-left: 50px;
}

.payment-message:before {
    content: "";
    position: absolute;
    left: 15px;
    top: 50%;
    transform: translateY(-50%);
    width: 20px;
    height: 20px;
    background-size: contain;
    background-repeat: no-repeat;
}

.payment-success {
    background-color: #d4edda;
    color: #155724;
    border: 1px solid #c3e6cb;
}

.payment-success:before {
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%2328a745'%3E%3Cpath d='M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z'/%3E%3C/svg%3E");
}

.payment-error {
    background-color: #f8d7da;
    color: #721c24;
    border: 1px solid #f5c6cb;
}

.payment-error:before {
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%23dc3545'%3E%3Cpath d='M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z'/%3E%3C/svg%3E");
}

.payment-info {
    background-color: #d1ecf1;
    color: #0c5460;
    border: 1px solid #bee5eb;
}

.payment-info:before {
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%2317a2b8'%3E%3Cpath d='M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z'/%3E%3C/svg%3E");
}

.payment-warning {
    background-color: #fff3cd;
    color: #856404;
    border: 1px solid #ffeaa7;
}

.payment-warning:before {
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%23ffc107'%3E%3Cpath d='M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z'/%3E%3C/svg%3E");
}

/* Enhanced spinner */
.spinner {
    display: none;
    width: 24px;
    height: 24px;
    border: 3px solid #f3f3f3;
    border-top: 3px solid #007bff;
    border-radius: 50%;
    animation: spin 1s linear infinite;
    margin: 0 auto;
}

@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}

/* Auto-dismiss messages */
.payment-message.auto-dismiss {
    animation: fadeInOut 5s forwards;
}

@keyframes fadeInOut {
    0% { opacity: 0; transform: translateY(-10px); }
    10% { opacity: 1; transform: translateY(0); }
    90% { opacity: 1; transform: translateY(0); }
    100% { opacity: 0; transform: translateY(-10px); }
}
```

### Enhanced JavaScript Feedback Functions
Improve the JavaScript feedback functions:

```javascript
// Enhanced showPaymentMessage function
function showPaymentMessage(elementId, message, type, autoDismiss = true) {
    const messageEl = document.getElementById(elementId);
    if (!messageEl) return;
    
    messageEl.textContent = message;
    messageEl.className = `payment-message payment-${type}`;
    
    // Add auto-dismiss class for success messages
    if (autoDismiss && type === 'success') {
        messageEl.classList.add('auto-dismiss');
    }
    
    messageEl.style.display = 'block';
    
    // Auto-hide after 5 seconds for success messages (unless auto-dismiss is used)
    if (autoDismiss && type === 'success' && !messageEl.classList.contains('auto-dismiss')) {
        setTimeout(() => {
            if (messageEl.style.display === 'block') {
                messageEl.style.display = 'none';
            }
        }, 5000);
    }
    
    // Auto-hide error messages after 10 seconds
    if (autoDismiss && type === 'error') {
        setTimeout(() => {
            if (messageEl.style.display === 'block') {
                messageEl.style.display = 'none';
            }
        }, 10000);
    }
}

// Enhanced toggleLoading function
function toggleLoading(buttonId, spinnerId, isLoading) {
    const button = document.getElementById(buttonId);
    const spinner = document.getElementById(spinnerId);
    
    if (!button || !spinner) return;
    
    if (isLoading) {
        button.disabled = true;
        button.style.opacity = '0.6';
        spinner.style.display = 'inline-block';
    } else {
        button.disabled = false;
        button.style.opacity = '1';
        spinner.style.display = 'none';
    }
}

// Toast notification system
function showToast(message, type = 'info', duration = 5000) {
    // Create toast container if it doesn't exist
    let toastContainer = document.getElementById('toast-container');
    if (!toastContainer) {
        toastContainer = document.createElement('div');
        toastContainer.id = 'toast-container';
        toastContainer.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
            display: flex;
            flex-direction: column;
            gap: 10px;
        `;
        document.body.appendChild(toastContainer);
    }
    
    // Create toast element
    const toast = document.createElement('div');
    toast.style.cssText = `
        padding: 12px 20px;
        border-radius: 4px;
        color: white;
        font-weight: 500;
        box-shadow: 0 2px 8px rgba(0,0,0,0.15);
        display: flex;
        align-items: center;
        gap: 8px;
        max-width: 300px;
        word-wrap: break-word;
    `;
    
    // Set background color based on type
    switch (type) {
        case 'success':
            toast.style.backgroundColor = '#28a745';
            break;
        case 'error':
            toast.style.backgroundColor = '#dc3545';
            break;
        case 'warning':
            toast.style.backgroundColor = '#ffc107';
            toast.style.color = '#212529';
            break;
        default:
            toast.style.backgroundColor = '#17a2b8';
    }
    
    toast.textContent = message;
    toastContainer.appendChild(toast);
    
    // Auto remove toast
    setTimeout(() => {
        toast.style.transition = 'opacity 0.3s, transform 0.3s';
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(100px)';
        setTimeout(() => {
            if (toast.parentNode) {
                toast.parentNode.removeChild(toast);
            }
        }, 300);
    }, duration);
}
```

## Logging and Monitoring

### Backend Logging
Implement comprehensive logging:

```php
<?php
// logger.php - Logging utility

class Logger {
    private static $logFile = __DIR__ . '/../logs/application.log';
    
    public static function log($level, $message, $context = []) {
        // Ensure log directory exists
        $logDir = dirname(self::$logFile);
        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }
        
        $timestamp = date('Y-m-d H:i:s');
        $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'unknown';
        $userId = $_SESSION['user_id'] ?? 'guest';
        
        $logEntry = [
            'timestamp' => $timestamp,
            'level' => strtoupper($level),
            'message' => $message,
            'ip' => $ip,
            'user_agent' => $userAgent,
            'user_id' => $userId,
            'context' => $context
        ];
        
        file_put_contents(
            self::$logFile, 
            json_encode($logEntry) . PHP_EOL, 
            FILE_APPEND | LOCK_EX
        );
    }
    
    public static function info($message, $context = []) {
        self::log('info', $message, $context);
    }
    
    public static function warning($message, $context = []) {
        self::log('warning', $message, $context);
    }
    
    public static function error($message, $context = []) {
        self::log('error', $message, $context);
    }
    
    public static function debug($message, $context = []) {
        if (!defined('IS_PRODUCTION') || !IS_PRODUCTION) {
            self::log('debug', $message, $context);
        }
    }
}
?>
```

## Error Recovery and Resilience

### Retry Mechanisms
Implement retry mechanisms for critical operations:

```javascript
// Retry utility function
async function retryOperation(operation, maxRetries = 3, delay = 1000) {
    let lastError;
    
    for (let i = 0; i <= maxRetries; i++) {
        try {
            return await operation();
        } catch (error) {
            lastError = error;
            
            // Don't retry on certain errors
            if (error.status === 400 || error.status === 401 || error.status === 403) {
                throw error;
            }
            
            // If this isn't the last retry, wait and try again
            if (i < maxRetries) {
                await new Promise(resolve => setTimeout(resolve, delay * Math.pow(2, i)));
            }
        }
    }
    
    throw lastError;
}

// Example usage with payment verification
async function verifyPaymentWithRetry(txRef, paymentType) {
    return retryOperation(
        () => verifyPayment(txRef, paymentType),
        3, // max retries
        1000 // initial delay
    );
}
```

## User Experience Improvements

### Progressive Feedback
Provide progressive feedback during long operations:

```javascript
// Progress indicator for long operations
function showProgress(message, progress = 0) {
    const progressContainer = document.getElementById('progress-container') || createProgressContainer();
    
    const messageEl = progressContainer.querySelector('.progress-message');
    const progressBar = progressContainer.querySelector('.progress-bar');
    
    messageEl.textContent = message;
    progressBar.style.width = progress + '%';
    progressContainer.style.display = 'block';
}

function hideProgress() {
    const progressContainer = document.getElementById('progress-container');
    if (progressContainer) {
        progressContainer.style.display = 'none';
    }
}

function createProgressContainer() {
    const container = document.createElement('div');
    container.id = 'progress-container';
    container.style.cssText = `
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: white;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 10000;
        min-width: 300px;
        text-align: center;
    `;
    
    container.innerHTML = `
        <div class="progress-message" style="margin-bottom: 10px;">Processing...</div>
        <div class="progress-bar-container" style="height: 10px; background: #e9ecef; border-radius: 5px; overflow: hidden;">
            <div class="progress-bar" style="height: 100%; background: #007bff; width: 0%; transition: width 0.3s;"></div>
        </div>
    `;
    
    document.body.appendChild(container);
    return container;
}
```

## Summary

This error handling and feedback system provides:

1. **Comprehensive Backend Error Handling**:
   - Global exception handling
   - Standardized API responses
   - Detailed logging
   - Environment-specific error messages

2. **Enhanced Frontend Error Handling**:
   - Network error detection
   - JSON parsing error handling
   - Retry mechanisms
   - User-friendly error messages

3. **Improved User Feedback**:
   - Visual feedback messages with icons
   - Auto-dismiss functionality
   - Toast notifications
   - Progress indicators

4. **Monitoring and Logging**:
   - Comprehensive logging system
   - Context-aware logging
   - Different log levels

5. **Resilience Features**:
   - Retry mechanisms for failed operations
   - Graceful degradation
   - User-friendly error recovery