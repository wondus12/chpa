# Running the Chapa Payment Application

## Current Setup

The application is now running on a Node.js server that serves the HTML interface and simulates API endpoints.

## How to Access the Application

1. The server is already running on http://localhost:8000
2. Open your web browser and navigate to http://localhost:8000
3. You should see the Chapa Banking App interface with options for:
   - Deposit
   - Withdraw
   - Withdrawal Request
   - Payments

## Features Available in Demo Mode

- View the user interface
- Simulate deposit transactions
- View transaction history
- Test different UI components

## Limitations of Current Setup

This is a simplified demonstration server that:
- Does not connect to a real database
- Does not process real payments
- Simulates API responses

## For Full Functionality

To run with full PHP and database functionality:

1. Install PHP and MySQL on your system
2. Set up a proper web server (Apache/Nginx) or use PHP's built-in server
3. Import the database schema from `database_setup.sql`
4. Configure the database connection in `config.php`

## Stopping the Server

To stop the server, press Ctrl+C in the terminal where it's running.

## Next Steps

1. Open your browser and go to http://localhost:8000
2. Try out the different features of the banking application
3. For production use, follow the complete setup instructions in HOW_TO_RUN.md