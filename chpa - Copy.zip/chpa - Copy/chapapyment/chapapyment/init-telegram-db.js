require('dotenv').config();
const sqlite3 = require('sqlite3').verbose();
const { open } = require('sqlite');

async function initDatabase() {
  let db;
  
  try {
    // Open database
    db = await open({
      filename: './chapa_telegram.db',
      driver: sqlite3.Database
    });
    
    console.log('Connected to SQLite database');
    
    // Create telegram_users table
    await db.exec(`
      CREATE TABLE IF NOT EXISTS telegram_users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        telegram_id INTEGER UNIQUE NOT NULL,
        username TEXT,
        first_name TEXT,
        last_name TEXT,
        balance DECIMAL(10, 2) DEFAULT 0.00,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);
    console.log('✓ telegram_users table created/verified');
    
    // Create telegram_transactions table
    await db.exec(`
      CREATE TABLE IF NOT EXISTS telegram_transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        telegram_user_id INTEGER NOT NULL,
        transaction_type TEXT NOT NULL,
        amount DECIMAL(10, 2) NOT NULL,
        status TEXT DEFAULT 'pending',
        tx_ref TEXT UNIQUE,
        chapa_tx_ref TEXT,
        payment_method TEXT,
        description TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);
    console.log('✓ telegram_transactions table created/verified');
    
    // Close connection
    await db.close();
    console.log('Database initialization completed successfully!');
    
  } catch (error) {
    console.error('Error initializing database:', error);
    
    if (db) {
      await db.close();
    }
    
    process.exit(1);
  }
}

// Run the initialization
initDatabase();