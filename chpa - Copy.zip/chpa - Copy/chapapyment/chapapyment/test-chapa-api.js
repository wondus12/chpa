require('dotenv').config();
const https = require('https');

// Test Chapa API directly
function testChapaAPI() {
  const payload = JSON.stringify({
    amount: "100",
    currency: "ETB",
    email: "test@gmail.com",
    first_name: "Test",
    last_name: "User",
    tx_ref: "test-" + Date.now(),
    callback_url: "https://webhook.site/test",
    return_url: "https://example.com/success",
    customization: {
      title: "Test Payment",
      description: "Testing Chapa API"
    }
  });

  const options = {
    hostname: 'api.chapa.co',
    port: 443,
    path: '/v1/transaction/initialize',
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${process.env.CHAPA_SECRET_KEY}`,
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(payload)
    }
  };

  console.log('Testing Chapa API with credentials:');
  console.log('Secret Key:', process.env.CHAPA_SECRET_KEY ? process.env.CHAPA_SECRET_KEY.substring(0, 20) + '...' : 'NOT SET');
  console.log('Public Key:', process.env.CHAPA_PUBLIC_KEY ? process.env.CHAPA_PUBLIC_KEY.substring(0, 20) + '...' : 'NOT SET');
  console.log('Payload:', payload);
  console.log('Options:', JSON.stringify(options, null, 2));

  const req = https.request(options, (res) => {
    let data = '';
    
    console.log('Response Status:', res.statusCode);
    console.log('Response Headers:', res.headers);
    
    res.on('data', (chunk) => {
      data += chunk;
    });
    
    res.on('end', () => {
      console.log('Raw Response:', data);
      
      try {
        const response = JSON.parse(data);
        console.log('Parsed Response:', JSON.stringify(response, null, 2));
        
        if (response.status === 'success') {
          console.log('✅ SUCCESS: Payment URL:', response.data.checkout_url);
        } else {
          console.log('❌ ERROR:', response.message || 'Unknown error');
        }
      } catch (error) {
        console.log('❌ JSON Parse Error:', error.message);
      }
    });
  });

  req.on('error', (error) => {
    console.log('❌ Request Error:', error.message);
  });

  req.write(payload);
  req.end();
}

// Run the test
testChapaAPI();
