require('dotenv').config();
const { Telegraf } = require('telegraf');
const LocalSession = require('telegraf-session-local');
const sqlite3 = require('sqlite3').verbose();
const { open } = require('sqlite');
const https = require('https');

// Chapa configuration
const CHAPA_CONFIG = {
  publicKey: process.env.CHAPA_PUBLIC_KEY || 'CHAPUBK_TEST-xxxxxxxxxxxxxxxxxxxx',
  secretKey: process.env.CHAPA_SECRET_KEY || 'CHASECK_TEST-xxxxxxxxxxxxxxxxxxxx',
  baseUrl: 'https://api.chapa.co/v1/'
};

// Validate required environment variables
if (!process.env.BOT_TOKEN) {
  console.error('Error: BOT_TOKEN is not set in .env file');
  process.exit(1);
}

if (!process.env.CHAPA_PUBLIC_KEY || !process.env.CHAPA_SECRET_KEY) {
  console.error('Error: Chapa API keys are not set in .env file');
  process.exit(1);
}

// Create bot instance
const bot = new Telegraf(process.env.BOT_TOKEN);

// Session middleware
const localSession = new LocalSession({ database: 'session_db.json' });
bot.use(localSession.middleware());

// Database connection
let db;

// Initialize database connection
async function initDatabase() {
  try {
    db = await open({
      filename: './chapa_telegram.db',
      driver: sqlite3.Database
    });
    
    console.log('Connected to SQLite database');
    
    // Create telegram_users table if it doesn't exist
    await db.exec(`
      CREATE TABLE IF NOT EXISTS telegram_users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        telegram_id INTEGER UNIQUE NOT NULL,
        username TEXT,
        first_name TEXT,
        last_name TEXT,
        balance DECIMAL(10, 2) DEFAULT 0.00,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);
    
    // Create telegram_transactions table if it doesn't exist
    await db.exec(`
      CREATE TABLE IF NOT EXISTS telegram_transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        telegram_user_id INTEGER NOT NULL,
        transaction_type TEXT NOT NULL,
        amount DECIMAL(10, 2) NOT NULL,
        status TEXT DEFAULT 'pending',
        tx_ref TEXT UNIQUE,
        chapa_tx_ref TEXT,
        payment_method TEXT,
        description TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);
    
    console.log('Database tables initialized');
  } catch (error) {
    console.error('Database initialization error:', error);
    process.exit(1);
  }
}

// Register or update user in database
async function registerUser(ctx) {
  const telegramId = ctx.from.id;
  const username = ctx.from.username || null;
  const firstName = ctx.from.first_name || '';
  const lastName = ctx.from.last_name || '';
  
  try {
    // Check if user exists
    const user = await db.get(
      'SELECT * FROM telegram_users WHERE telegram_id = ?',
      [telegramId]
    );
    
    if (!user) {
      // Create new user
      await db.run(
        'INSERT INTO telegram_users (telegram_id, username, first_name, last_name, balance) VALUES (?, ?, ?, ?, 0.00)',
        [telegramId, username, firstName, lastName]
      );
      console.log(`New user registered: ${telegramId}`);
    } else {
      // Update existing user info
      await db.run(
        'UPDATE telegram_users SET username = ?, first_name = ?, last_name = ?, updated_at = CURRENT_TIMESTAMP WHERE telegram_id = ?',
        [username, firstName, lastName, telegramId]
      );
    }
    
    return telegramId;
  } catch (error) {
    console.error('Error registering user:', error);
    throw error;
  }
}

// Get user balance
async function getUserBalance(telegramId) {
  try {
    const user = await db.get(
      'SELECT balance FROM telegram_users WHERE telegram_id = ?',
      [telegramId]
    );
    
    if (user) {
      return user.balance;
    }
    return 0;
  } catch (error) {
    console.error('Error getting user balance:', error);
    throw error;
  }
}

// Update user balance
async function updateUserBalance(telegramId, amount, transactionType) {
  try {
    if (transactionType === 'deposit') {
      await db.run(
        'UPDATE telegram_users SET balance = balance + ? WHERE telegram_id = ?',
        [amount, telegramId]
      );
    } else if (transactionType === 'withdrawal') {
      await db.run(
        'UPDATE telegram_users SET balance = balance - ? WHERE telegram_id = ?',
        [amount, telegramId]
      );
    }
  } catch (error) {
    console.error('Error updating user balance:', error);
    throw error;
  }
}

// Create transaction record
async function createTransaction(telegramId, transactionType, amount, txRef, paymentMethod, description) {
  try {
    await db.run(
      'INSERT INTO telegram_transactions (telegram_user_id, transaction_type, amount, tx_ref, payment_method, description) VALUES (?, ?, ?, ?, ?, ?)',
      [telegramId, transactionType, amount, txRef, paymentMethod, description]
    );
  } catch (error) {
    console.error('Error creating transaction:', error);
    throw error;
  }
}

// Generate unique transaction reference
function generateTxRef() {
  return 'tx-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9);
}

// Initialize Chapa payment
async function initializeChapaPayment(amount, txRef, userInfo) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify({
      amount: amount.toString(),
      currency: 'ETB',
      email: userInfo.email || `user${userInfo.telegram_id}@gmail.com`,
      first_name: userInfo.first_name || 'Telegram',
      last_name: userInfo.last_name || 'User',
      tx_ref: txRef,
      callback_url: 'https://your-domain.com/api/webhook.php',
      return_url: 'https://your-domain.com/success',
      customization: {
        title: 'Bot Deposit',
        description: `Deposit ${amount} ETB via Telegram Bot`
      }
    });

    const options = {
      hostname: 'api.chapa.co',
      port: 443,
      path: '/v1/transaction/initialize',
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${CHAPA_CONFIG.secretKey}`,
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(payload)
      }
    };

    const req = https.request(options, (res) => {
      let data = '';
      
      res.on('data', (chunk) => {
        data += chunk;
      });
      
      res.on('end', () => {
        try {
          console.log('Chapa API Response:', data);
          const response = JSON.parse(data);
          console.log('Parsed response:', response);
          
          if (response.status === 'success') {
            resolve(response.data.checkout_url);
          } else {
            console.log('Chapa API Error:', response);
            reject(new Error(JSON.stringify(response)));
          }
        } catch (error) {
          console.log('JSON Parse Error:', error);
          console.log('Raw response data:', data);
          reject(error);
        }
      });
    });

    req.on('error', (error) => {
      reject(error);
    });

    req.write(payload);
    req.end();
  });
}

// Start command
bot.start((ctx) => {
  ctx.reply('Welcome to Chapa Payment Bot! 🚀\n\nUse /help to see available commands.');
});

// Help command
bot.help((ctx) => {
  ctx.reply(
    '💳 Chapa Payment Bot Commands:\n\n' +
    '/start - Start the bot\n' +
    '/help - Show this help message\n' +
    '/balance - Check your balance\n' +
    '/deposit - Make a deposit\n' +
    '/withdraw - Request a withdrawal\n' +
    '/transactions - View recent transactions\n\n' +
    'For any issues, contact support.'
  );
});

// Balance command
bot.command('balance', async (ctx) => {
  try {
    await registerUser(ctx);
    const balance = await getUserBalance(ctx.from.id);
    ctx.reply(`💰 Your current balance: ${balance} ETB`);
  } catch (error) {
    console.error('Error in balance command:', error);
    ctx.reply('❌ Error retrieving balance. Please try again later.');
  }
});

// Deposit command
bot.command('deposit', async (ctx) => {
  try {
    await registerUser(ctx);
    ctx.reply(
      '📥 DEPOSIT\n\n' +
      'Please enter the amount you want to deposit (in ETB):\n\n' +
      'Minimum: 1 ETB\n' +
      'Maximum: 100,000 ETB\n\n' +
      'Or type /cancel to cancel this operation.'
    );
    
    // Set scene for amount input
    ctx.session = { ...ctx.session, awaitingDepositAmount: true };
  } catch (error) {
    console.error('Error in deposit command:', error);
    ctx.reply('❌ Error initiating deposit. Please try again later.');
  }
});

// Withdraw command
bot.command('withdraw', async (ctx) => {
  try {
    await registerUser(ctx);
    const balance = await getUserBalance(ctx.from.id);
    
    if (balance < 50) {
      ctx.reply('❌ Insufficient balance for withdrawal.\n\nMinimum withdrawal amount is 50 ETB.');
      return;
    }
    
    ctx.reply(
      '📤 WITHDRAWAL\n\n' +
      `Your current balance: ${balance} ETB\n\n` +
      'Please enter the amount you want to withdraw (in ETB):\n\n' +
      'Minimum: 50 ETB\n' +
      `Maximum: ${balance} ETB\n\n` +
      'Or type /cancel to cancel this operation.'
    );
    
    // Set scene for amount input
    ctx.session = { ...ctx.session, awaitingWithdrawalAmount: true };
  } catch (error) {
    console.error('Error in withdraw command:', error);
    ctx.reply('❌ Error initiating withdrawal. Please try again later.');
  }
});

// Transactions command
bot.command('transactions', async (ctx) => {
  try {
    await registerUser(ctx);
    
    // Get recent transactions
    const transactions = await db.all(
      'SELECT * FROM telegram_transactions WHERE telegram_user_id = ? ORDER BY created_at DESC LIMIT 10',
      [ctx.from.id]
    );
    
    if (transactions.length === 0) {
      ctx.reply('📋 You have no transactions yet.');
      return;
    }
    
    let message = '📋 Recent Transactions:\n\n';
    transactions.forEach((transaction, index) => {
      const date = new Date(transaction.created_at).toLocaleDateString();
      const type = transaction.transaction_type === 'deposit' ? '📥 Deposit' : '📤 Withdrawal';
      const status = transaction.status.charAt(0).toUpperCase() + transaction.status.slice(1);
      message += `${index + 1}. ${date} - ${type} - ${transaction.amount} ETB - ${status}\n`;
    });
    
    ctx.reply(message);
  } catch (error) {
    console.error('Error in transactions command:', error);
    ctx.reply('❌ Error retrieving transactions. Please try again later.');
  }
});

// Handle text messages (for amount input)
bot.on('text', async (ctx) => {
  const text = ctx.message.text;
  
  // Handle cancel command
  if (text === '/cancel') {
    ctx.session = { awaitingDepositAmount: false, awaitingWithdrawalAmount: false };
    ctx.reply('Operation cancelled.');
    return;
  }
  
  // Handle deposit amount input
  if (ctx.session && ctx.session.awaitingDepositAmount) {
    const amount = parseFloat(text);
    
    if (isNaN(amount) || amount < 1 || amount > 100000) {
      ctx.reply('❌ Invalid amount. Please enter a valid amount between 1 and 100,000 ETB.');
      return;
    }
    
    // Generate transaction reference
    const txRef = generateTxRef();
    
    try {
      // Get user info for Chapa payment
      const userInfo = {
        telegram_id: ctx.from.id,
        first_name: ctx.from.first_name || 'Telegram',
        last_name: ctx.from.last_name || 'User',
        email: `user${ctx.from.id}@gmail.com`
      };

      // Initialize Chapa payment
      const paymentLink = await initializeChapaPayment(amount, txRef, userInfo);
      
      // Create transaction record
      await createTransaction(ctx.from.id, 'deposit', amount, txRef, 'chapa', 'Telegram deposit');
      
      ctx.reply(
        `💳 DEPOSIT DETAILS\n\n` +
        `Amount: ${amount} ETB\n` +
        `Transaction ID: ${txRef}\n\n` +
        `Click the link below to complete your payment:\n` +
        `${paymentLink}\n\n` +
        `After payment, your balance will be updated automatically.\n\n` +
        `Type /cancel to cancel this operation.`
      );
    } catch (error) {
      console.error('Error initializing Chapa payment:', error);
      ctx.reply(
        `❌ Error creating payment link.\n\n` +
        `Please try again later or contact support.\n\n` +
        `Error: ${error.message}`
      );
    }
    
    // Reset session
    ctx.session = { awaitingDepositAmount: false };
    
    return;
  }
  
  // Handle withdrawal amount input
  if (ctx.session && ctx.session.awaitingWithdrawalAmount) {
    const amount = parseFloat(text);
    const balance = await getUserBalance(ctx.from.id);
    
    if (isNaN(amount) || amount < 50 || amount > balance) {
      ctx.reply(`❌ Invalid amount. Please enter a valid amount between 50 and ${balance} ETB.`);
      return;
    }
    
    // Generate transaction reference
    const txRef = generateTxRef();
    
    // Create transaction record
    await createTransaction(ctx.from.id, 'withdrawal', amount, txRef, 'bank_transfer', 'Telegram withdrawal');
    
    // Update user balance
    await updateUserBalance(ctx.from.id, amount, 'withdrawal');
    
    ctx.reply(
      `📤 WITHDRAWAL REQUEST\n\n` +
      `Amount: ${amount} ETB\n` +
      `Transaction ID: ${txRef}\n\n` +
      `✅ Withdrawal request submitted successfully!\n` +
      `Your balance has been updated.\n\n` +
      `The withdrawal will be processed within 24 hours.`
    );
    
    // Reset session
    ctx.session = { awaitingWithdrawalAmount: false };
    
    return;
  }
  
  // Default response for unrecognized text
  ctx.reply('I didn\'t understand that. Type /help to see available commands.');
});

// Error handling
bot.catch((err, ctx) => {
  console.error(`Error for ${ctx.updateType}`, err);
  ctx.reply('❌ An error occurred. Please try again later.');
});

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));

// Start the bot
async function startBot() {
  try {
    await initDatabase();
    await bot.launch();
    console.log('Telegram bot started successfully!');
    console.log('Bot username:', (await bot.telegram.getMe()).username);
  } catch (error) {
    console.error('Error starting bot:', error);
    process.exit(1);
  }
}

// Run the bot
startBot();