<?php
/**
 * Get Approval Secret Key for Chapa Dashboard Configuration
 * Run this script to get your approval secret key (max 25 characters for Chapa)
 */

// Set up CLI environment variables to avoid warnings
if (php_sapi_name() === 'cli') {
    $_SERVER['HTTP_HOST'] = 'localhost';
    $_SERVER['REQUEST_METHOD'] = 'GET';
    $_SERVER['REMOTE_ADDR'] = '127.0.0.1';
}

require_once __DIR__ . '/config.php';

echo "=== Chapa Approval Secret Key Generator ===\n\n";

// Simple approach: directly instantiate the secret generation logic
class CLITransferApproval {
    private function getApprovalSecretKey() {
        $keyFile = __DIR__ . '/.approval_secret';
        
        if (file_exists($keyFile)) {
            $existingKey = trim(file_get_contents($keyFile));
            // If existing key is too long, regenerate
            if (strlen($existingKey) > 25) {
                $secretKey = $this->generateShortSecretKey();
                file_put_contents($keyFile, $secretKey);
                chmod($keyFile, 0600);
                return $secretKey;
            }
            return $existingKey;
        }
        
        // Generate new secret key (max 25 characters)
        $secretKey = $this->generateShortSecretKey();
        file_put_contents($keyFile, $secretKey);
        chmod($keyFile, 0600); // Restrict access
        
        return $secretKey;
    }
    
    private function generateShortSecretKey() {
        // Generate 25-character alphanumeric key
        $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        $secretKey = '';
        for ($i = 0; $i < 25; $i++) {
            $secretKey .= $characters[random_int(0, strlen($characters) - 1)];
        }
        return $secretKey;
    }
    
    public function getApprovalSecret() {
        $secretKey = $this->getApprovalSecretKey();
        
        return [
            'success' => true,
            'approval_secret' => $secretKey,
            'length' => strlen($secretKey),
            'note' => 'Generated for Chapa dashboard (max 25 chars)'
        ];
    }
}

// Create CLI instance to avoid HTTP headers
$transferApproval = new CLITransferApproval();

// Get the secret
$secretData = $transferApproval->getApprovalSecret();

if ($secretData['success']) {
    echo "✅ Approval Secret Key Generated Successfully!\n\n";
    echo "📋 CHAPA DASHBOARD CONFIGURATION:\n";
    echo "================================\n\n";
    echo "Transfer Approval URL:\n";
    echo DOMAIN_URL . "/api/transfer-approval.php\n\n";
    echo "Approval Secret Key ({$secretData['length']} characters):\n";
    echo $secretData['approval_secret'] . "\n\n";
    echo "📝 Copy these values to your Chapa dashboard settings.\n\n";
    
    // Save to a text file for easy access
    $configText = "CHAPA DASHBOARD CONFIGURATION\n";
    $configText .= "============================\n\n";
    $configText .= "Transfer Approval URL:\n";
    $configText .= DOMAIN_URL . "/api/transfer-approval.php\n\n";
    $configText .= "Approval Secret Key ({$secretData['length']} characters):\n";
    $configText .= $secretData['approval_secret'] . "\n\n";
    $configText .= "Generated on: " . date('Y-m-d H:i:s') . "\n";
    
    file_put_contents(__DIR__ . '/chapa-config.txt', $configText);
    echo "💾 Configuration saved to: chapa-config.txt\n";
    
} else {
    echo "❌ Error: " . $secretData['error'] . "\n";
}

echo "\n🔧 Testing your endpoint:\n";
echo "curl \"" . DOMAIN_URL . "/api/transfer-approval.php?get_secret\"\n\n";

echo "🚀 Ready for Chapa Dashboard!\n";
echo "Your approval secret key: " . $secretData['approval_secret'] . " ({$secretData['length']} chars)\n";
?>
