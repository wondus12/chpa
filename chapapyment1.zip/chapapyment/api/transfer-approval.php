<?php
/**
 * Transfer Approval URL Endpoint
 * Enhanced transfer approval system with secret key validation
 * 
 * This endpoint handles transfer approval requests with additional security layers:
 * - Approval secret key validation
 * - Transfer amount limits
 * - Account verification
 * - Rate limiting protection
 * 
 * Usage: POST /api/transfer-approval.php
 * 
 * Response codes:
 * - 200 OK: Transfer approved
 * - 400 Bad Request: Invalid request or validation failed
 * - 401 Unauthorized: Invalid approval secret key
 * - 403 Forbidden: Transfer limits exceeded or blocked
 * - 429 Too Many Requests: Rate limit exceeded
 */

// Load configuration
require_once __DIR__ . '/../config.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Approval-Secret');

class TransferApproval {
    
    private $approvalSecretKey;
    private $maxTransferAmount;
    private $dailyTransferLimit;
    private $logFile;
    
    public function __construct() {
        // Generate or use existing approval secret key
        $this->approvalSecretKey = $this->getApprovalSecretKey();
        $this->maxTransferAmount = 1000000; // 1M ETB max per transaction
        $this->dailyTransferLimit = 5000000; // 5M ETB daily limit
        $this->logFile = __DIR__ . '/../logs/transfer-approval.log';
        
        // Ensure logs directory exists
        if (!is_dir(dirname($this->logFile))) {
            mkdir(dirname($this->logFile), 0755, true);
        }
    }
    
    /**
     * Generate or retrieve approval secret key
     */
    private function getApprovalSecretKey() {
        $keyFile = __DIR__ . '/../.approval_secret';
        
        if (file_exists($keyFile)) {
            $existingKey = trim(file_get_contents($keyFile));
            // If existing key is too long, regenerate for Chapa compatibility
            if (strlen($existingKey) > 25) {
                $secretKey = $this->generateShortSecretKey();
                file_put_contents($keyFile, $secretKey);
                chmod($keyFile, 0600);
                return $secretKey;
            }
            return $existingKey;
        }
        
        // Generate new secret key (max 25 characters for Chapa)
        $secretKey = $this->generateShortSecretKey();
        file_put_contents($keyFile, $secretKey);
        chmod($keyFile, 0600); // Restrict access
        
        return $secretKey;
    }
    
    /**
     * Generate 25-character alphanumeric secret key for Chapa compatibility
     */
    private function generateShortSecretKey() {
        $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        $secretKey = '';
        for ($i = 0; $i < 25; $i++) {
            $secretKey .= $characters[random_int(0, strlen($characters) - 1)];
        }
        return $secretKey;
    }
    
    /**
     * Handle transfer approval request
     */
    public function handleApprovalRequest() {
        try {
            // Rate limiting check
            if (!$this->checkRateLimit()) {
                http_response_code(429);
                return [
                    'success' => false,
                    'error' => 'Rate limit exceeded. Please try again later.',
                    'status' => 'rate_limited'
                ];
            }
            
            // Validate approval secret key
            if (!$this->validateApprovalSecret()) {
                http_response_code(401);
                return [
                    'success' => false,
                    'error' => 'Invalid approval secret key',
                    'status' => 'unauthorized'
                ];
            }
            
            // Get and validate request data
            $requestData = $this->getRequestData();
            if (!$requestData) {
                http_response_code(400);
                return [
                    'success' => false,
                    'error' => 'Invalid request data',
                    'status' => 'invalid_request'
                ];
            }
            
            // Validate transfer data
            $validation = $this->validateTransferData($requestData);
            if (!$validation['valid']) {
                http_response_code(400);
                return [
                    'success' => false,
                    'error' => $validation['error'],
                    'status' => 'validation_failed'
                ];
            }
            
            // Check transfer limits
            $limitCheck = $this->checkTransferLimits($requestData);
            if (!$limitCheck['allowed']) {
                http_response_code(403);
                return [
                    'success' => false,
                    'error' => $limitCheck['error'],
                    'status' => 'limit_exceeded'
                ];
            }
            
            // Process approval
            $approval = $this->processTransferApproval($requestData);
            
            // Log the approval
            $this->logApproval($requestData, $approval);
            
            return $approval;
            
        } catch (Exception $e) {
            $this->logError('Transfer approval error: ' . $e->getMessage());
            http_response_code(500);
            return [
                'success' => false,
                'error' => 'Internal server error',
                'status' => 'error'
            ];
        }
    }
    
    /**
     * Validate approval secret key from header
     */
    private function validateApprovalSecret() {
        $providedSecret = $_SERVER['HTTP_X_APPROVAL_SECRET'] ?? '';
        return hash_equals($this->approvalSecretKey, $providedSecret);
    }
    
    /**
     * Get and parse request data
     */
    private function getRequestData() {
        $payload = file_get_contents('php://input');
        $data = json_decode($payload, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            return false;
        }
        
        return $data;
    }
    
    /**
     * Validate transfer data structure and content
     */
    private function validateTransferData($data) {
        $required = ['transfer_id', 'amount', 'currency', 'sender_account', 'receiver_account', 'purpose'];
        
        foreach ($required as $field) {
            if (!isset($data[$field]) || empty($data[$field])) {
                return [
                    'valid' => false,
                    'error' => "Missing required field: {$field}"
                ];
            }
        }
        
        // Validate amount
        if (!is_numeric($data['amount']) || $data['amount'] <= 0) {
            return [
                'valid' => false,
                'error' => 'Invalid transfer amount'
            ];
        }
        
        // Validate currency
        if (!in_array(strtoupper($data['currency']), ['ETB', 'USD', 'EUR'])) {
            return [
                'valid' => false,
                'error' => 'Unsupported currency'
            ];
        }
        
        // Validate account formats (basic validation)
        if (!$this->isValidAccountNumber($data['sender_account']) || 
            !$this->isValidAccountNumber($data['receiver_account'])) {
            return [
                'valid' => false,
                'error' => 'Invalid account number format'
            ];
        }
        
        return ['valid' => true];
    }
    
    /**
     * Check transfer limits
     */
    private function checkTransferLimits($data) {
        $amount = floatval($data['amount']);
        
        // Check single transaction limit
        if ($amount > $this->maxTransferAmount) {
            return [
                'allowed' => false,
                'error' => "Transfer amount exceeds maximum limit of {$this->maxTransferAmount}"
            ];
        }
        
        // Check daily limit (simplified - in production, use database)
        $dailyTotal = $this->getDailyTransferTotal($data['sender_account']);
        if (($dailyTotal + $amount) > $this->dailyTransferLimit) {
            return [
                'allowed' => false,
                'error' => 'Daily transfer limit exceeded'
            ];
        }
        
        return ['allowed' => true];
    }
    
    /**
     * Process the transfer approval
     */
    private function processTransferApproval($data) {
        // Generate approval token
        $approvalToken = $this->generateApprovalToken($data);
        
        // In a real implementation, you would:
        // 1. Store the approval in database
        // 2. Send notification to relevant parties
        // 3. Update account balances or create pending transaction
        
        return [
            'success' => true,
            'status' => 'approved',
            'approval_token' => $approvalToken,
            'transfer_id' => $data['transfer_id'],
            'approved_amount' => $data['amount'],
            'currency' => $data['currency'],
            'approval_time' => date('Y-m-d H:i:s'),
            'expires_at' => date('Y-m-d H:i:s', strtotime('+1 hour'))
        ];
    }
    
    /**
     * Generate approval token
     */
    private function generateApprovalToken($data) {
        $tokenData = [
            'transfer_id' => $data['transfer_id'],
            'amount' => $data['amount'],
            'timestamp' => time(),
            'secret' => $this->approvalSecretKey
        ];
        
        return hash('sha256', json_encode($tokenData));
    }
    
    /**
     * Basic account number validation
     */
    private function isValidAccountNumber($account) {
        // Basic validation - adjust based on your bank's account format
        return preg_match('/^[0-9]{10,20}$/', $account);
    }
    
    /**
     * Get daily transfer total for an account (simplified)
     */
    private function getDailyTransferTotal($account) {
        // In production, query database for today's transfers
        // For now, return 0 as placeholder
        return 0;
    }
    
    /**
     * Rate limiting check
     */
    private function checkRateLimit() {
        $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        $rateLimitFile = __DIR__ . '/../logs/rate_limit_' . md5($ip) . '.json';
        
        $now = time();
        $window = 300; // 5 minutes
        $maxRequests = 10;
        
        if (file_exists($rateLimitFile)) {
            $data = json_decode(file_get_contents($rateLimitFile), true);
            
            // Clean old entries
            $data['requests'] = array_filter($data['requests'], function($timestamp) use ($now, $window) {
                return ($now - $timestamp) < $window;
            });
            
            if (count($data['requests']) >= $maxRequests) {
                return false;
            }
            
            $data['requests'][] = $now;
        } else {
            $data = ['requests' => [$now]];
        }
        
        file_put_contents($rateLimitFile, json_encode($data));
        return true;
    }
    
    /**
     * Log approval activity
     */
    private function logApproval($requestData, $approval) {
        $logEntry = [
            'timestamp' => date('Y-m-d H:i:s'),
            'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
            'transfer_id' => $requestData['transfer_id'],
            'amount' => $requestData['amount'],
            'currency' => $requestData['currency'],
            'status' => $approval['status'],
            'approval_token' => $approval['approval_token'] ?? null
        ];
        
        file_put_contents($this->logFile, json_encode($logEntry) . PHP_EOL, FILE_APPEND | LOCK_EX);
    }
    
    /**
     * Log errors
     */
    private function logError($message) {
        $logEntry = [
            'timestamp' => date('Y-m-d H:i:s'),
            'level' => 'ERROR',
            'message' => $message,
            'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown'
        ];
        
        file_put_contents($this->logFile, json_encode($logEntry) . PHP_EOL, FILE_APPEND | LOCK_EX);
    }
    
    /**
     * Get approval secret key for client use
     */
    public function getApprovalSecret() {
        // Only return in development mode
        if (!IS_PRODUCTION) {
            return [
                'success' => true,
                'approval_secret' => $this->approvalSecretKey,
                'note' => 'This endpoint is only available in development mode'
            ];
        }
        
        http_response_code(404);
        return [
            'success' => false,
            'error' => 'Not found'
        ];
    }
}

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Initialize the transfer approval handler
$transferApproval = new TransferApproval();

// Handle different request methods
switch ($_SERVER['REQUEST_METHOD']) {
    case 'POST':
        $result = $transferApproval->handleApprovalRequest();
        echo json_encode($result);
        break;
        
    case 'GET':
        // Development endpoint to get approval secret
        if (isset($_GET['get_secret'])) {
            $result = $transferApproval->getApprovalSecret();
            echo json_encode($result);
        } else {
            http_response_code(405);
            echo json_encode([
                'success' => false,
                'error' => 'Method not allowed'
            ]);
        }
        break;
        
    default:
        http_response_code(405);
        echo json_encode([
            'success' => false,
            'error' => 'Method not allowed'
        ]);
        break;
}
?>
