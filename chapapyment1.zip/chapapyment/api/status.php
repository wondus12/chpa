<?php
/**
 * API Status Check
 * Shows the status of all API endpoints
 */

header('Content-Type: application/json');

$status = [
    'server' => [
        'php_version' => PHP_VERSION,
        'server_time' => date('Y-m-d H:i:s'),
        'timezone' => date_default_timezone_get(),
        'memory_usage' => memory_get_usage(true),
        'status' => 'running'
    ],
    'chapa' => [
        'test_mode' => true,
        'public_key' => 'CHAPUBK_TEST-v8gO0BwmSBFgAUpaMktUcwfm3YDCzA',
        'secret_key_configured' => defined('CHAPA_SECRET_KEY') ? 'Yes' : 'No',
        'webhook_configured' => file_exists(__DIR__ . '/webhook.php') ? 'Yes' : 'No'
    ],
    'endpoints' => [
        'verify_payment' => [
            'url' => '/api/verify-payment.php',
            'method' => 'POST',
            'status' => file_exists(__DIR__ . '/verify-payment.php') ? 'Available' : 'Missing'
        ],
        'webhook' => [
            'url' => '/api/webhook.php',
            'method' => 'POST',
            'status' => file_exists(__DIR__ . '/webhook.php') ? 'Available' : 'Missing'
        ]
    ],
    'logs' => [
        'transactions' => [
            'file' => '../logs/transactions.log',
            'exists' => file_exists(__DIR__ . '/../logs/transactions.log'),
            'size' => file_exists(__DIR__ . '/../logs/transactions.log') ? 
                     filesize(__DIR__ . '/../logs/transactions.log') : 0
        ],
        'webhooks' => [
            'file' => '../logs/webhooks.log',
            'exists' => file_exists(__DIR__ . '/../logs/webhooks.log'),
            'size' => file_exists(__DIR__ . '/../logs/webhooks.log') ? 
                     filesize(__DIR__ . '/../logs/webhooks.log') : 0
        ]
    ],
    'test_endpoints' => [
        'verify_test' => [
            'description' => 'Test payment verification',
            'curl_example' => 'curl -X POST ' . $_SERVER['HTTP_HOST'] . '/api/verify-payment.php -H "Content-Type: application/json" -d \'{"tx_ref":"test-123","simulate":true}\''
        ]
    ]
];

// If requested as HTML, show formatted output
if (isset($_GET['format']) && $_GET['format'] === 'html') {
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <title>API Status</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            .status-good { color: #28a745; }
            .status-warning { color: #ffc107; }
            .status-error { color: #dc3545; }
            .section { margin: 20px 0; padding: 15px; border: 1px solid #ddd; border-radius: 5px; }
            pre { background: #f8f9fa; padding: 10px; border-radius: 3px; overflow-x: auto; }
        </style>
    </head>
    <body>
        <h1>🔧 Chapa Banking App - API Status</h1>
        
        <div class="section">
            <h2>Server Status</h2>
            <p><strong>PHP Version:</strong> <?php echo $status['server']['php_version']; ?></p>
            <p><strong>Server Time:</strong> <?php echo $status['server']['server_time']; ?></p>
            <p><strong>Status:</strong> <span class="status-good">✅ Running</span></p>
        </div>
        
        <div class="section">
            <h2>Chapa Configuration</h2>
            <p><strong>Test Mode:</strong> <span class="status-good">✅ Enabled</span></p>
            <p><strong>Public Key:</strong> <?php echo $status['chapa']['public_key']; ?></p>
            <p><strong>Secret Key:</strong> <span class="status-good">✅ Configured</span></p>
        </div>
        
        <div class="section">
            <h2>API Endpoints</h2>
            <?php foreach ($status['endpoints'] as $name => $endpoint): ?>
                <p><strong><?php echo ucfirst(str_replace('_', ' ', $name)); ?>:</strong> 
                   <span class="status-good">✅ <?php echo $endpoint['status']; ?></span>
                   <code><?php echo $endpoint['url']; ?></code>
                </p>
            <?php endforeach; ?>
        </div>
        
        <div class="section">
            <h2>Test Commands</h2>
            <h3>Test Payment Verification:</h3>
            <pre><?php echo $status['test_endpoints']['verify_test']['curl_example']; ?></pre>
            
            <h3>Test in Browser:</h3>
            <p><a href="../test-cases.html">Open Test Suite</a></p>
            <p><a href="../chapa-integrated-banking-app.html">Open Banking App</a></p>
        </div>
        
        <div class="section">
            <h2>Quick Test</h2>
            <button onclick="testAPI()">Test Payment Verification API</button>
            <div id="test-result"></div>
        </div>
        
        <script>
        async function testAPI() {
            const resultDiv = document.getElementById('test-result');
            resultDiv.innerHTML = 'Testing...';
            
            try {
                const response = await fetch('/api/verify-payment.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ tx_ref: 'test-' + Date.now(), simulate: true })
                });
                
                const result = await response.json();
                resultDiv.innerHTML = '<pre>' + JSON.stringify(result, null, 2) + '</pre>';
            } catch (error) {
                resultDiv.innerHTML = '<p style="color: red;">Error: ' + error.message + '</p>';
            }
        }
        </script>
    </body>
    </html>
    <?php
} else {
    echo json_encode($status, JSON_PRETTY_PRINT);
}
?>