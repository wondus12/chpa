# Chapa Payment Server-Side Verification Setup

## Overview
This document provides instructions for setting up server-side payment verification for your Chapa integration. **CRITICAL**: Never expose your secret key in client-side code.

## Required Credentials
```
Public Key: CHAPUBK_TEST-v8gO0BwmSBFgAUpaMktUcwfm3YDCzA
Secret Key: CHASECK_TEST-IZJ1Slg3nI6ivT5GlGbzv6rTIzbk3lJE (SERVER-SIDE ONLY)
Encryption Key: XpK4ELIzAAoFm3OPzpRCOxNi
Secret Hash: chapapayment
```

## 1. PHP Server Implementation

### Install Dependencies
```bash
composer require guzzlehttp/guzzle
```

### Create Payment Verification Endpoint
```php
<?php
// payment-verify.php

require_once 'vendor/autoload.php';

use GuzzleHttp\Client;

class ChapaVerification {
    private $secretKey = 'CHASECK_TEST-IZJ1Slg3nI6ivT5GlGbzv6rTIzbk3lJE';
    private $secretHash = 'chapapayment';
    private $baseUrl = 'https://api.chapa.co/v1';
    
    public function verifyPayment($txRef) {
        $client = new Client();
        
        try {
            $response = $client->get($this->baseUrl . '/transaction/verify/' . $txRef, [
                'headers' => [
                    'Authorization' => 'Bearer ' . $this->secretKey,
                    'Content-Type' => 'application/json'
                ]
            ]);
            
            $data = json_decode($response->getBody(), true);
            
            return [
                'success' => true,
                'status' => $data['status'],
                'data' => $data['data']
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
    
    public function handleWebhook($payload, $signature) {
        // Verify webhook signature
        $expectedSignature = hash_hmac('sha256', $payload, $this->secretHash);
        
        if (!hash_equals($expectedSignature, $signature)) {
            return ['success' => false, 'error' => 'Invalid signature'];
        }
        
        $data = json_decode($payload, true);
        
        // Process the webhook data
        return $this->processWebhookData($data);
    }
    
    private function processWebhookData($data) {
        // Update your database with payment status
        // Send notifications to users
        // Update account balances
        
        return ['success' => true, 'processed' => true];
    }
}

// Handle verification request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $txRef = $input['tx_ref'] ?? '';
    
    if (empty($txRef)) {
        http_response_code(400);
        echo json_encode(['error' => 'Transaction reference required']);
        exit;
    }
    
    $verifier = new ChapaVerification();
    $result = $verifier->verifyPayment($txRef);
    
    header('Content-Type: application/json');
    echo json_encode($result);
}

// Handle webhook
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_SERVER['REQUEST_URI'] === '/webhook/chapa') {
    $payload = file_get_contents('php://input');
    $signature = $_SERVER['HTTP_X_CHAPA_SIGNATURE'] ?? '';
    
    $verifier = new ChapaVerification();
    $result = $verifier->handleWebhook($payload, $signature);
    
    header('Content-Type: application/json');
    echo json_encode($result);
}
?>
```

## 2. Node.js Server Implementation

### Install Dependencies
```bash
npm install express axios crypto
```

### Create Server
```javascript
// server.js
const express = require('express');
const axios = require('axios');
const crypto = require('crypto');

const app = express();
app.use(express.json());

const CHAPA_CONFIG = {
    secretKey: 'CHASECK_TEST-IZJ1Slg3nI6ivT5GlGbzv6rTIzbk3lJE',
    secretHash: 'chapapayment',
    baseUrl: 'https://api.chapa.co/v1'
};

// Verify payment endpoint
app.post('/api/verify-payment', async (req, res) => {
    const { tx_ref } = req.body;
    
    if (!tx_ref) {
        return res.status(400).json({ error: 'Transaction reference required' });
    }
    
    try {
        const response = await axios.get(
            `${CHAPA_CONFIG.baseUrl}/transaction/verify/${tx_ref}`,
            {
                headers: {
                    'Authorization': `Bearer ${CHAPA_CONFIG.secretKey}`,
                    'Content-Type': 'application/json'
                }
            }
        );
        
        const { data } = response.data;
        
        // Update your database here
        await updatePaymentStatus(tx_ref, data.status, data);
        
        res.json({
            success: true,
            status: data.status,
            data: data
        });
        
    } catch (error) {
        console.error('Verification error:', error);
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// Webhook endpoint
app.post('/webhook/chapa', (req, res) => {
    const signature = req.headers['x-chapa-signature'];
    const payload = JSON.stringify(req.body);
    
    // Verify signature
    const expectedSignature = crypto
        .createHmac('sha256', CHAPA_CONFIG.secretHash)
        .update(payload)
        .digest('hex');
    
    if (signature !== expectedSignature) {
        return res.status(401).json({ error: 'Invalid signature' });
    }
    
    // Process webhook
    processWebhook(req.body);
    
    res.json({ success: true });
});

async function updatePaymentStatus(txRef, status, data) {
    // Update your database
    console.log(`Updating payment ${txRef} with status ${status}`);
}

function processWebhook(data) {
    // Handle webhook data
    console.log('Processing webhook:', data);
}

app.listen(3000, () => {
    console.log('Server running on port 3000');
});
```

## 3. Database Schema

### MySQL Schema
```sql
CREATE TABLE payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tx_ref VARCHAR(255) UNIQUE NOT NULL,
    user_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    currency VARCHAR(3) DEFAULT 'ETB',
    status ENUM('pending', 'success', 'failed') DEFAULT 'pending',
    payment_type ENUM('deposit', 'withdraw') NOT NULL,
    chapa_reference VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_user_id (user_id),
    INDEX idx_status (status),
    INDEX idx_tx_ref (tx_ref)
);

CREATE TABLE webhook_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tx_ref VARCHAR(255),
    payload JSON,
    signature VARCHAR(255),
    processed BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

## 4. Security Best Practices

### Environment Variables
```bash
# .env file
CHAPA_SECRET_KEY=CHASECK_TEST-IZJ1Slg3nI6ivT5GlGbzv6rTIzbk3lJE
CHAPA_SECRET_HASH=chapapayment
CHAPA_PUBLIC_KEY=CHAPUBK_TEST-v8gO0BwmSBFgAUpaMktUcwfm3YDCzA
```

### Security Checklist
- ✅ Never expose secret key in client-side code
- ✅ Always verify webhook signatures
- ✅ Use HTTPS for all API endpoints
- ✅ Implement rate limiting
- ✅ Log all transactions for audit
- ✅ Validate all input data
- ✅ Use environment variables for secrets

## 5. Frontend Integration

### Update your HTML to use server verification
```javascript
// Replace the client-side verification with server call
async function verifyPayment(txRef, paymentType) {
    try {
        const response = await fetch('/api/verify-payment', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ tx_ref: txRef })
        });
        
        const result = await response.json();
        
        if (result.success && result.status === 'success') {
            showPaymentMessage(`${paymentType}-message`, 
                `Payment verified successfully! ${currentPayment.amount} ETB has been processed.`, 
                'success'
            );
            addPaymentToTable(currentPayment, 'Completed');
        } else {
            showPaymentMessage(`${paymentType}-message`, 
                'Payment verification failed. Please contact support.', 
                'error'
            );
            addPaymentToTable(currentPayment, 'Failed');
        }
        
    } catch (error) {
        console.error('Verification error:', error);
        showPaymentMessage(`${paymentType}-message`, 
            'Payment verification failed. Please contact support.', 
            'error'
        );
    }
}
```

## 6. Testing

### Test Cases
1. **Successful Payment**: Test with valid amount and credentials
2. **Failed Payment**: Test with insufficient funds
3. **Network Issues**: Test with poor connectivity
4. **Invalid Amounts**: Test with amounts outside limits
5. **Webhook Verification**: Test webhook signature validation
6. **Duplicate Transactions**: Test duplicate tx_ref handling

### Test Commands
```bash
# Test verification endpoint
curl -X POST http://localhost:3000/api/verify-payment \
  -H "Content-Type: application/json" \
  -d '{"tx_ref":"test-tx-ref"}'

# Test webhook endpoint
curl -X POST http://localhost:3000/webhook/chapa \
  -H "Content-Type: application/json" \
  -H "X-Chapa-Signature: your-signature" \
  -d '{"event":"payment.success","data":{"tx_ref":"test-ref"}}'
```

## 7. Production Deployment

### Environment Setup
1. Replace test credentials with production keys
2. Update base URLs to production endpoints
3. Configure SSL certificates
4. Set up monitoring and logging
5. Configure backup and recovery

### Monitoring
- Set up alerts for failed payments
- Monitor webhook delivery
- Track payment success rates
- Log all security events

## Support
For issues with Chapa integration, contact:
- Chapa Support: support@chapa.co
- Documentation: https://developer.chapa.co