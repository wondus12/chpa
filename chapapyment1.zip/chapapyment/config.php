<?php
/**
 * Configuration file for bochboch.com Chapa Banking App
 * Update these settings for your production environment
 */

// Environment Detection
$isProduction = $_SERVER['HTTP_HOST'] === 'bochboch.com' || $_SERVER['HTTP_HOST'] === 'www.bochboch.com';
$isLocal = in_array($_SERVER['HTTP_HOST'], ['localhost', '127.0.0.1']) || strpos($_SERVER['HTTP_HOST'], 'localhost:') === 0;

// Domain Configuration
define('DOMAIN_URL', $isProduction ? 'https://bochboch.com' : 'http://' . $_SERVER['HTTP_HOST']);
define('IS_PRODUCTION', $isProduction);
define('IS_LOCAL', $isLocal);

// Chapa Configuration
if ($isProduction) {
    // Production Chapa Keys (replace with your actual production keys)
    define('CHAPA_PUBLIC_KEY', 'CHAPUBK_LIVE-your-production-public-key');
    define('CHAPA_SECRET_KEY', 'CHASECK_LIVE-your-production-secret-key');
    define('CHAPA_SECRET_HASH', 'your-production-secret-hash');
    define('CHAPA_TEST_MODE', false);
} else {
    // Test/Development Chapa Keys
    define('CHAPA_PUBLIC_KEY', 'CHAPUBK_TEST-v8gO0BwmSBFgAUpaMktUcwfm3YDCzA');
    define('CHAPA_SECRET_KEY', 'CHASECK_TEST-IZJ1Slg3nI6ivT5GlGbzv6rTIzbk3lJE');
    define('CHAPA_SECRET_HASH', 'chapapayment');
    define('CHAPA_TEST_MODE', true);
}

// API Configuration
define('CHAPA_BASE_URL', 'https://api.chapa.co/v1');

// Callback URLs
define('CALLBACK_URL', DOMAIN_URL . '/api/webhook.php');
define('RETURN_URL', DOMAIN_URL . '/payment/success');
define('CANCEL_URL', DOMAIN_URL . '/payment/cancel');

// Database Configuration (for future use)
if ($isProduction) {
    define('DB_HOST', 'localhost');
    define('DB_NAME', 'bochboch_banking');
    define('DB_USER', 'your_db_user');
    define('DB_PASS', 'your_secure_password');
} else {
    define('DB_HOST', 'www.bochboch.com');
    define('DB_NAME', 'bochboec_localhost');
    define('DB_USER', 'bochboec_root');
    define('DB_PASS', '1234%Wondu1234%Wondu');
}

// Security Settings
define('ENABLE_LOGGING', true);
define('LOG_DIRECTORY', __DIR__ . '/logs');
define('MAX_LOG_SIZE', 10 * 1024 * 1024); // 10MB

// Payment Limits
define('MIN_DEPOSIT_AMOUNT', 1);
define('MAX_DEPOSIT_AMOUNT', 100000);
define('MIN_WITHDRAW_AMOUNT', 50);
define('MAX_WITHDRAW_AMOUNT', 50000);

// Rate Limiting
define('MAX_REQUESTS_PER_MINUTE', 60);
define('MAX_PAYMENTS_PER_HOUR', 10);

// Email Configuration (for notifications)
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USER', 'support@bochboch.com');
define('SMTP_PASS', '1234%Wondu1234%Wondu1234%Wondu');
define('FROM_EMAIL', 'support@bochboch.com');
define('FROM_NAME', 'BochBoch Banking');

// Admin Configuration
define('ADMIN_EMAIL', 'admin@bochboch.com');
define('SUPPORT_EMAIL', 'support@bochboch.com');

// Feature Flags
define('ENABLE_WEBHOOKS', true);
define('ENABLE_EMAIL_NOTIFICATIONS', true); // Enable when email is configured
define('ENABLE_SMS_NOTIFICATIONS', true);   // Enable when SMS is configured
define('ENABLE_FRAUD_DETECTION', true);

// Utility Functions
function getConfig($key, $default = null) {
    return defined($key) ? constant($key) : $default;
}

function isProduction() {
    return IS_PRODUCTION;
}

function isTestMode() {
    return CHAPA_TEST_MODE;
}

function getDomainUrl() {
    return DOMAIN_URL;
}

function getChapaConfig() {
    return [
        'public_key' => CHAPA_PUBLIC_KEY,
        'secret_key' => CHAPA_SECRET_KEY,
        'secret_hash' => CHAPA_SECRET_HASH,
        'base_url' => CHAPA_BASE_URL,
        'test_mode' => CHAPA_TEST_MODE,
        'callback_url' => CALLBACK_URL,
        'return_url' => RETURN_URL,
        'cancel_url' => CANCEL_URL
    ];
}

// Initialize logs directory
if (ENABLE_LOGGING && !is_dir(LOG_DIRECTORY)) {
    mkdir(LOG_DIRECTORY, 0755, true);
}

// Display configuration info (only in development)
if (!$isProduction && isset($_GET['debug']) && $_GET['debug'] === 'config') {
    header('Content-Type: application/json');
    echo json_encode([
        'environment' => $isProduction ? 'production' : 'development',
        'domain' => DOMAIN_URL,
        'chapa_test_mode' => CHAPA_TEST_MODE,
        'public_key' => CHAPA_PUBLIC_KEY,
        'logging_enabled' => ENABLE_LOGGING,
        'features' => [
            'webhooks' => ENABLE_WEBHOOKS,
            'email_notifications' => ENABLE_EMAIL_NOTIFICATIONS,
            'fraud_detection' => ENABLE_FRAUD_DETECTION
        ]
    ], JSON_PRETTY_PRINT);
    exit;
}
?>