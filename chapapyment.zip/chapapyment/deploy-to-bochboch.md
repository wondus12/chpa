# Deploy Chapa Banking App to bochboch.com

## 🌐 **Domain Deployment Guide**

Your Chapa integration is already configured for `http://bochboch.com/`. Here's how to deploy it to your live domain.

## 📋 **Pre-Deployment Checklist**

### ✅ **Files Ready for Upload:**
- `index.php` - Main landing page
- `chapa-integrated-banking-app.html` - Banking application
- `test-cases.html` - Testing suite
- `api/verify-payment.php` - Payment verification API
- `api/webhook.php` - Webhook handler
- `api/status.php` - System status
- `chapa-payment-handler.js` - Payment logic
- `server-verification-setup.md` - Documentation

### ✅ **Domain Configuration:**
- Domain: `http://bochboch.com/`
- Public Key: `CHAPUBK_TEST-v8gO0BwmSBFgAUpaMktUcwfm3YDCzA`
- Test Mode: Enabled (switch to production keys when ready)

## 🚀 **Deployment Methods**

### **Method 1: FTP/SFTP Upload**
```bash
# Upload all files to your web server root directory
# Typically: /public_html/ or /www/ or /htdocs/

# File structure on server:
bochboch.com/
├── index.php
├── chapa-integrated-banking-app.html
├── test-cases.html
├── chapa-payment-handler.js
├── api/
│   ├── verify-payment.php
│   ├── webhook.php
│   └── status.php
└── logs/ (will be created automatically)
```

### **Method 2: cPanel File Manager**
1. Login to your cPanel
2. Open File Manager
3. Navigate to `public_html/`
4. Upload all files maintaining the directory structure
5. Set permissions for `logs/` directory to 755

### **Method 3: Git Deployment**
```bash
# If your server supports Git
git clone your-repository
# Or upload files via Git push
```

## 🔧 **Server Configuration**

### **PHP Requirements:**
- PHP 7.4 or higher
- cURL extension enabled
- JSON extension enabled
- File write permissions for logs

### **Apache .htaccess (Optional):**
```apache
# Create .htaccess file for better security and routing
RewriteEngine On

# Redirect to HTTPS (recommended for production)
# RewriteCond %{HTTPS} off
# RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]

# API routing
RewriteRule ^api/(.*)$ api/$1 [L]

# Security headers
Header always set X-Content-Type-Options nosniff
Header always set X-Frame-Options DENY
Header always set X-XSS-Protection "1; mode=block"

# Cache static files
<FilesMatch "\.(css|js|png|jpg|jpeg|gif|ico|svg)$">
    ExpiresActive On
    ExpiresDefault "access plus 1 month"
</FilesMatch>
```

## 🔐 **Security Configuration**

### **Environment Variables (Recommended):**
Create `.env` file (keep this secure):
```env
CHAPA_PUBLIC_KEY=CHAPUBK_TEST-v8gO0BwmSBFgAUpaMktUcwfm3YDCzA
CHAPA_SECRET_KEY=CHASECK_TEST-IZJ1Slg3nI6ivT5GlGbzv6rTIzbk3lJE
CHAPA_SECRET_HASH=chapapayment
CHAPA_BASE_URL=https://api.chapa.co/v1
DOMAIN_URL=http://bochboch.com
```

### **Update PHP Files to Use Environment:**
```php
// Add to top of api files
if (file_exists(__DIR__ . '/../.env')) {
    $env = parse_ini_file(__DIR__ . '/../.env');
    define('CHAPA_SECRET_KEY', $env['CHAPA_SECRET_KEY']);
    define('CHAPA_SECRET_HASH', $env['CHAPA_SECRET_HASH']);
}
```

## 🌐 **DNS and Domain Setup**

### **Verify Domain Points to Server:**
```bash
# Check if domain resolves to your server
nslookup bochboch.com
ping bochboch.com
```

### **SSL Certificate (Highly Recommended):**
```bash
# If using Let's Encrypt
certbot --apache -d bochboch.com -d www.bochboch.com

# Or through cPanel SSL/TLS section
```

## 📊 **Post-Deployment Testing**

### **1. Test Basic Access:**
- Visit: `http://bochboch.com/`
- Should show welcome page with links

### **2. Test Banking App:**
- Visit: `http://bochboch.com/chapa-integrated-banking-app.html`
- Try deposit with amount: 100 ETB
- Check if Chapa modal opens

### **3. Test API Endpoints:**
```bash
# Test payment verification API
curl -X POST http://bochboch.com/api/verify-payment.php \
  -H "Content-Type: application/json" \
  -d '{"tx_ref":"test-123","simulate":true}'

# Check API status
curl http://bochboch.com/api/status.php
```

### **4. Test Suite:**
- Visit: `http://bochboch.com/test-cases.html`
- Run all test cases
- Verify results

## 🔄 **Chapa Dashboard Configuration**

### **Update Chapa Settings:**
1. Login to Chapa Dashboard
2. Go to Settings → Webhooks
3. Set webhook URL: `http://bochboch.com/api/webhook.php`
4. Set callback URL: `http://bochboch.com/payment/callback`
5. Set return URL: `http://bochboch.com/payment/success`

### **Domain Verification:**
- Add `bochboch.com` to allowed domains in Chapa dashboard
- Verify domain ownership if required

## 📱 **Mobile Testing**

### **Test on Mobile Devices:**
- Visit `http://bochboch.com/` on mobile
- Test deposit/withdraw functionality
- Verify Chapa payment modal works on mobile

## 🔍 **Monitoring and Logs**

### **Check Logs:**
```bash
# Transaction logs
tail -f /path/to/your/site/logs/transactions.log

# Webhook logs  
tail -f /path/to/your/site/logs/webhooks.log

# Server error logs
tail -f /var/log/apache2/error.log
```

### **Monitor API Status:**
- Bookmark: `http://bochboch.com/api/status.php?format=html`
- Check regularly for system health

## 🚨 **Troubleshooting**

### **Common Issues:**

#### **1. Chapa SDK Not Loading:**
```javascript
// Check browser console for errors
// Verify internet connection
// Ensure HTTPS for production
```

#### **2. API Endpoints Not Working:**
```bash
# Check file permissions
chmod 644 api/*.php
chmod 755 api/

# Check PHP errors
tail -f /var/log/php_errors.log
```

#### **3. Payment Modal Not Opening:**
```javascript
// Check browser console
// Verify public key is correct
// Ensure domain is whitelisted in Chapa
```

## 🔄 **Production Readiness**

### **Before Going Live:**

1. **Switch to Production Keys:**
   - Replace test keys with production keys
   - Update `testMode: false` in JavaScript

2. **Enable HTTPS:**
   - Install SSL certificate
   - Update all URLs to HTTPS

3. **Database Integration:**
   - Set up MySQL/PostgreSQL database
   - Update PHP files to use real database

4. **Backup System:**
   - Set up automated backups
   - Test restore procedures

5. **Monitoring:**
   - Set up uptime monitoring
   - Configure error alerts

## 📞 **Support Contacts**

### **If You Need Help:**
- **Chapa Support:** support@chapa.co
- **Chapa Docs:** https://developer.chapa.co
- **Test the integration** before going live

## ✅ **Deployment Checklist**

- [ ] Files uploaded to server
- [ ] Directory permissions set correctly
- [ ] Domain points to server
- [ ] SSL certificate installed (recommended)
- [ ] Chapa dashboard configured
- [ ] Webhook URL updated
- [ ] Test transactions completed
- [ ] Mobile testing done
- [ ] Monitoring set up
- [ ] Backup system configured

Your banking app is ready for `bochboch.com`! 🎉