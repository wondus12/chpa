<?php
/**
 * Real-time Balance API
 * Retrieve current user balance
 */

require_once __DIR__ . '/../session_config.php';
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../models/User.php';

// Start session
startSecureSession();

header('Content-Type: application/json');

// Validate user authentication
$user_id = $_SESSION['user_id'] ?? null;
if (!$user_id) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'error' => 'User not authenticated'
    ]);
    exit;
}

// Initialize database connection
$database = new Database();
$db = $database->getConnection();

// Get user balance
$user = new User($db);
$userData = $user->getUserById($user_id);

if (!$userData) {
    http_response_code(404);
    echo json_encode([
        'success' => false,
        'error' => 'User not found'
    ]);
    exit;
}

echo json_encode([
    'success' => true,
    'data' => [
        'balance' => floatval($userData['balance']),
        'currency' => 'ETB',
        'last_updated' => $userData['updated_at']
    ]
]);
?>
