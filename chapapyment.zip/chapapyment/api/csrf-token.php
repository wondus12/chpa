<?php
/**
 * CSRF Token API Endpoint
 * Provides CSRF tokens for frontend requests
 */

require_once __DIR__ . '/../session_config.php';
require_once __DIR__ . '/../security/csrf.php';

header('Content-Type: application/json');

// Generate CSRF token
$token = generateCSRFToken();

echo json_encode([
    'success' => true,
    'token' => $token
]);
?>
