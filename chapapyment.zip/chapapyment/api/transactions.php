<?php
/**
 * Transaction History API
 * Retrieve and filter user transactions
 */

require_once __DIR__ . '/../session_config.php';
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../models/Transaction.php';

// Start session
startSecureSession();

header('Content-Type: application/json');

// Validate user authentication
$user_id = $_SESSION['user_id'] ?? null;
if (!$user_id) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'error' => 'User not authenticated'
    ]);
    exit;
}

// Get filter parameters
$filters = [
    'date_from' => $_GET['date_from'] ?? null,
    'date_to' => $_GET['date_to'] ?? null,
    'status' => $_GET['status'] ?? null,
    'type' => $_GET['type'] ?? null,
    'search' => $_GET['search'] ?? null,
    'limit' => min(intval($_GET['limit'] ?? 50), 100), // Max 100 records
    'offset' => intval($_GET['offset'] ?? 0)
];

// Initialize database connection
$database = new Database();
$db = $database->getConnection();

// Get transactions with filters
$transaction = new Transaction($db);
$transactions = $transaction->getUserTransactionsWithFilters($user_id, $filters);

// Get total count for pagination
$totalCount = $transaction->getUserTransactionCount($user_id, $filters);

echo json_encode([
    'success' => true,
    'data' => $transactions,
    'pagination' => [
        'total' => $totalCount,
        'limit' => $filters['limit'],
        'offset' => $filters['offset'],
        'pages' => ceil($totalCount / $filters['limit'])
    ]
]);
?>
