<?php
/**
 * Withdrawal API with Input Validation
 */

require_once __DIR__ . '/../session_config.php';
require_once __DIR__ . '/../security/csrf.php';
require_once __DIR__ . '/../security/InputValidator.php';
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../models/Transaction.php';
require_once __DIR__ . '/../models/WithdrawalRequest.php';
require_once __DIR__ . '/../security/FraudDetector.php';

header('Content-Type: application/json');

// Validate CSRF token
if (!validateCSRFMiddleware()) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => 'Invalid CSRF token'
    ]);
    exit;
}

// Validate user authentication
$user_id = $_SESSION['user_id'] ?? null;
if (!$user_id) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'error' => 'User not authenticated'
    ]);
    exit;
}

// Get request data
$input = json_decode(file_get_contents('php://input'), true);

// Validate amount
$amount = InputValidator::validateAmount($input['amount'] ?? 0);
if (!$amount) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => 'Invalid amount format'
    ]);
    exit;
}

// Validate account details
$accountDetails = InputValidator::validateAccountDetails($input['account_details'] ?? '');
if (!$accountDetails) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => 'Invalid account details'
    ]);
    exit;
}

// Validate payment method
$paymentMethod = InputValidator::validatePaymentMethod($input['payment_method'] ?? 'bank_transfer');
if (!$paymentMethod) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => 'Invalid payment method'
    ]);
    exit;
}

// Initialize database connection
$database = new Database();
$db = $database->getConnection();

// Validate withdrawal amount against user balance
$user = new User($db);
$userData = $user->getUserById($user_id);

if (!$userData) {
    http_response_code(404);
    echo json_encode([
        'success' => false,
        'error' => 'User not found'
    ]);
    exit;
}

if ($amount > $userData['balance']) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => 'Insufficient balance'
    ]);
    exit;
}

// Perform fraud checks
$fraudDetector = new FraudDetector($db);
$fraudCheck = $fraudDetector->checkTransaction($user_id, $amount, 'withdrawal', $_SERVER['REMOTE_ADDR']);

if (!$fraudCheck['passed']) {
    http_response_code(403);
    echo json_encode([
        'success' => false,
        'error' => 'Transaction flagged by fraud detection',
        'fraud_level' => $fraudCheck['fraud_level'],
        'warnings' => $fraudCheck['warnings']
    ]);
    exit;
}

// Create withdrawal request
$withdrawalRequest = new WithdrawalRequest($db);
$requestCreated = $withdrawalRequest->createRequest($user_id, $amount, $accountDetails, $paymentMethod);

if ($requestCreated) {
    // Deduct amount from user balance
    $user->updateBalance($user_id, $amount, 'subtract');
    
    echo json_encode([
        'success' => true,
        'message' => 'Withdrawal request submitted successfully',
        'request_id' => $requestCreated
    ]);
} else {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Failed to submit withdrawal request'
    ]);
}
?>
