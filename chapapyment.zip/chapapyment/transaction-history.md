# Transaction History Implementation

## Backend API Implementation

### Transaction History API (api/transactions.php)
```php
<?php
/**
 * Transaction History API
 * Retrieve and filter user transactions
 */

require_once __DIR__ . '/../session_config.php';
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../models/Transaction.php';

// Start session
startSecureSession();

header('Content-Type: application/json');

// Validate user authentication
$user_id = $_SESSION['user_id'] ?? null;
if (!$user_id) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'error' => 'User not authenticated'
    ]);
    exit;
}

// Get filter parameters
$filters = [
    'date_from' => $_GET['date_from'] ?? null,
    'date_to' => $_GET['date_to'] ?? null,
    'status' => $_GET['status'] ?? null,
    'type' => $_GET['type'] ?? null,
    'search' => $_GET['search'] ?? null,
    'limit' => min(intval($_GET['limit'] ?? 50), 100), // Max 100 records
    'offset' => intval($_GET['offset'] ?? 0)
];

// Initialize database connection
$database = new Database();
$db = $database->getConnection();

// Get transactions with filters
$transaction = new Transaction($db);
$transactions = $transaction->getUserTransactionsWithFilters($user_id, $filters);

// Get total count for pagination
$totalCount = $transaction->getUserTransactionCount($user_id, $filters);

echo json_encode([
    'success' => true,
    'data' => $transactions,
    'pagination' => [
        'total' => $totalCount,
        'limit' => $filters['limit'],
        'offset' => $filters['offset'],
        'pages' => ceil($totalCount / $filters['limit'])
    ]
]);
?>
```

### Updated Transaction Model with Filtering (models/Transaction.php)
```php
<?php
/**
 * Updated Transaction Model with Filtering
 */

class Transaction {
    private $conn;
    private $table_name = "transactions";
    
    public $id;
    public $user_id;
    public $transaction_type;
    public $amount;
    public $status;
    public $tx_ref;
    public $chapa_tx_ref;
    public $payment_method;
    public $description;
    public $created_at;
    public $updated_at;
    
    public function __construct($db) {
        $this->conn = $db;
    }
    
    // Create a new transaction
    public function createTransaction($user_id, $type, $amount, $tx_ref, $chapa_tx_ref = null, $payment_method = null, $description = null) {
        $query = "INSERT INTO " . $this->table_name . " 
                  (user_id, transaction_type, amount, tx_ref, chapa_tx_ref, payment_method, description, status) 
                  VALUES (:user_id, :transaction_type, :amount, :tx_ref, :chapa_tx_ref, :payment_method, :description, 'pending')";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->bindParam(':transaction_type', $type);
        $stmt->bindParam(':amount', $amount);
        $stmt->bindParam(':tx_ref', $tx_ref);
        $stmt->bindParam(':chapa_tx_ref', $chapa_tx_ref);
        $stmt->bindParam(':payment_method', $payment_method);
        $stmt->bindParam(':description', $description);
        
        return $stmt->execute();
    }
    
    // Update transaction status
    public function updateStatus($tx_ref, $status) {
        $query = "UPDATE " . $this->table_name . " SET status = :status, updated_at = CURRENT_TIMESTAMP WHERE tx_ref = :tx_ref";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':status', $status);
        $stmt->bindParam(':tx_ref', $tx_ref);
        
        return $stmt->execute();
    }
    
    // Get transaction by reference
    public function getTransactionByRef($tx_ref) {
        $query = "SELECT * FROM " . $this->table_name . " WHERE tx_ref = :tx_ref LIMIT 1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':tx_ref', $tx_ref);
        $stmt->execute();
        
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    // Get user transactions with basic pagination
    public function getUserTransactions($user_id, $limit = 10) {
        $query = "SELECT * FROM " . $this->table_name . " 
                  WHERE user_id = :user_id 
                  ORDER BY created_at DESC 
                  LIMIT :limit";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // Get user transactions with advanced filtering
    public function getUserTransactionsWithFilters($user_id, $filters = []) {
        $query = "SELECT t.*, u.username as user_name FROM " . $this->table_name . " t";
        
        // Join with users table for admin queries
        $params = [':user_id' => $user_id];
        $whereClauses = ["t.user_id = :user_id"];
        
        // Add date filters
        if (!empty($filters['date_from'])) {
            $whereClauses[] = "t.created_at >= :date_from";
            $params[':date_from'] = $filters['date_from'];
        }
        
        if (!empty($filters['date_to'])) {
            $whereClauses[] = "t.created_at <= :date_to";
            $params[':date_to'] = $filters['date_to'];
        }
        
        // Add status filter
        if (!empty($filters['status'])) {
            $whereClauses[] = "t.status = :status";
            $params[':status'] = $filters['status'];
        }
        
        // Add type filter
        if (!empty($filters['type'])) {
            $whereClauses[] = "t.transaction_type = :type";
            $params[':type'] = $filters['type'];
        }
        
        // Add search filter
        if (!empty($filters['search'])) {
            $searchTerm = '%' . $filters['search'] . '%';
            $whereClauses[] = "(t.tx_ref LIKE :search OR t.description LIKE :search OR t.payment_method LIKE :search)";
            $params[':search'] = $searchTerm;
        }
        
        // Add where clause if needed
        if (!empty($whereClauses)) {
            $query .= " WHERE " . implode(" AND ", $whereClauses);
        }
        
        // Add ordering and pagination
        $query .= " ORDER BY t.created_at DESC";
        
        if (isset($filters['limit'])) {
            $query .= " LIMIT :limit OFFSET :offset";
            $params[':limit'] = $filters['limit'];
            $params[':offset'] = $filters['offset'];
        }
        
        $stmt = $this->conn->prepare($query);
        
        // Bind parameters
        foreach ($params as $key => $value) {
            if ($key === ':limit' || $key === ':offset') {
                $stmt->bindValue($key, $value, PDO::PARAM_INT);
            } else {
                $stmt->bindValue($key, $value);
            }
        }
        
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // Get user transaction count with filters
    public function getUserTransactionCount($user_id, $filters = []) {
        $query = "SELECT COUNT(*) as count FROM " . $this->table_name . " t";
        
        $params = [':user_id' => $user_id];
        $whereClauses = ["t.user_id = :user_id"];
        
        // Add date filters
        if (!empty($filters['date_from'])) {
            $whereClauses[] = "t.created_at >= :date_from";
            $params[':date_from'] = $filters['date_from'];
        }
        
        if (!empty($filters['date_to'])) {
            $whereClauses[] = "t.created_at <= :date_to";
            $params[':date_to'] = $filters['date_to'];
        }
        
        // Add status filter
        if (!empty($filters['status'])) {
            $whereClauses[] = "t.status = :status";
            $params[':status'] = $filters['status'];
        }
        
        // Add type filter
        if (!empty($filters['type'])) {
            $whereClauses[] = "t.transaction_type = :type";
            $params[':type'] = $filters['type'];
        }
        
        // Add search filter
        if (!empty($filters['search'])) {
            $searchTerm = '%' . $filters['search'] . '%';
            $whereClauses[] = "(t.tx_ref LIKE :search OR t.description LIKE :search OR t.payment_method LIKE :search)";
            $params[':search'] = $searchTerm;
        }
        
        // Add where clause if needed
        if (!empty($whereClauses)) {
            $query .= " WHERE " . implode(" AND ", $whereClauses);
        }
        
        $stmt = $this->conn->prepare($query);
        
        // Bind parameters
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['count'] ?? 0;
    }
    
    // Get all transactions for admin (with filtering)
    public function getAllTransactionsWithFilters($filters = []) {
        $query = "SELECT t.*, u.username, u.email FROM " . $this->table_name . " t 
                  JOIN users u ON t.user_id = u.id";
        
        $params = [];
        $whereClauses = [];
        
        // Add user filter
        if (!empty($filters['user_id'])) {
            $whereClauses[] = "t.user_id = :user_id";
            $params[':user_id'] = $filters['user_id'];
        }
        
        // Add date filters
        if (!empty($filters['date_from'])) {
            $whereClauses[] = "t.created_at >= :date_from";
            $params[':date_from'] = $filters['date_from'];
        }
        
        if (!empty($filters['date_to'])) {
            $whereClauses[] = "t.created_at <= :date_to";
            $params[':date_to'] = $filters['date_to'];
        }
        
        // Add status filter
        if (!empty($filters['status'])) {
            $whereClauses[] = "t.status = :status";
            $params[':status'] = $filters['status'];
        }
        
        // Add type filter
        if (!empty($filters['type'])) {
            $whereClauses[] = "t.transaction_type = :type";
            $params[':type'] = $filters['type'];
        }
        
        // Add search filter
        if (!empty($filters['search'])) {
            $searchTerm = '%' . $filters['search'] . '%';
            $whereClauses[] = "(t.tx_ref LIKE :search OR u.username LIKE :search OR u.email LIKE :search OR t.description LIKE :search)";
            $params[':search'] = $searchTerm;
        }
        
        // Add where clause if needed
        if (!empty($whereClauses)) {
            $query .= " WHERE " . implode(" AND ", $whereClauses);
        }
        
        // Add ordering and pagination
        $query .= " ORDER BY t.created_at DESC";
        
        if (isset($filters['limit'])) {
            $query .= " LIMIT :limit OFFSET :offset";
            $params[':limit'] = $filters['limit'];
            $params[':offset'] = $filters['offset'];
        }
        
        $stmt = $this->conn->prepare($query);
        
        // Bind parameters
        foreach ($params as $key => $value) {
            if ($key === ':limit' || $key === ':offset') {
                $stmt->bindValue($key, $value, PDO::PARAM_INT);
            } else {
                $stmt->bindValue($key, $value);
            }
        }
        
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>
```

## Frontend Implementation

### Updated HTML Structure for Transaction History
```html
<!-- Payments Section -->
<div id="payments-section" class="content-section" style="display: none;">
    <h1>Transaction History</h1>
    
    <!-- Filter Controls -->
    <div class="filter-section">
        <div class="row">
            <div class="col-md-3">
                <label>Date From</label>
                <input type="date" class="form-control filter-input" id="date-from" placeholder="From">
            </div>
            <div class="col-md-3">
                <label>Date To</label>
                <input type="date" class="form-control filter-input" id="date-to" placeholder="To">
            </div>
            <div class="col-md-3">
                <label>Status</label>
                <select class="form-control filter-input" id="status-filter">
                    <option value="">All Statuses</option>
                    <option value="pending">Pending</option>
                    <option value="completed">Completed</option>
                    <option value="failed">Failed</option>
                    <option value="cancelled">Cancelled</option>
                </select>
            </div>
            <div class="col-md-3">
                <label>Type</label>
                <select class="form-control filter-input" id="type-filter">
                    <option value="">All Types</option>
                    <option value="deposit">Deposit</option>
                    <option value="withdrawal">Withdrawal</option>
                </select>
            </div>
        </div>
        
        <div class="row mt-3">
            <div class="col-md-6">
                <label>Search</label>
                <input type="text" class="form-control filter-input" id="search-input" placeholder="Search by transaction ID, description, or payment method">
            </div>
            <div class="col-md-6">
                <label>&nbsp;</label>
                <div>
                    <button class="btn btn-primary" id="apply-filters">Apply Filters</button>
                    <button class="btn btn-secondary" id="clear-filters">Clear Filters</button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Transaction Table -->
    <div class="table-responsive mt-4">
        <table class="table table-striped" id="transactions-table">
            <thead>
                <tr>
                    <th>Date & Time</th>
                    <th>Transaction ID</th>
                    <th>Type</th>
                    <th>Amount</th>
                    <th>Payment Method</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody id="transactions-table-body">
                <!-- Transactions will be loaded here -->
                <tr>
                    <td colspan="7" class="text-center">
                        <div class="spinner-border" role="status" id="loading-spinner">
                            <span class="sr-only">Loading...</span>
                        </div>
                        <div id="no-transactions-message" style="display: none;">
                            No transactions found
                        </div>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
    
    <!-- Pagination -->
    <div class="d-flex justify-content-between align-items-center mt-3">
        <div id="pagination-info">Showing 0 of 0 transactions</div>
        <nav>
            <ul class="pagination" id="pagination-controls">
                <!-- Pagination controls will be generated here -->
            </ul>
        </nav>
    </div>
</div>
```

### JavaScript for Transaction History
```javascript
// Transaction History Management
class TransactionHistory {
    constructor() {
        this.currentPage = 0;
        this.limit = 10;
        this.totalTransactions = 0;
        this.transactions = [];
        this.filters = {
            date_from: null,
            date_to: null,
            status: null,
            type: null,
            search: null
        };
    }
    
    // Initialize transaction history
    init() {
        this.bindEvents();
        this.loadTransactions();
    }
    
    // Bind event listeners
    bindEvents() {
        // Filter events
        document.getElementById('apply-filters').addEventListener('click', () => {
            this.applyFilters();
        });
        
        document.getElementById('clear-filters').addEventListener('click', () => {
            this.clearFilters();
        });
        
        // Enter key in search
        document.getElementById('search-input').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                this.applyFilters();
            }
        });
        
        // Filter inputs change
        document.querySelectorAll('.filter-input').forEach(input => {
            input.addEventListener('change', () => {
                // Auto-apply filters after a delay for better UX
                clearTimeout(this.filterTimeout);
                this.filterTimeout = setTimeout(() => {
                    this.applyFilters();
                }, 500);
            });
        });
    }
    
    // Apply filters
    applyFilters() {
        this.filters = {
            date_from: document.getElementById('date-from').value || null,
            date_to: document.getElementById('date-to').value || null,
            status: document.getElementById('status-filter').value || null,
            type: document.getElementById('type-filter').value || null,
            search: document.getElementById('search-input').value || null
        };
        
        this.currentPage = 0;
        this.loadTransactions();
    }
    
    // Clear filters
    clearFilters() {
        document.getElementById('date-from').value = '';
        document.getElementById('date-to').value = '';
        document.getElementById('status-filter').value = '';
        document.getElementById('type-filter').value = '';
        document.getElementById('search-input').value = '';
        
        this.filters = {
            date_from: null,
            date_to: null,
            status: null,
            type: null,
            search: null
        };
        
        this.currentPage = 0;
        this.loadTransactions();
    }
    
    // Load transactions from API
    async loadTransactions() {
        try {
            // Show loading spinner
            this.showLoading(true);
            
            // Build query parameters
            const params = new URLSearchParams({
                limit: this.limit,
                offset: this.currentPage * this.limit,
                ...Object.fromEntries(
                    Object.entries(this.filters).filter(([_, v]) => v != null && v !== '')
                )
            });
            
            const response = await fetch(`/api/transactions.php?${params}`, {
                method: 'GET',
                credentials: 'same-origin'
            });
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            
            const result = await response.json();
            
            if (result.success) {
                this.transactions = result.data;
                this.totalTransactions = result.pagination.total;
                this.renderTransactions();
                this.renderPagination();
            } else {
                throw new Error(result.error || 'Failed to load transactions');
            }
        } catch (error) {
            console.error('Error loading transactions:', error);
            this.showError('Failed to load transactions. Please try again.');
        } finally {
            this.showLoading(false);
        }
    }
    
    // Render transactions table
    renderTransactions() {
        const tbody = document.getElementById('transactions-table-body');
        
        if (this.transactions.length === 0) {
            document.getElementById('no-transactions-message').style.display = 'block';
            tbody.innerHTML = '<tr><td colspan="7" class="text-center">No transactions found</td></tr>';
            return;
        }
        
        document.getElementById('no-transactions-message').style.display = 'none';
        
        const rows = this.transactions.map(transaction => {
            const date = new Date(transaction.created_at).toLocaleString();
            const amount = parseFloat(transaction.amount).toLocaleString('en-ET', {
                style: 'currency',
                currency: 'ETB'
            });
            
            // Status badge
            let statusClass = '';
            switch (transaction.status) {
                case 'completed':
                    statusClass = 'badge-success';
                    break;
                case 'pending':
                    statusClass = 'badge-warning';
                    break;
                case 'failed':
                    statusClass = 'badge-danger';
                    break;
                default:
                    statusClass = 'badge-secondary';
            }
            
            // Type badge
            const typeClass = transaction.transaction_type === 'deposit' ? 'badge-primary' : 'badge-info';
            
            return `
                <tr>
                    <td>${date}</td>
                    <td>${transaction.tx_ref || 'N/A'}</td>
                    <td><span class="badge ${typeClass}">${transaction.transaction_type}</span></td>
                    <td>${amount}</td>
                    <td>${transaction.payment_method || 'N/A'}</td>
                    <td><span class="badge ${statusClass}">${transaction.status}</span></td>
                    <td>
                        <button class="btn btn-sm btn-outline-primary view-details" 
                                data-tx-ref="${transaction.tx_ref}">
                            View
                        </button>
                    </td>
                </tr>
            `;
        }).join('');
        
        tbody.innerHTML = rows;
        
        // Bind view details events
        document.querySelectorAll('.view-details').forEach(button => {
            button.addEventListener('click', (e) => {
                const txRef = e.target.getAttribute('data-tx-ref');
                this.viewTransactionDetails(txRef);
            });
        });
    }
    
    // Render pagination controls
    renderPagination() {
        const totalPages = Math.ceil(this.totalTransactions / this.limit);
        const paginationControls = document.getElementById('pagination-controls');
        
        // Update pagination info
        const start = this.currentPage * this.limit + 1;
        const end = Math.min(start + this.limit - 1, this.totalTransactions);
        document.getElementById('pagination-info').textContent = 
            `Showing ${start}-${end} of ${this.totalTransactions} transactions`;
        
        // Generate pagination buttons
        let paginationHTML = '';
        
        // Previous button
        if (this.currentPage > 0) {
            paginationHTML += `
                <li class="page-item">
                    <a class="page-link" href="#" data-page="${this.currentPage - 1}">Previous</a>
                </li>
            `;
        }
        
        // Page numbers
        const maxVisiblePages = 5;
        let startPage = Math.max(0, this.currentPage - Math.floor(maxVisiblePages / 2));
        let endPage = Math.min(totalPages - 1, startPage + maxVisiblePages - 1);
        
        // Adjust start page if needed
        if (endPage - startPage < maxVisiblePages - 1) {
            startPage = Math.max(0, endPage - maxVisiblePages + 1);
        }
        
        // First page
        if (startPage > 0) {
            paginationHTML += `
                <li class="page-item">
                    <a class="page-link" href="#" data-page="0">1</a>
                </li>
            `;
            if (startPage > 1) {
                paginationHTML += '<li class="page-item disabled"><span class="page-link">...</span></li>';
            }
        }
        
        // Page numbers
        for (let i = startPage; i <= endPage; i++) {
            const activeClass = i === this.currentPage ? 'active' : '';
            paginationHTML += `
                <li class="page-item ${activeClass}">
                    <a class="page-link" href="#" data-page="${i}">${i + 1}</a>
                </li>
            `;
        }
        
        // Last page
        if (endPage < totalPages - 1) {
            if (endPage < totalPages - 2) {
                paginationHTML += '<li class="page-item disabled"><span class="page-link">...</span></li>';
            }
            paginationHTML += `
                <li class="page-item">
                    <a class="page-link" href="#" data-page="${totalPages - 1}">${totalPages}</a>
                </li>
            `;
        }
        
        // Next button
        if (this.currentPage < totalPages - 1) {
            paginationHTML += `
                <li class="page-item">
                    <a class="page-link" href="#" data-page="${this.currentPage + 1}">Next</a>
                </li>
            `;
        }
        
        paginationControls.innerHTML = paginationHTML;
        
        // Bind pagination events
        document.querySelectorAll('.page-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const page = parseInt(e.target.getAttribute('data-page'));
                if (!isNaN(page)) {
                    this.currentPage = page;
                    this.loadTransactions();
                }
            });
        });
    }
    
    // View transaction details
    viewTransactionDetails(txRef) {
        // Find the transaction
        const transaction = this.transactions.find(t => t.tx_ref === txRef);
        
        if (transaction) {
            // Create modal or show details in a sidebar
            this.showTransactionModal(transaction);
        }
    }
    
    // Show transaction details modal
    showTransactionModal(transaction) {
        // Create modal if it doesn't exist
        let modal = document.getElementById('transaction-modal');
        if (!modal) {
            modal = document.createElement('div');
            modal.id = 'transaction-modal';
            modal.className = 'modal fade';
            modal.tabIndex = -1;
            modal.innerHTML = `
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Transaction Details</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body" id="transaction-modal-body">
                            <!-- Details will be loaded here -->
                        </div>
                        <div class="modal-footer">
                            <button type="button"