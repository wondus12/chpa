# Payment Simulation and Testing Guide

## Table of Contents
1. [Testing Overview](#testing-overview)
2. [Manual Testing Steps](#manual-testing-steps)
3. [Automated Testing](#automated-testing)
4. [Payment Simulation](#payment-simulation)
5. [Security Testing](#security-testing)
6. [Performance Testing](#performance-testing)
7. [Load Testing](#load-testing)
8. [Regression Testing](#regression-testing)
9. [Test Data Management](#test-data-management)
10. [Continuous Integration](#continuous-integration)

## Testing Overview

This document provides comprehensive testing procedures for the Chapa Banking App, covering manual testing, automated testing, payment simulation, security testing, and performance testing.

### Testing Environment Setup

1. **Development Environment**
   - PHP 7.4+
   - MySQL 5.7+
   - Apache/Nginx
   - Composer
   - Node.js (for frontend tooling)

2. **Test Database**
   ```sql
   CREATE DATABASE chapa_banking_test;
   -- Import schema from database/schema.sql
   ```

3. **Test Configuration**
   - Copy `config.example.php` to `config.test.php`
   - Update database connection to test database
   - Set `IS_PRODUCTION` to `false`
   - Use Chapa test keys

## Manual Testing Steps

### User Authentication Testing

1. **User Registration**
   - Navigate to registration page
   - Enter valid registration details
   - Verify account creation and email confirmation
   - Test duplicate email/username handling

2. **User Login**
   - Navigate to login page
   - Enter valid credentials
   - Verify successful login and session creation
   - Test invalid credentials handling
   - Test account lockout after failed attempts

3. **Session Management**
   - Test session timeout
   - Test concurrent sessions
   - Test logout functionality
   - Test session regeneration

### Deposit Functionality Testing

1. **Chapa Payment Initiation**
   - Select deposit amount
   - Click deposit button
   - Verify Chapa payment form loads
   - Test different amount selections
   - Test custom amount input

2. **Payment Success Simulation**
   - Complete Chapa payment form
   - Simulate successful payment
   - Verify transaction record creation
   - Verify balance update
   - Verify success message display

3. **Payment Failure Simulation**
   - Cancel Chapa payment
   - Simulate payment failure
   - Verify transaction record creation with failed status
   - Verify balance remains unchanged
   - Verify error message display

4. **Payment Verification**
   - Test verify-payment.php endpoint
   - Test webhook handling
   - Verify database updates
   - Test edge cases (invalid tx_ref, etc.)

### Withdrawal Functionality Testing

1. **Withdrawal Request Submission**
   - Navigate to withdrawal section
   - Enter valid withdrawal amount
   - Enter account details
   - Submit withdrawal request
   - Verify request creation in database
   - Verify balance deduction

2. **Withdrawal Validation**
   - Test minimum amount validation (50 ETB)
   - Test maximum amount validation (50,000 ETB)
   - Test insufficient balance handling
   - Test invalid account details handling
   - Test fraud detection triggers

3. **Admin Withdrawal Processing**
   - Login as admin
   - Navigate to withdrawal requests
   - Test approval workflow
   - Test rejection workflow
   - Verify balance updates
   - Verify notifications

### Transaction History Testing

1. **Transaction Display**
   - Navigate to payments section
   - Verify transaction history loads
   - Test pagination
   - Test date filtering
   - Test status filtering
   - Test type filtering
   - Test search functionality

2. **Real-time Updates**
   - Test balance display updates
   - Test WebSocket connection
   - Test polling fallback
   - Test connection recovery

### Security Testing

1. **CSRF Protection**
   - Test forms without CSRF token
   - Test API endpoints without CSRF token
   - Verify token validation
   - Test token regeneration

2. **Input Validation**
   - Test SQL injection attempts
   - Test XSS attempts
   - Test invalid input formats
   - Test boundary value testing

3. **Authentication Testing**
   - Test unauthorized access to protected pages
   - Test session hijacking attempts
   - Test brute force attacks
   - Test password strength requirements

## Automated Testing

### Unit Testing Framework Setup

1. **Install PHPUnit**
   ```bash
   composer require --dev phpunit/phpunit
   ```

2. **Test Directory Structure**
   ```
   tests/
   ├── Unit/
   │   ├── UserTest.php
   │   ├── TransactionTest.php
   │   ├── WithdrawalRequestTest.php
   │   └── SecurityTest.php
   ├── Integration/
   │   ├── PaymentTest.php
   │   ├── WebhookTest.php
   │   └── AdminTest.php
   └── Fixtures/
       ├── TestUser.php
       └── TestTransaction.php
   ```

### Sample Unit Tests

#### User Model Test (tests/Unit/UserTest.php)
```php
<?php
use PHPUnit\Framework\TestCase;

class UserTest extends TestCase {
    private $db;
    private $user;
    
    protected function setUp(): void {
        // Setup test database connection
        $this->db = new PDO('mysql:host=localhost;dbname=chapa_banking_test', 'test_user', 'test_pass');
        $this->user = new User($this->db);
    }
    
    public function testCreateUser() {
        $userData = [
            'username' => 'testuser',
            'email' => 'test@example.com',
            'password' => 'password123'
        ];
        
        $result = $this->user->createUser($userData);
        $this->assertTrue($result);
        
        // Verify user was created
        $user = $this->user->getUserByEmail('test@example.com');
        $this->assertNotNull($user);
        $this->assertEquals('testuser', $user['username']);
    }
    
    public function testUpdateBalance() {
        // Create test user
        $userId = $this->createTestUser();
        
        // Update balance
        $result = $this->user->updateBalance($userId, 1000, 'add');
        $this->assertTrue($result);
        
        // Verify balance update
        $user = $this->user->getUserById($userId);
        $this->assertEquals(1000, $user['balance']);
    }
    
    private function createTestUser() {
        $userData = [
            'username' => 'testuser' . time(),
            'email' => 'test' . time() . '@example.com',
            'password' => password_hash('password123', PASSWORD_DEFAULT)
        ];
        
        $this->db->prepare("INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)")
                 ->execute([$userData['username'], $userData['email'], $userData['password']]);
        
        return $this->db->lastInsertId();
    }
}
?>
```

#### Payment Verification Test (tests/Integration/PaymentTest.php)
```php
<?php
use PHPUnit\Framework\TestCase;

class PaymentTest extends TestCase {
    private $db;
    
    protected function setUp(): void {
        $this->db = new PDO('mysql:host=localhost;dbname=chapa_banking_test', 'test_user', 'test_pass');
    }
    
    public function testVerifyPaymentSuccess() {
        // Mock Chapa API response
        $mockResponse = [
            'status' => 'success',
            'data' => [
                'amount' => 1000,
                'currency' => 'ETB',
                'tx_ref' => 'test-tx-' . time()
            ]
        ];
        
        // Create test user and transaction
        $userId = $this->createTestUser();
        $txRef = 'test-tx-' . time();
        
        // Test verification
        $verifier = new ChapaVerification();
        $result = $verifier->simulateVerification($txRef);
        
        $this->assertTrue($result['success']);
        $this->assertEquals('success', $result['status']);
        $this->assertEquals($txRef, $result['data']['tx_ref']);
    }
    
    public function testVerifyPaymentFailure() {
        // Test with forced failure
        $_SESSION['force_verification_failure'] = true;
        
        $verifier = new ChapaVerification();
        $result = $verifier->simulateVerification('test-tx');
        
        $this->assertFalse($result['success']);
        $this->assertEquals('failed', $result['status']);
    }
    
    private function createTestUser() {
        $stmt = $this->db->prepare("INSERT INTO users (username, email, password_hash, balance) VALUES (?, ?, ?, ?)");
        $stmt->execute(['testuser', 'test@example.com', 'hashed_password', 1000]);
        return $this->db->lastInsertId();
    }
}
?>
```

### Running Tests
```bash
# Run all tests
./vendor/bin/phpunit

# Run specific test suite
./vendor/bin/phpunit tests/Unit/UserTest.php

# Run with coverage
./vendor/bin/phpunit --coverage-html coverage/

# Run tests in parallel
./vendor/bin/phpunit --processes 4
```

## Payment Simulation

### Chapa Test Mode Configuration

1. **Test Keys Setup**
   - Public Key: `CHAPUBK_TEST-xxxxxxxxxxxxxxxxxxxx`
   - Secret Key: `CHASECRETKEY-xxxxxxxxxxxxxxxxxxxx`

2. **Test Card Details**
   - Card Number: `4200000000000000`
   - Expiry: `12/25`
   - CVV: `123`
   - PIN: `1234`

### Manual Payment Simulation Steps

1. **Successful Payment Simulation**
   ```
   1. Navigate to deposit section
   2. Select or enter amount (e.g., 1000 ETB)
   3. Click "DEPOSIT" button
   4. On Chapa form, enter:
      - Card Number: 4200000000000000
      - Expiry: 12/25
      - CVV: 123
      - PIN: 1234
      - OTP: 123456
   5. Complete payment
   6. Verify success message
   7. Check transaction history
   8. Verify balance update
   ```

2. **Failed Payment Simulation**
   ```
   1. Navigate to deposit section
   2. Select or enter amount
   3. Click "DEPOSIT" button
   4. On Chapa form, enter invalid details or cancel
   5. Verify error message
   6. Check transaction history for failed status
   7. Verify balance unchanged
   ```

3. **Pending Payment Simulation**
   ```
   1. Navigate to deposit section
   2. Select or enter amount
   3. Click "DEPOSIT" button
   4. On Chapa form, select "Pending" test option
   5. Verify pending status in transaction history
   6. Test admin approval process
   ```

### API Testing with cURL

1. **Verify Payment**
   ```bash
   curl -X POST http://localhost/api/verify-payment.php \
        -H "Content-Type: application/json" \
        -H "X-CSRF-Token: your_csrf_token" \
        -d '{"tx_ref":"test-tx-123","simulate":true}'
   ```

2. **Submit Withdrawal**
   ```bash
   curl -X POST http://localhost/api/withdraw.php \
        -H "Content-Type: application/json" \
        -H "X-CSRF-Token: your_csrf_token" \
        -d '{"amount":500,"account_details":"0912345678","payment_method":"mobile_money"}'
   ```

3. **Get Transaction History**
   ```bash
   curl -X GET "http://localhost/api/transactions.php?status=completed&type=deposit&limit=10" \
        -H "Content-Type: application/json"
   ```

## Security Testing

### OWASP Testing Checklist

1. **Injection Flaws**
   - Test SQL injection in all input fields
   - Test command injection
   - Test LDAP injection

2. **Broken Authentication**
   - Test brute force login attempts
   - Test session management
   - Test password reset functionality

3. **Sensitive Data Exposure**
   - Test SSL/TLS configuration
   - Test data encryption
   - Test error message handling

4. **XML External Entities (XXE)**
   - Test XML input handling
   - Test file upload functionality

5. **Broken Access Control**
   - Test forced browsing
   - Test privilege escalation
   - Test direct object references

6. **Security Misconfiguration**
   - Test server configuration
   - Test framework configuration
   - Test database configuration

7. **Cross-Site Scripting (XSS)**
   - Test reflected XSS
   - Test stored XSS
   - Test DOM-based XSS

8. **Insecure Deserialization**
   - Test object deserialization
   - Test session data handling

9. **Using Components with Known Vulnerabilities**
   - Test dependency scanning
   - Test framework updates

10. **Insufficient Logging & Monitoring**
    - Test audit logging
    - Test monitoring alerts
    - Test incident response

### Security Testing Tools

1. **OWASP ZAP**
   ```bash
   # Install OWASP ZAP
   docker run -d -p 8080:8080 owasp/zap2docker-stable
   
   # Run automated scan
   docker run owasp/zap2docker-stable zap-baseline.py -t http://localhost:8000
   ```

2. **SQLMap**
   ```bash
   # Test for SQL injection
   sqlmap -u "http://localhost/api/verify-payment.php" --data="tx_ref=test" --dbs
   ```

3. **Nikto**
   ```bash
   # Web server security scanner
   nikto -h http://localhost:8000
   ```

## Performance Testing

### Load Testing with Apache Bench

1. **Install Apache Bench**
   ```bash
   # Usually comes with Apache
   ab -V
   ```

2. **Test API Endpoints**
   ```bash
   # Test verify-payment endpoint
   ab -n 1000 -c 10 -p test_data.json -T "application/json" http://localhost/api/verify-payment.php
   
   # Test transaction history endpoint
   ab -n 1000 -c 10 http://localhost/api/transactions.php?limit=50
   ```

### Performance Testing with JMeter

1. **Test Plan Structure**
   ```
   Test Plan
   ├── Thread Group (Users)
   │   ├── HTTP Request (Login)
   │   ├── HTTP Request (Deposit)
   │   ├── HTTP Request (Withdrawal)
   │   └── HTTP Request (Transaction History)
   ├── View Results Tree
   └── Summary Report
   ```

2. **JMeter Test Script**
   ```xml
   <?xml version="1.0" encoding="UTF-8"?>
   <jmeterTestPlan version="1.0">
     <hashTree>
       <TestPlan>
         <elementProp name="TestPlan.arguments" elementType="Arguments" guiclass="ArgumentsPanel">
           <!-- Test configuration -->
         </elementProp>
       </TestPlan>
     </hashTree>
   </jmeterTestPlan>
   ```

## Load Testing

### Simulating Concurrent Users

1. **High Load Scenario**
   - 100 concurrent users
   - 1000 total requests
   - Mixed read/write operations
   - Monitor response times
   - Monitor database performance

2. **Stress Testing**
   - Gradually increase load
   - Monitor system resources
   - Identify breaking points
   - Test recovery procedures

### Database Load Testing

1. **Connection Pool Testing**
   - Test maximum connections
   - Test connection timeouts
   - Test connection recovery

2. **Query Performance**
   - Test slow query log
   - Test index usage
   - Test query optimization

## Regression Testing

### Test Suite Maintenance

1. **Version Control**
   - Store tests in version control
   - Track test changes with code changes
   - Review test coverage

2. **Test Data Management**
   - Use consistent test data
   - Clean up test data after runs
   - Generate realistic test data

3. **Test Environment Management**
   - Maintain separate test environments
   - Automate environment setup
   - Ensure environment consistency

### Continuous Testing

1. **Pre-commit Testing**
   - Run unit tests before commit
   - Run security scans
   - Validate code quality

2. **Post-commit Testing**
   - Run integration tests
   - Run performance tests
   - Deploy to staging

## Test Data Management

### Test Data Generation

1. **User Data**
   ```php
   <?php
   class TestDataProvider {
       public static function generateUsers($count = 10) {
           $users = [];
           for ($i = 0; $i < $count; $i++) {
               $users[] = [
                   'username' => 'testuser' . $i,
                   'email' => 'test' . $i . '@example.com',
                   'password' => password_hash('password123', PASSWORD_DEFAULT),
                   'balance' => rand(1000, 10000)
               ];
           }
           return $users;
       }
       
       public static function generateTransactions($userId, $count = 50) {
           $transactions = [];
           $types = ['deposit', 'withdrawal'];
           $statuses = ['pending', 'completed', 'failed'];
           
           for ($i = 0; $i < $count; $i++) {
               $transactions[] = [
                   'user_id' => $userId,
                   'transaction_type' => $types[array_rand($types)],
                   'amount' => rand(100, 5000),
                   'status' => $statuses[array_rand($statuses)],
                   'tx_ref' => 'tx-' . time() . '-' . $i,
                   'created_at' => date('Y-m-d H:i:s', time() - rand(0, 30*24*60*60))
               ];
           }
           return $transactions;
       }
   }
   ?>
   ```

2. **Test Data Seeding**
   ```bash
   # Seed test database
   php tests/seed_test_data.php
   
   # Clear test data
   php tests/clear_test_data.php
   ```

## Continuous Integration

### GitHub Actions Workflow

```yaml
# .github/workflows/test.yml
name: Test Suite

on:
  push:
    branches: [ main, develop ]
  pull_request:
    branches: [ main ]

jobs:
  test:
    runs-on: ubuntu-latest
    
    services:
      mysql:
        image: mysql:5.7
        env:
          MYSQL_ROOT_PASSWORD: rootpassword
          MYSQL_DATABASE: chapa_banking_test
        ports:
          - 3306:3306
        options: --health-cmd="mysqladmin ping" --health-interval=10s --health-timeout=5s --health-retries=3
    
    steps:
    - uses: actions/checkout@v2
    
    - name: Setup PHP
      uses: shivammathur/setup-php@v2
      with:
        php-version: '7.4'
        extensions: mbstring, xml, ctype, iconv, mysql, pdo_mysql
        coverage: xdebug
    
    - name: Install dependencies
      run: composer install --prefer-dist --no-progress
    
    - name: Setup test database
      run: |
        mysql -h 127.0.0.1 -u root -prootpassword -e "CREATE DATABASE chapa_banking_test;"
        mysql -h 127.0.0.1 -u root -prootpassword chapa_banking_test < database/schema.sql
    
    - name: Run unit tests
      run: ./vendor/bin/phpunit tests/Unit
    
    - name: Run integration tests
      run: ./vendor/bin/phpunit tests/Integration
    
    - name: Run security checks
      run: |
        ./vendor/bin/security-checker security:check composer.lock
```

### Test Reporting

1. **JUnit XML Reports**
   ```bash
   ./vendor/bin/phpunit --log-junit test-results.xml
   ```

2. **Code Coverage Reports**
   ```bash
   ./vendor/bin/phpunit --coverage-clover coverage.xml
   ```

3. **Performance Reports**
   - Generate HTML reports from JMeter results
   - Create dashboard with Grafana
   - Monitor key performance metrics

## Summary

This testing guide provides comprehensive coverage of:

1. **Manual Testing Procedures** - Step-by-step testing scenarios
2. **Automated Testing Framework** - Unit and integration tests
3. **Payment Simulation** - Realistic payment testing scenarios
4. **Security Testing** - OWASP-based security validation
5. **Performance Testing** - Load and stress testing procedures
6. **Test Data Management** - Consistent test data generation
7. **Continuous Integration** - Automated testing workflows

The testing approach ensures the Chapa Banking App is thoroughly validated for functionality, security, and performance before deployment to production environments.