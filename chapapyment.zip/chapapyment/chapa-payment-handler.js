/**
 * Chapa Payment Handler for Banking App
 * Handles all Chapa payment integration logic
 */

class ChapaPaymentHandler {
    constructor(config) {
        this.config = {
            publicKey: config.publicKey,
            baseUrl: config.baseUrl,
            secretHash: config.secretHash,
            testMode: config.testMode || true,
            ...config
        };
        this.currentPayment = null;
    }

    // Initialize Chapa SDK
    initialize() {
        if (typeof Chapa === 'undefined') {
            console.error('Chapa SDK not loaded');
            return false;
        }
        return true;
    }

    // Generate unique transaction reference
    generateTxRef() {
        return 'tx-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9);
    }

    // Validate payment amount
    validateAmount(amount, min = 1, max = 1000000) {
        if (!amount || isNaN(amount)) {
            return { valid: false, message: 'Please enter a valid amount' };
        }
        
        const numAmount = parseFloat(amount);
        if (numAmount < min) {
            return { valid: false, message: `Minimum amount is ${min} ETB` };
        }
        
        if (numAmount > max) {
            return { valid: false, message: `Maximum amount is ${max} ETB` };
        }
        
        return { valid: true };
    }

    // Perform fraud checks
    performFraudChecks(amount, paymentType) {
        const checks = {
            passed: true,
            warnings: []
        };
        
        // Check for suspicious amounts
        if (amount > 10000) {
            checks.warnings.push('Large amount transaction');
        }
        
        // Check for rapid successive transactions
        const lastPaymentTime = localStorage.getItem('lastPaymentTime');
        const currentTime = Date.now();
        
        if (lastPaymentTime && (currentTime - parseInt(lastPaymentTime)) < 30000) {
            checks.warnings.push('Rapid successive transactions detected');
            // In production, you might want to block this
        }
        
        // Store current payment time
        localStorage.setItem('lastPaymentTime', currentTime.toString());
        
        return checks;
    }

    // Initialize deposit payment
    async initiateDeposit(amount, userEmail, callbacks) {
        if (!this.initialize()) {
            callbacks.onError('Payment system not available. Please try again later.');
            return;
        }

        const validation = this.validateAmount(amount, 1, 100000);
        if (!validation.valid) {
            callbacks.onError(validation.message);
            return;
        }

        // Perform fraud checks
        const fraudChecks = this.performFraudChecks(amount, 'deposit');
        if (fraudChecks.warnings.length > 0) {
            console.warn('Fraud warnings:', fraudChecks.warnings);
        }

        callbacks.onStart();

        const txRef = this.generateTxRef();
        
        // Store current payment info
        this.currentPayment = {
            type: 'deposit',
            amount: parseFloat(amount),
            txRef: txRef,
            timestamp: new Date().toISOString(),
            userEmail: userEmail
        };

        try {
            const handler = Chapa.setup({
                key: this.config.publicKey,
                email: userEmail,
                amount: parseFloat(amount),
                currency: 'ETB',
                ref: txRef,
                callback: (response) => {
                    this.handlePaymentCallback(response, callbacks);
                },
                onClose: () => {
                    this.handlePaymentClose(callbacks);
                }
            });

            handler.openIframe();
            
        } catch (error) {
            console.error('Chapa initialization error:', error);
            callbacks.onError('Failed to initialize payment. Please try again.');
        }
    }

    // Handle payment callback
    handlePaymentCallback(response, callbacks) {
        if (response.status === 'success') {
            callbacks.onVerifying();
            this.verifyPayment(response.tx_ref, callbacks);
        } else {
            const errorMessage = response.message || 'Payment failed';
            callbacks.onError(`Payment failed: ${errorMessage}`);
            
            if (this.currentPayment) {
                callbacks.onPaymentComplete(this.currentPayment, 'Failed');
                this.currentPayment = null;
            }
        }
    }

    // Handle payment modal close
    handlePaymentClose(callbacks) {
        if (this.currentPayment) {
            callbacks.onCancel('Payment was cancelled');
            this.currentPayment = null;
        }
    }

    // Verify payment (client-side simulation - should be server-side)
    async verifyPayment(txRef, callbacks) {
        try {
            // In production, make an API call to your server for verification
            const response = await this.serverVerifyPayment(txRef);
            
            if (response.verified) {
                callbacks.onSuccess(`Payment verified successfully! ${this.currentPayment.amount} ETB has been added to your account.`);
                callbacks.onPaymentComplete(this.currentPayment, 'Completed');
            } else {
                callbacks.onError('Payment verification failed. Please contact support.');
                callbacks.onPaymentComplete(this.currentPayment, 'Failed');
            }
            
        } catch (error) {
            console.error('Verification error:', error);
            callbacks.onError('Payment verification failed. Please contact support.');
            callbacks.onPaymentComplete(this.currentPayment, 'Failed');
        }
        
        this.currentPayment = null;
    }

    // Server verification (simulate API call)
    async serverVerifyPayment(txRef) {
        // This should be replaced with actual API call to your server
        return new Promise((resolve) => {
            setTimeout(() => {
                // Simulate 90% success rate
                const verified = Math.random() > 0.1;
                resolve({ verified, txRef });
            }, 2000);
        });
    }

    // Process withdrawal (simulation)
    async processWithdrawal(amount, callbacks) {
        const validation = this.validateAmount(amount, 50, 50000);
        if (!validation.valid) {
            callbacks.onError(validation.message);
            return;
        }

        // Perform fraud checks
        const fraudChecks = this.performFraudChecks(amount, 'withdraw');
        if (fraudChecks.warnings.length > 0) {
            console.warn('Fraud warnings:', fraudChecks.warnings);
        }

        callbacks.onStart();

        const txRef = this.generateTxRef();
        
        this.currentPayment = {
            type: 'withdraw',
            amount: parseFloat(amount),
            txRef: txRef,
            timestamp: new Date().toISOString()
        };

        try {
            // Simulate withdrawal processing
            const response = await this.processWithdrawalRequest(this.currentPayment);
            
            if (response.success) {
                callbacks.onSuccess(`Withdrawal of ${amount} ETB processed successfully. Transaction ID: ${txRef}`);
                callbacks.onPaymentComplete(this.currentPayment, 'Completed');
            } else {
                callbacks.onError(`Withdrawal failed: ${response.error}`);
                callbacks.onPaymentComplete(this.currentPayment, 'Failed');
            }
            
        } catch (error) {
            console.error('Withdrawal error:', error);
            callbacks.onError('Withdrawal processing failed. Please try again.');
            callbacks.onPaymentComplete(this.currentPayment, 'Failed');
        }
        
        this.currentPayment = null;
    }

    // Simulate withdrawal processing
    async processWithdrawalRequest(paymentData) {
        return new Promise((resolve) => {
            setTimeout(() => {
                // Simulate 80% success rate
                const success = Math.random() > 0.2;
                resolve({
                    success,
                    error: success ? null : 'Insufficient funds or processing error',
                    txRef: paymentData.txRef
                });
            }, 2000);
        });
    }

    // Get payment status
    getPaymentStatus(txRef) {
        // This should make an API call to your server
        return new Promise((resolve) => {
            setTimeout(() => {
                resolve({
                    status: 'completed',
                    amount: 1000,
                    currency: 'ETB',
                    txRef: txRef
                });
            }, 1000);
        });
    }
}

// Export for use in other files
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ChapaPaymentHandler;
}