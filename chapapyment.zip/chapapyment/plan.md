# Chapa Banking App - Implementation Plan

## 1. Configuration Requirements

The application requires a `config.php` file with the following constants:

### Required Constants:
- `DOMAIN_URL` - The domain URL for the application
- `MIN_DEPOSIT_AMOUNT` - Minimum deposit amount (e.g., 1)
- `MAX_DEPOSIT_AMOUNT` - Maximum deposit amount (e.g., 100000)
- `IS_PRODUCTION` - Boolean flag for production mode
- `CHAPA_SECRET_KEY` - Chapa secret key for API authentication

### Required Function:
- `getChapaConfig()` - Returns an array with Chapa configuration:
  - `public_key` - Chapa public key
  - `secret_key` - Chapa secret key
  - `secret_hash` - Secret hash for webhook verification
  - `approval_secret` - Approval secret for transfer approvals
  - `base_url` - Base URL for API endpoints

## 2. Database Schema Design

### Users Table
```sql
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    balance DECIMAL(10, 2) DEFAULT 0.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

### Transactions Table
```sql
CREATE TABLE transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    transaction_type ENUM('deposit', 'withdrawal') NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    status ENUM('pending', 'completed', 'failed', 'cancelled') DEFAULT 'pending',
    tx_ref VARCHAR(100) UNIQUE,
    chapa_tx_ref VARCHAR(100),
    payment_method VARCHAR(50),
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);
```

### Withdrawal Requests Table
```sql
CREATE TABLE withdrawal_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    payment_method VARCHAR(50),
    account_details TEXT,
    admin_notes TEXT,
    requested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    processed_at TIMESTAMP NULL,
    processed_by INT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (processed_by) REFERENCES users(id)
);
```

## 3. Missing Functionality Implementation

### Withdrawal Functionality
- Add proper validation for min/max amounts (50-50000 ETB)
- Implement fraud checks for withdrawals
- Add database integration for storing withdrawal requests
- Create admin approval/rejection workflow

### Session Management
- Implement user authentication system
- Add login/logout functionality
- Secure all endpoints with session validation

### Security Enhancements
- Add CSRF protection to all forms and API endpoints
- Implement proper input validation and sanitization
- Add rate limiting for transactions
- Strengthen fraud detection with additional checks

## 4. Frontend Improvements

### Withdrawal Section
- Add proper form validation
- Implement real-time balance updates
- Add success/error feedback messages
- Connect to backend withdrawal API

### Transaction History
- Implement date and status filters
- Add search functionality
- Display real-time transaction data

### Admin Panel
- Create withdrawal request approval/rejection interface
- Add filtering and search capabilities
- Implement proper admin authentication

## 5. Backend Implementation

### API Endpoints Needed
1. `POST /api/withdraw.php` - Process withdrawal requests
2. `GET /api/transactions.php` - Retrieve transaction history
3. `POST /api/admin/approve-withdrawal.php` - Approve withdrawal requests
4. `POST /api/admin/reject-withdrawal.php` - Reject withdrawal requests
5. `GET /api/balance.php` - Get current user balance

### Database Integration
- Create database connection script
- Implement CRUD operations for all entities
- Add proper error handling for database operations

## 6. Security Implementation

### CSRF Protection
- Generate and validate CSRF tokens for all forms
- Add middleware to check tokens on POST requests

### Input Validation
- Validate all user inputs on both frontend and backend
- Sanitize inputs to prevent XSS attacks
- Implement proper error handling

### Session Security
- Use secure session configuration
- Implement session timeout
- Add session regeneration on login

## 7. Testing Plan

### Payment Simulation
- Test deposit flow with Chapa test mode
- Verify webhook handling
- Test payment verification endpoint
- Simulate various payment scenarios

### Withdrawal Testing
- Test withdrawal validation
- Verify fraud detection
- Test admin approval workflow
- Check balance updates

### Security Testing
- Test CSRF protection
- Verify input validation
- Check session management
- Test rate limiting