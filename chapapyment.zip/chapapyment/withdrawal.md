# Withdrawal Functionality Implementation

## Frontend Implementation

### Update HTML Structure
Add proper IDs and structure to the withdrawal section in the HTML file:

```html
<!-- Withdraw Section -->
<div id="withdraw-section" class="content-section" style="display: none;">
    <div class="section">
        <h2>Instant Withdraw</h2>
        <div>Process Time: Instant</div>
        
        <div>
            <div>Min. Amount: 50 ETB</div>
            <div>Max. Amount: 50000 ETB</div>
        </div>
        
        <div class="amount-grid">
            <div class="amount-option" data-amount="200">200 ETB</div>
            <div class="amount-option" data-amount="500">500 ETB</div>
            <div class="amount-option" data-amount="1000">1000 ETB</div>
            <div class="amount-option" data-amount="2500">2500 ETB</div>
            <div class="amount-option" data-amount="5000">5000 ETB</div>
            <div class="amount-option" data-amount="10000">10000 ETB</div>
        </div>
        
        <input type="number" class="amount-input" id="withdraw-amount" placeholder="Select or type in the amount to be withdrawn" value="200">
        
        <!-- Add account details input -->
        <input type="text" class="amount-input" id="withdraw-account" placeholder="Enter account number or phone number">
        
        <button class="action-btn" id="withdraw-btn">WITHDRAW</button>
        
        <!-- Add feedback messages -->
        <div class="payment-message payment-success" id="withdraw-success-message">Withdrawal request submitted successfully!</div>
        <div class="payment-message payment-error" id="withdraw-error-message">Withdrawal failed. Please try again.</div>
        <div class="payment-message payment-info" id="withdraw-info-message">Processing withdrawal request...</div>
        <div class="spinner" id="withdraw-spinner"></div>
    </div>
</div>
```

## Backend Implementation

### Withdrawal API Endpoint (withdraw.php)
```php
<?php
/**
 * Withdrawal API Endpoint
 * Handles withdrawal requests from users
 */

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../models/WithdrawalRequest.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: ' . DOMAIN_URL);
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed. Use POST.'
    ]);
    exit;
}

// Get input data
$input = json_decode(file_get_contents('php://input'), true);

// Validate input
if (!$input || !isset($input['amount']) || !isset($input['account_details'])) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => 'Amount and account details are required'
    ]);
    exit;
}

$amount = floatval($input['amount']);
$accountDetails = $input['account_details'];
$paymentMethod = $input['payment_method'] ?? 'bank_transfer';
$user_id = $_SESSION['user_id'] ?? null; // This will require session management

// Validate user authentication
if (!$user_id) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'error' => 'User not authenticated'
    ]);
    exit;
}

// Validate amount
if ($amount < 50 || $amount > 50000) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => 'Amount must be between 50 and 50,000 ETB'
    ]);
    exit;
}

// Initialize database connection
$database = new Database();
$db = $database->getConnection();

// Get user information
$user = new User($db);
$userData = $user->getUserById($user_id);

if (!$userData) {
    http_response_code(404);
    echo json_encode([
        'success' => false,
        'error' => 'User not found'
    ]);
    exit;
}

// Check if user has sufficient balance
if ($userData['balance'] < $amount) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => 'Insufficient balance'
    ]);
    exit;
}

// Perform fraud checks
$fraudCheck = performFraudChecks($user_id, $amount, $db);
if (!$fraudCheck['passed']) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => 'Transaction flagged by fraud detection: ' . $fraudCheck['reason']
    ]);
    exit;
}

// Create withdrawal request
$withdrawalRequest = new WithdrawalRequest($db);

try {
    // Create the withdrawal request in the database
    $requestCreated = $withdrawalRequest->createRequest($user_id, $amount, $paymentMethod, $accountDetails);
    
    if ($requestCreated) {
        // Deduct amount from user balance (this should be done in a transaction in production)
        $user->updateBalance($user_id, $amount, 'subtract');
        
        echo json_encode([
            'success' => true,
            'message' => 'Withdrawal request submitted successfully',
            'request_id' => $db->lastInsertId()
        ]);
    } else {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => 'Failed to create withdrawal request'
        ]);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Internal server error: ' . $e->getMessage()
    ]);
}

/**
 * Perform fraud checks for withdrawal requests
 */
function performFraudChecks($user_id, $amount, $db) {
    // Check for suspicious amounts
    if ($amount > 10000) {
        return [
            'passed' => false,
            'reason' => 'Amount exceeds fraud threshold'
        ];
    }
    
    // Check for rapid successive transactions
    $recentTransactions = getRecentWithdrawalsByUser($user_id, $db);
    if (count($recentTransactions) > 3) {
        return [
            'passed' => false,
            'reason' => 'Too many recent withdrawal requests'
        ];
    }
    
    // Check if amount is significantly different from user's typical transactions
    $avgAmount = getAverageWithdrawalAmount($user_id, $db);
    if ($avgAmount > 0 && $amount > ($avgAmount * 5)) {
        return [
            'passed' => false,
            'reason' => 'Amount significantly higher than typical withdrawals'
        ];
    }
    
    // All fraud checks passed
    return [
        'passed' => true,
        'reason' => 'No fraud indicators detected'
    ];
}

/**
 * Get recent withdrawal requests for a user
 */
function getRecentWithdrawalsByUser($user_id, $db) {
    $query = "SELECT * FROM withdrawal_requests 
              WHERE user_id = :user_id 
              AND requested_at > DATE_SUB(NOW(), INTERVAL 1 HOUR)";
    
    $stmt = $db->prepare($query);
    $stmt->bindParam(':user_id', $user_id);
    $stmt->execute();
    
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * Get average withdrawal amount for a user
 */
function getAverageWithdrawalAmount($user_id, $db) {
    $query = "SELECT AVG(amount) as avg_amount FROM withdrawal_requests 
              WHERE user_id = :user_id 
              AND status = 'approved'";
    
    $stmt = $db->prepare($query);
    $stmt->bindParam(':user_id', $user_id);
    $stmt->execute();
    
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result['avg_amount'] ?? 0;
}
?>
```

## Updated JavaScript Functions

### Withdrawal Functions
```javascript
// Initiate Withdraw Payment
function initiateWithdraw() {
    // Get amount and account details
    const amount = document.getElementById('withdraw-amount').value;
    const accountDetails = document.getElementById('withdraw-account').value;
    
    // Validate amount
    const validation = validateAmount(amount, 50, 50000);
    
    if (!validation.valid) {
        showPaymentMessage('withdraw-error-message', validation.message, 'error');
        return;
    }
    
    // Validate account details
    if (!accountDetails || accountDetails.trim().length < 5) {
        showPaymentMessage('withdraw-error-message', 'Please enter valid account details', 'error');
        return;
    }
    
    // Hide previous messages
    hidePaymentMessage('withdraw-error-message');
    hidePaymentMessage('withdraw-success-message');
    
    // Show loading
    toggleLoading('withdraw-btn', 'withdraw-spinner', true);
    showPaymentMessage('withdraw-info-message', 'Processing withdrawal request...', 'info');
    
    // Perform fraud checks
    const fraudChecks = performFraudChecks(amount, 'withdraw');
    if (fraudChecks.warnings.length > 0) {
        console.warn('Fraud warnings:', fraudChecks.warnings);
    }
    
    // Send withdrawal request to backend
    processWithdrawal(amount, accountDetails);
}

// Process withdrawal with backend
async function processWithdrawal(amount, accountDetails) {
    try {
        const response = await fetch(CHAPA_CONFIG.baseUrl + 'withdraw.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                amount: amount,
                account_details: accountDetails,
                payment_method: 'bank_transfer'
            })
        });
        
        const result = await response.json();
        
        // Hide loading
        toggleLoading('withdraw-btn', 'withdraw-spinner', false);
        hidePaymentMessage('withdraw-info-message');
        
        if (response.ok && result.success) {
            showPaymentMessage('withdraw-success-message', result.message, 'success');
            
            // Reset form after success
            setTimeout(() => {
                document.getElementById('withdraw-amount').value = '200';
                document.getElementById('withdraw-account').value = '';
                hidePaymentMessage('withdraw-success-message');
            }, 5000);
        } else {
            showPaymentMessage('withdraw-error-message', result.error || 'Withdrawal failed', 'error');
        }
    } catch (error) {
        console.error('Error processing withdrawal:', error);
        
        // Hide loading
        toggleLoading('withdraw-btn', 'withdraw-spinner', false);
        hidePaymentMessage('withdraw-info-message');
        showPaymentMessage('withdraw-error-message', 'Unable to process withdrawal. Please try again.', 'error');
    }
}

// Enhanced fraud prevention and validation
function performFraudChecks(amount, paymentType) {
    const checks = {
        passed: true,
        warnings: []
    };
    
    // Check for suspicious amounts
    if (amount > 10000) {
        checks.warnings.push('Large amount transaction');
    }
    
    // Check for rapid successive transactions
    const lastPaymentTime = localStorage.getItem('lastPaymentTime');
    const currentTime = Date.now();
    
    if (lastPaymentTime && (currentTime - parseInt(lastPaymentTime)) < 30000) {
        checks.warnings.push('Rapid successive transactions detected');
    }
    
    // Store current payment time
    localStorage.setItem('lastPaymentTime', currentTime.toString());
    
    // Additional withdrawal-specific checks
    if (paymentType === 'withdraw') {
        // Check if amount is a round number (often indicates automated/bot activity)
        if (amount % 1000 === 0 && amount >= 1000) {
            checks.warnings.push('Round number amount detected');
        }
    }
    
    return checks;
}
```

## Security Considerations

1. **Rate Limiting**: Implement rate limiting for withdrawal requests
2. **Session Management**: Ensure proper user authentication
3. **Input Validation**: Validate all inputs on both frontend and backend
4. **CSRF Protection**: Add CSRF tokens to withdrawal requests
5. **Fraud Detection**: Enhanced fraud detection for withdrawals
6. **Audit Trail**: Log all withdrawal requests for monitoring

## Validation Rules

1. **Amount Validation**:
   - Minimum: 50 ETB
   - Maximum: 50,000 ETB
   - Must be numeric
   - Must be available in user's balance

2. **Account Details Validation**:
   - Required field
   - Minimum 5 characters
   - Should be validated based on payment method

3. **User Authentication**:
   - User must be logged in
   - Session must be valid
   - CSRF token validation

4. **Fraud Prevention**:
   - Rate limiting (max 3 withdrawals per hour)
   - Large amount verification
   - Pattern analysis