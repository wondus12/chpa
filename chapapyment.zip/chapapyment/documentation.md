# Chapa Banking App Documentation

## Table of Contents
1. [Setup Guide](#setup-guide)
2. [Security Implementation](#security-implementation)
3. [API Usage](#api-usage)
4. [Database Schema](#database-schema)
5. [Frontend Components](#frontend-components)
6. [Troubleshooting](#troubleshooting)

## Setup Guide

### System Requirements
- PHP 7.4 or higher
- MySQL 5.7 or higher
- Apache or Nginx web server
- Composer (for PHP dependencies)
- Node.js and npm (for frontend build tools, if needed)

### Installation Steps

1. **Clone the Repository**
   ```bash
   git clone https://github.com/your-username/chapa-banking-app.git
   cd chapa-banking-app
   ```

2. **Install PHP Dependencies**
   ```bash
   composer install
   ```

3. **Database Setup**
   - Create a MySQL database:
     ```sql
     CREATE DATABASE chapa_banking;
     ```
   - Import the database schema from `database/schema.sql`
   - Update database credentials in `config.php`

4. **Configure Environment**
   - Copy `config.example.php` to `config.php`
   - Update the configuration values:
     ```php
     define('DB_HOST', 'localhost');
     define('DB_NAME', 'chapa_banking');
     define('DB_USER', 'your_db_user');
     define('DB_PASS', 'your_db_password');
     define('CHAPA_SECRET_KEY', 'your_chapa_secret_key');
     define('DOMAIN_URL', 'https://yourdomain.com');
     ```

5. **Set Permissions**
   ```bash
   chmod 755 -R logs/
   chmod 600 config.php
   ```

6. **Web Server Configuration**
   - Configure your web server to point to the project root
   - Ensure `.htaccess` files are processed (for Apache)
   - For Nginx, ensure proper routing to `index.php`

7. **SSL Configuration (Recommended)**
   - Obtain an SSL certificate
   - Configure your web server to use HTTPS
   - Update `DOMAIN_URL` in `config.php` to use `https://`

### Configuration File (config.php)
```php
<?php
/**
 * Chapa Banking App Configuration
 */

// Database Configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'chapa_banking');
define('DB_USER', 'your_db_user');
define('DB_PASS', 'your_db_password');

// Chapa Configuration
define('CHAPA_SECRET_KEY', 'your_chapa_secret_key');
define('CHAPA_PUBLIC_KEY', 'your_chapa_public_key');

// Domain Configuration
define('DOMAIN_URL', 'https://yourdomain.com');

// Security Configuration
define('IS_PRODUCTION', false); // Set to true in production
define('MIN_DEPOSIT_AMOUNT', 1);
define('MAX_DEPOSIT_AMOUNT', 100000);

// Session Configuration
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_secure', 1);
ini_set('session.cookie_samesite', 'Strict');

// Error Reporting
if (!IS_PRODUCTION) {
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', 0);
    ini_set('log_errors', 1);
    error_reporting(E_ALL);
}
?>
```

## Security Implementation

### Authentication Security
- Passwords are hashed using `password_hash()` with bcrypt
- Sessions are secured with HTTP-only, secure, and SameSite cookies
- Session regeneration to prevent fixation attacks
- Login attempt rate limiting

### CSRF Protection
- Synchronizer token pattern implementation
- Double submit cookie pattern as fallback
- Token validation on all state-changing operations
- Automatic token regeneration

### Input Validation and Sanitization
- All user inputs are validated and sanitized
- Prepared statements for all database queries
- XSS prevention through output encoding
- Content Security Policy headers

### Fraud Detection
- Transaction amount analysis
- Frequency monitoring
- IP and device tracking
- User behavior analysis
- Risk scoring system

### Rate Limiting
- Configurable limits per action type
- Database-based tracking
- Automatic expiration
- IP-based and user-based limits

### Data Encryption
- Passwords hashed with bcrypt
- Sensitive data encrypted at rest (if implemented)
- SSL/TLS for data in transit
- Secure session storage

## API Usage

### Authentication
All API endpoints require proper authentication through sessions. Admin endpoints require additional admin privileges.

### Common Response Format
```json
{
  "success": true,
  "message": "Success message",
  "data": {}
}
```

Error responses:
```json
{
  "success": false,
  "error": "Error message"
}
```

### API Endpoints

#### Payment Verification
```
POST /api/verify-payment.php
```
**Request Body:**
```json
{
  "tx_ref": "transaction_reference",
  "payment_type": "deposit|withdrawal"
}
```

**Response:**
```json
{
  "success": true,
  "status": "success|failed",
  "data": {
    "amount": 1000,
    "currency": "ETB",
    "tx_ref": "transaction_reference"
  }
}
```

#### Webhook Handler
```
POST /api/webhook.php
```
**Headers:**
- `X-Chapa-Signature`: HMAC signature for verification

**Request Body:**
```json
{
  "event": "payment.success",
  "data": {
    "tx_ref": "transaction_reference",
    "amount": 1000,
    "currency": "ETB"
  }
}
```

#### Withdrawal Request
```
POST /api/withdraw.php
```
**Request Body:**
```json
{
  "amount": 500,
  "account_details": "account_or_phone_number",
  "payment_method": "bank_transfer|mobile_money"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Withdrawal request submitted successfully",
  "request_id": 12345
}
```

#### Transaction History
```
GET /api/transactions.php
```
**Query Parameters:**
- `date_from`: Start date (YYYY-MM-DD)
- `date_to`: End date (YYYY-MM-DD)
- `status`: Transaction status (pending|completed|failed)
- `type`: Transaction type (deposit|withdrawal)
- `search`: Search term
- `limit`: Number of records (default: 50, max: 100)
- `offset`: Pagination offset

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "transaction_type": "deposit",
      "amount": 1000,
      "status": "completed",
      "tx_ref": "tx-12345",
      "created_at": "2023-01-01 12:00:00"
    }
  ],
  "pagination": {
    "total": 100,
    "limit": 50,
    "offset": 0,
    "pages": 2
  }
}
```

#### Balance Check
```
GET /api/balance.php
```
**Response:**
```json
{
  "success": true,
  "data": {
    "balance": 5000,
    "currency": "ETB",
    "last_updated": "2023-01-01 12:00:00"
  }
}
```

#### Admin Endpoints

##### Get Withdrawal Requests
```
GET /api/admin/withdrawal-requests.php
```
**Query Parameters:**
- `status`: Request status (pending|approved|rejected)
- `date_from`: Start date
- `date_to`: End date
- `search`: Search term
- `limit`: Number of records
- `offset`: Pagination offset

##### Approve Withdrawal Request
```
POST /api/admin/approve-withdrawal.php
```
**Request Body:**
```json
{
  "request_id": 123,
  "admin_notes": "Approved for processing"
}
```

##### Reject Withdrawal Request
```
POST /api/admin/reject-withdrawal.php
```
**Request Body:**
```json
{
  "request_id": 123,
  "admin_notes": "Insufficient funds"
}
```

## Database Schema

### Users Table
```sql
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    balance DECIMAL(10, 2) DEFAULT 0.00,
    role ENUM('user', 'admin') DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

### Transactions Table
```sql
CREATE TABLE transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    transaction_type ENUM('deposit', 'withdrawal') NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    status ENUM('pending', 'completed', 'failed', 'cancelled') DEFAULT 'pending',
    tx_ref VARCHAR(100) UNIQUE,
    chapa_tx_ref VARCHAR(100),
    payment_method VARCHAR(50),
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);
```

### Withdrawal Requests Table
```sql
CREATE TABLE withdrawal_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    payment_method VARCHAR(50),
    account_details TEXT,
    admin_notes TEXT,
    requested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    processed_at TIMESTAMP NULL,
    processed_by INT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (processed_by) REFERENCES users(id)
);
```

### Additional Security Tables

#### Rate Limits Table
```sql
CREATE TABLE rate_limits (
    id INT AUTO_INCREMENT PRIMARY KEY,
    rate_limit_key VARCHAR(255) UNIQUE NOT NULL,
    count INT DEFAULT 1,
    expires_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

#### Blacklisted IPs Table
```sql
CREATE TABLE blacklisted_ips (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ip_address VARCHAR(45) NOT NULL,
    reason TEXT,
    expires_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

#### Fraud Detection Logs Table
```sql
CREATE TABLE fraud_detection_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    transaction_type ENUM('deposit', 'withdrawal') NOT NULL,
    fraud_level ENUM('no_risk', 'low_risk', 'medium_risk', 'high_risk') NOT NULL,
    score INT NOT NULL,
    details JSON,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);
```

## Frontend Components

### HTML Structure
The frontend is built with vanilla JavaScript and Bootstrap for responsive design. Key components include:

1. **Deposit Section**
   - Amount selection grid
   - Custom amount input
   - Chapa payment integration
   - Success/error feedback

2. **Withdrawal Section**
   - Amount selection grid
   - Custom amount input
   - Account details input
   - Validation and submission

3. **Transaction History**
   - Filterable table with date, status, and type filters
   - Search functionality
   - Pagination controls

4. **Admin Panel**
   - Withdrawal request management
   - Approval/rejection workflow
   - Statistics dashboard

### JavaScript Modules

#### Payment Processing
```javascript
// Initialize Chapa payment
function initiateDeposit() {
    // Validate amount
    // Generate transaction reference
    // Initialize Chapa SDK
    // Handle payment callback
}
```

#### Transaction History
```javascript
// Load and display transactions
class TransactionHistory {
    loadTransactions() { /* ... */ }
    applyFilters() { /* ... */ }
    renderTransactions() { /* ... */ }
}
```

#### Real-time Balance Updates
```javascript
// WebSocket connection for balance updates
class BalanceUpdater {
    connect() { /* ... */ }
    updateBalanceDisplay() { /* ... */ }
}
```

## Troubleshooting

### Common Issues

#### Database Connection Error
- Check database credentials in `config.php`
- Ensure MySQL service is running
- Verify database exists and user has proper permissions

#### Chapa Payment Not Working
- Verify Chapa public and secret keys in `config.php`
- Check that webhook URL is correctly configured in Chapa dashboard
- Ensure SSL is properly configured for production

#### Session Issues
- Check session configuration in `config.php`
- Ensure `logs/` directory is writable
- Verify cookie settings match your domain

#### CSRF Token Errors
- Ensure forms include CSRF token fields
- Check that session is properly started
- Verify CSRF middleware is included in API endpoints

### Logging
- Application logs: `logs/application.log`
- Error logs: `logs/errors.log`
- Transaction logs: `logs/transactions.log`
- Webhook logs: `logs/webhooks.log`

### Debugging Tips
1. Enable debug mode by setting `IS_PRODUCTION` to `false` in `config.php`
2. Check browser console for JavaScript errors
3. Review server error logs
4. Use the API status endpoint at `/api/status.php` to check system health

### Performance Optimization
1. Enable OPcache for PHP
2. Use database indexing for frequently queried columns
3. Implement caching for static content
4. Optimize images and frontend assets
5. Use CDN for static resources in production

## Maintenance

### Regular Tasks
1. **Database Cleanup**: Regularly clean up old logs and expired sessions
2. **Security Updates**: Keep PHP and dependencies up to date
3. **Backup**: Regular database and file backups
4. **Monitoring**: Monitor logs for suspicious activity

### Backup Strategy
```bash
# Database backup
mysqldump -u username -p chapa_banking > backups/chapa_banking_$(date +%Y%m%d).sql

# File backup
tar -czf backups/chapa_banking_files_$(date +%Y%m%d).tar.gz chapapyment/
```

### Update Procedure
1. Backup current installation
2. Pull latest changes from repository
3. Run database migrations if needed
4. Update dependencies with `composer update`
5. Test all functionality
6. Monitor logs for issues

## Support
For support, please contact:
- Email: support@yourdomain.com
- Documentation: https://yourdomain.com/docs
- GitHub Issues: https://github.com/your-username/chapa-banking-app/issues