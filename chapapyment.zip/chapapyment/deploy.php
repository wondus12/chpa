<?php
/**
 * Simple deployment script for bochboch.com
 * Run this after uploading files to verify everything is working
 */

echo "🚀 BochBoch Banking App Deployment Verification\n";
echo "===============================================\n\n";

// Check PHP version
echo "📋 System Check:\n";
echo "PHP Version: " . PHP_VERSION . "\n";

// Check required extensions
$required_extensions = ['curl', 'json', 'mbstring'];
foreach ($required_extensions as $ext) {
    $status = extension_loaded($ext) ? '✅' : '❌';
    echo "Extension $ext: $status\n";
}

// Check file permissions
echo "\n📁 File Check:\n";
$required_files = [
    'index.php',
    'chapa-integrated-banking-app.html',
    'config.php',
    'api/verify-payment.php',
    'api/webhook.php',
    'api/status.php'
];

foreach ($required_files as $file) {
    $status = file_exists($file) ? '✅' : '❌';
    echo "File $file: $status\n";
}

// Check logs directory
echo "\n📝 Logs Directory:\n";
$logs_dir = __DIR__ . '/logs';
if (!is_dir($logs_dir)) {
    mkdir($logs_dir, 0755, true);
    echo "Created logs directory: ✅\n";
} else {
    echo "Logs directory exists: ✅\n";
}

$writable = is_writable($logs_dir) ? '✅' : '❌';
echo "Logs directory writable: $writable\n";

// Load and check configuration
echo "\n⚙️  Configuration Check:\n";
require_once 'config.php';

echo "Domain URL: " . DOMAIN_URL . "\n";
echo "Environment: " . (IS_PRODUCTION ? 'Production' : 'Development') . "\n";
echo "Chapa Test Mode: " . (CHAPA_TEST_MODE ? 'Yes' : 'No') . "\n";
echo "Public Key: " . substr(CHAPA_PUBLIC_KEY, 0, 20) . "...\n";

// Test API endpoints
echo "\n🔧 API Endpoint Test:\n";

// Test verify-payment endpoint
$test_data = json_encode(['tx_ref' => 'test-' . time(), 'simulate' => true]);
$context = stream_context_create([
    'http' => [
        'method' => 'POST',
        'header' => 'Content-Type: application/json',
        'content' => $test_data
    ]
]);

$api_url = DOMAIN_URL . '/api/verify-payment.php';
echo "Testing: $api_url\n";

$response = @file_get_contents($api_url, false, $context);
if ($response) {
    $result = json_decode($response, true);
    $status = $result && isset($result['success']) ? '✅' : '❌';
    echo "Payment verification API: $status\n";
} else {
    echo "Payment verification API: ❌ (Could not connect)\n";
}

// Test status endpoint
$status_url = DOMAIN_URL . '/api/status.php';
$status_response = @file_get_contents($status_url);
$status_ok = $status_response ? '✅' : '❌';
echo "Status API: $status_ok\n";

// Security recommendations
echo "\n🔐 Security Recommendations:\n";
echo "1. Enable HTTPS for production (" . (IS_PRODUCTION ? 'Required' : 'Recommended') . ")\n";
echo "2. Update Chapa keys for production\n";
echo "3. Set up database for user management\n";
echo "4. Configure email notifications\n";
echo "5. Set up monitoring and backups\n";

// Next steps
echo "\n🎯 Next Steps:\n";
echo "1. Visit: " . DOMAIN_URL . "/\n";
echo "2. Test banking app: " . DOMAIN_URL . "/chapa-integrated-banking-app.html\n";
echo "3. Run test suite: " . DOMAIN_URL . "/test-cases.html\n";
echo "4. Check API status: " . DOMAIN_URL . "/api/status.php?format=html\n";

if (IS_PRODUCTION) {
    echo "\n⚠️  PRODUCTION ENVIRONMENT DETECTED\n";
    echo "Make sure to:\n";
    echo "- Update Chapa keys to production keys\n";
    echo "- Enable HTTPS\n";
    echo "- Configure proper database\n";
    echo "- Set up monitoring\n";
}

echo "\n✅ Deployment verification complete!\n";
echo "Your banking app should be ready at: " . DOMAIN_URL . "\n";
?>