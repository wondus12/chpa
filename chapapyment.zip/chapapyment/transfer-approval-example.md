# Transfer Approval URL Documentation

## Overview
The Transfer Approval URL endpoint (`/api/transfer-approval.php`) provides enhanced security for transfer approval requests with secret key validation, rate limiting, and comprehensive logging.

## 🔑 Your Generated Approval Secret Key
```
63ea505949dfcce10ff723551416c351aefca28c9bf171ad2e10ff6af442054c
```

## Features
- **Approval Secret Key**: Automatically generated 64-character hex secret key
- **Rate Limiting**: 10 requests per 5-minute window per IP
- **Transfer Limits**: 1M ETB per transaction, 5M ETB daily limit
- **Account Validation**: Basic account number format validation
- **Comprehensive Logging**: All approval activities logged
- **CORS Support**: Cross-origin requests enabled

## API Endpoints

### POST /api/transfer-approval.php
Process a transfer approval request.

**Headers:**
```
Content-Type: application/json
X-Approval-Secret: 63ea505949dfcce10ff723551416c351aefca28c9bf171ad2e10ff6af442054c
```

**Request Body:**
```json
{
    "transfer_id": "TXN_123456789",
    "amount": 50000,
    "currency": "ETB",
    "sender_account": "1234567890123456",
    "receiver_account": "9876543210987654",
    "purpose": "Business payment"
}
```

**Success Response (200):**
```json
{
    "success": true,
    "status": "approved",
    "approval_token": "a1b2c3d4e5f6...",
    "transfer_id": "TXN_123456789",
    "approved_amount": 50000,
    "currency": "ETB",
    "approval_time": "2025-08-17 09:40:15",
    "expires_at": "2025-08-17 10:40:15"
}
```

**Error Responses:**
- `401`: Invalid approval secret key
- `400`: Invalid request data or validation failed
- `403`: Transfer limits exceeded
- `429`: Rate limit exceeded

### GET /api/transfer-approval.php?get_secret
Get the approval secret key (development mode only).

**Response:**
```json
{
    "success": true,
    "approval_secret": "63ea505949dfcce10ff723551416c351aefca28c9bf171ad2e10ff6af442054c",
    "note": "This endpoint is only available in development mode"
}
```

## 📋 Chapa Dashboard Configuration

**Transfer Approval URL:**
```
https://yourdomain.com/api/transfer-approval.php
```

**Approval Secret Key:**
```
63ea505949dfcce10ff723551416c351aefca28c9bf171ad2e10ff6af442054c
```

## Usage Examples

### JavaScript/Fetch Example
```javascript
// Use your generated approval secret
const approvalSecret = '63ea505949dfcce10ff723551416c351aefca28c9bf171ad2e10ff6af442054c';

// Make transfer approval request
const transferData = {
    transfer_id: 'TXN_' + Date.now(),
    amount: 25000,
    currency: 'ETB',
    sender_account: '1234567890123456',
    receiver_account: '9876543210987654',
    purpose: 'Salary payment'
};

const response = await fetch('/api/transfer-approval.php', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
        'X-Approval-Secret': approvalSecret
    },
    body: JSON.stringify(transferData)
});

const result = await response.json();
console.log('Approval result:', result);
```

### PHP/cURL Example
```php
<?php
// Use your generated approval secret
$approvalSecret = '63ea505949dfcce10ff723551416c351aefca28c9bf171ad2e10ff6af442054c';

// Prepare transfer data
$transferData = [
    'transfer_id' => 'TXN_' . time(),
    'amount' => 75000,
    'currency' => 'ETB',
    'sender_account' => '1234567890123456',
    'receiver_account' => '9876543210987654',
    'purpose' => 'Invoice payment'
];

// Make approval request
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'http://localhost/api/transfer-approval.php');
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($transferData));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'X-Approval-Secret: ' . $approvalSecret
]);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$response = curl_exec($ch);
$result = json_decode($response, true);
curl_close($ch);

echo "Approval result: " . json_encode($result, JSON_PRETTY_PRINT);
?>
```

### Python Example
```python
import requests
import json

# Use your generated approval secret
approval_secret = '63ea505949dfcce10ff723551416c351aefca28c9bf171ad2e10ff6af442054c'

# Transfer data
transfer_data = {
    'transfer_id': f'TXN_{int(time.time())}',
    'amount': 100000,
    'currency': 'ETB',
    'sender_account': '1234567890123456',
    'receiver_account': '9876543210987654',
    'purpose': 'Equipment purchase'
}

# Make approval request
headers = {
    'Content-Type': 'application/json',
    'X-Approval-Secret': approval_secret
}

response = requests.post(
    'http://localhost/api/transfer-approval.php',
    headers=headers,
    json=transfer_data
)

result = response.json()
print(f"Approval result: {json.dumps(result, indent=2)}")
```

### cURL Command Line Test
```bash
curl -X POST "http://localhost/api/transfer-approval.php" \
  -H "Content-Type: application/json" \
  -H "X-Approval-Secret: 63ea505949dfcce10ff723551416c351aefca28c9bf171ad2e10ff6af442054c" \
  -d '{
    "transfer_id": "TXN_123456789",
    "amount": 50000,
    "currency": "ETB",
    "sender_account": "1234567890123456",
    "receiver_account": "9876543210987654",
    "purpose": "Test payment"
  }'
```

## Security Features

### Approval Secret Key
- Automatically generated 64-character hexadecimal key
- Stored in `.approval_secret` file with restricted permissions (600)
- Required in `X-Approval-Secret` header for all requests
- Uses `hash_equals()` for timing-safe comparison

### Rate Limiting
- 10 requests per 5-minute window per IP address
- Rate limit data stored in temporary files
- Automatic cleanup of expired entries

### Transfer Limits
- Maximum single transaction: 1,000,000 ETB
- Daily transfer limit: 5,000,000 ETB per account
- Currency validation (ETB, USD, EUR supported)

### Logging
- All approval requests logged to `logs/transfer-approval.log`
- Includes timestamp, IP, transfer details, and approval status
- Error logging for debugging and security monitoring

## File Structure
```
/api/transfer-approval.php    # Main endpoint
/.approval_secret            # Secret key file (auto-generated)
/logs/transfer-approval.log  # Activity logs
/logs/rate_limit_*.json     # Rate limiting data
```

## Production Considerations

1. **Database Integration**: Replace file-based daily limits with database queries
2. **Secret Key Management**: Consider using environment variables or secure key management
3. **Enhanced Validation**: Add bank-specific account validation rules
4. **Notification System**: Implement real-time notifications for approvals
5. **Audit Trail**: Enhanced logging with user identification and audit trails
6. **SSL/TLS**: Ensure all requests are made over HTTPS in production

## Testing

Test the endpoint using the provided examples or tools like Postman. In development mode, you can retrieve the approval secret using the `?get_secret` parameter.
