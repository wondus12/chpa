# Enhanced Fraud Detection Implementation

## Fraud Detection Framework

### Fraud Detection Service (security/FraudDetector.php)
```php
<?php
/**
 * Fraud Detection Service
 * Comprehensive fraud detection system for banking transactions
 */

class FraudDetector {
    private $db;
    private $config;
    
    // Fraud detection thresholds
    private const HIGH_AMOUNT_THRESHOLD = 10000;
    private const SUSPICIOUS_AMOUNT_THRESHOLD = 5000;
    private const MAX_DAILY_WITHDRAWALS = 10;
    private const MAX_HOURLY_TRANSACTIONS = 5;
    private const RATE_LIMIT_WINDOW = 3600; // 1 hour
    
    public function __construct($db, $config = []) {
        $this->db = $db;
        $this->config = array_merge([
            'high_amount_threshold' => self::HIGH_AMOUNT_THRESHOLD,
            'suspicious_amount_threshold' => self::SUSPICIOUS_AMOUNT_THRESHOLD,
            'max_daily_withdrawals' => self::MAX_DAILY_WITHDRAWALS,
            'max_hourly_transactions' => self::MAX_HOURLY_TRANSACTIONS
        ], $config);
    }
    
    /**
     * Perform comprehensive fraud check for a transaction
     */
    public function checkTransaction($userId, $amount, $transactionType, $ipAddress = null, $userAgent = null) {
        $fraudScore = 0;
        $warnings = [];
        $details = [];
        
        // 1. Amount-based checks
        $amountCheck = $this->checkAmount($amount);
        if (!$amountCheck['passed']) {
            $fraudScore += $amountCheck['score'];
            $warnings = array_merge($warnings, $amountCheck['warnings']);
            $details['amount_check'] = $amountCheck;
        }
        
        // 2. Frequency-based checks
        $frequencyCheck = $this->checkTransactionFrequency($userId, $transactionType);
        if (!$frequencyCheck['passed']) {
            $fraudScore += $frequencyCheck['score'];
            $warnings = array_merge($warnings, $frequencyCheck['warnings']);
            $details['frequency_check'] = $frequencyCheck;
        }
        
        // 3. IP and device-based checks
        if ($ipAddress) {
            $ipCheck = $this->checkIpAddress($userId, $ipAddress);
            if (!$ipCheck['passed']) {
                $fraudScore += $ipCheck['score'];
                $warnings = array_merge($warnings, $ipCheck['warnings']);
                $details['ip_check'] = $ipCheck;
            }
        }
        
        // 4. User behavior analysis
        $behaviorCheck = $this->checkUserBehavior($userId, $amount);
        if (!$behaviorCheck['passed']) {
            $fraudScore += $behaviorCheck['score'];
            $warnings = array_merge($warnings, $behaviorCheck['warnings']);
            $details['behavior_check'] = $behaviorCheck;
        }
        
        // 5. Time-based checks
        $timeCheck = $this->checkTransactionTiming($userId);
        if (!$timeCheck['passed']) {
            $fraudScore += $timeCheck['score'];
            $warnings = array_merge($warnings, $timeCheck['warnings']);
            $details['time_check'] = $timeCheck;
        }
        
        // Determine fraud level based on score
        $fraudLevel = $this->determineFraudLevel($fraudScore);
        
        return [
            'passed' => $fraudLevel !== 'high_risk',
            'fraud_level' => $fraudLevel,
            'score' => $fraudScore,
            'warnings' => $warnings,
            'details' => $details
        ];
    }
    
    /**
     * Check amount for suspicious patterns
     */
    private function checkAmount($amount) {
        $warnings = [];
        $score = 0;
        
        // Check for high amount
        if ($amount >= $this->config['high_amount_threshold']) {
            $warnings[] = 'High amount transaction detected';
            $score += 50;
        } elseif ($amount >= $this->config['suspicious_amount_threshold']) {
            $warnings[] = 'Moderate amount transaction detected';
            $score += 20;
        }
        
        // Check for round numbers (often indicates automated/bot activity)
        if ($amount % 1000 === 0 && $amount >= 1000) {
            $warnings[] = 'Round number amount detected';
            $score += 15;
        }
        
        // Check for unusual decimal patterns
        $decimalPart = $amount - floor($amount);
        if ($decimalPart == 0.99 || $decimalPart == 0.00) {
            $warnings[] = 'Unusual decimal pattern detected';
            $score += 10;
        }
        
        return [
            'passed' => $score < 30,
            'score' => $score,
            'warnings' => $warnings
        ];
    }
    
    /**
     * Check transaction frequency
     */
    private function checkTransactionFrequency($userId, $transactionType) {
        $warnings = [];
        $score = 0;
        
        // Check hourly transaction count
        $hourlyCount = $this->getTransactionCount($userId, 'hour');
        if ($hourlyCount > $this->config['max_hourly_transactions']) {
            $warnings[] = "High transaction frequency: {$hourlyCount} transactions this hour";
            $score += 30;
        }
        
        // Check daily withdrawal count for withdrawals
        if ($transactionType === 'withdrawal') {
            $dailyWithdrawals = $this->getWithdrawalCount($userId, 'day');
            if ($dailyWithdrawals > $this->config['max_daily_withdrawals']) {
                $warnings[] = "Excessive withdrawals: {$dailyWithdrawals} today";
                $score += 40;
            }
        }
        
        return [
            'passed' => $score < 25,
            'score' => $score,
            'warnings' => $warnings
        ];
    }
    
    /**
     * Check IP address for suspicious activity
     */
    private function checkIpAddress($userId, $ipAddress) {
        $warnings = [];
        $score = 0;
        
        // Check if this is a new IP for the user
        if (!$this->isKnownIpAddress($userId, $ipAddress)) {
            $warnings[] = 'New IP address detected for user';
            $score += 20;
        }
        
        // Check if IP has been associated with failed transactions
        $failedFromIp = $this->getFailedTransactionsFromIp($ipAddress);
        if ($failedFromIp > 3) {
            $warnings[] = "IP address has {$failedFromIp} failed transactions";
            $score += 25;
        }
        
        // Check IP reputation (simplified - in production, use external service)
        if ($this->isBlacklistedIp($ipAddress)) {
            $warnings[] = 'IP address is blacklisted';
            $score += 50;
        }
        
        return [
            'passed' => $score < 30,
            'score' => $score,
            'warnings' => $warnings
        ];
    }
    
    /**
     * Check user behavior patterns
     */
    private function checkUserBehavior($userId, $amount) {
        $warnings = [];
        $score = 0;
        
        // Check if amount is significantly different from user's typical transactions
        $avgAmount = $this->getUserAverageTransactionAmount($userId);
        if ($avgAmount > 0) {
            $deviation = abs($amount - $avgAmount) / $avgAmount;
            if ($deviation > 2) { // More than 200% deviation
                $warnings[] = 'Amount significantly different from user average';
                $score += 25;
            }
        }
        
        // Check time since last transaction
        $timeSinceLast = $this->getTimeSinceLastTransaction($userId);
        if ($timeSinceLast !== null && $timeSinceLast < 30) { // Less than 30 seconds
            $warnings[] = 'Rapid successive transactions detected';
            $score += 20;
        }
        
        // Check for pattern breaking (e.g., user usually deposits but now withdrawing)
        $usualTransactionType = $this->getUserUsualTransactionType($userId);
        // This would need more sophisticated implementation
        
        return [
            'passed' => $score < 30,
            'score' => $score,
            'warnings' => $warnings
        ];
    }
    
    /**
     * Check transaction timing patterns
     */
    private function checkTransactionTiming($userId) {
        $warnings = [];
        $score = 0;
        
        // Check if transaction is happening at unusual hours
        $hour = date('H');
        if (($hour >= 0 && $hour <= 5) || ($hour >= 23 && $hour <= 24)) {
            $warnings[] = 'Transaction at unusual hours detected';
            $score += 15;
        }
        
        // Check for weekend patterns
        $dayOfWeek = date('w');
        if ($dayOfWeek == 0 || $dayOfWeek == 6) {
            // Weekend transaction - not necessarily fraud, but note it
            // Score might be adjusted based on user behavior
        }
        
        return [
            'passed' => $score < 20,
            'score' => $score,
            'warnings' => $warnings
        ];
    }
    
    /**
     * Determine fraud level based on score
     */
    private function determineFraudLevel($score) {
        if ($score >= 70) {
            return 'high_risk';
        } elseif ($score >= 40) {
            return 'medium_risk';
        } elseif ($score >= 20) {
            return 'low_risk';
        } else {
            return 'no_risk';
        }
    }
    
    /**
     * Database helper methods
     */
    private function getTransactionCount($userId, $period = 'hour') {
        $timeClause = '';
        switch ($period) {
            case 'hour':
                $timeClause = "AND created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)";
                break;
            case 'day':
                $timeClause = "AND created_at >= DATE_SUB(NOW(), INTERVAL 1 DAY)";
                break;
            case 'week':
                $timeClause = "AND created_at >= DATE_SUB(NOW(), INTERVAL 1 WEEK)";
                break;
        }
        
        $query = "SELECT COUNT(*) as count FROM transactions 
                  WHERE user_id = :user_id 
                  AND status = 'completed' 
                  {$timeClause}";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':user_id', $userId);
        $stmt->execute();
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['count'] ?? 0;
    }
    
    private function getWithdrawalCount($userId, $period = 'day') {
        $timeClause = '';
        switch ($period) {
            case 'hour':
                $timeClause = "AND created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)";
                break;
            case 'day':
                $timeClause = "AND created_at >= DATE_SUB(NOW(), INTERVAL 1 DAY)";
                break;
            case 'week':
                $timeClause = "AND created_at >= DATE_SUB(NOW(), INTERVAL 1 WEEK)";
                break;
        }
        
        $query = "SELECT COUNT(*) as count FROM transactions 
                  WHERE user_id = :user_id 
                  AND transaction_type = 'withdrawal' 
                  AND status IN ('completed', 'pending') 
                  {$timeClause}";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':user_id', $userId);
        $stmt->execute();
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['count'] ?? 0;
    }
    
    private function isKnownIpAddress($userId, $ipAddress) {
        $query = "SELECT COUNT(*) as count FROM user_ips 
                  WHERE user_id = :user_id 
                  AND ip_address = :ip_address";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':user_id', $userId);
        $stmt->bindParam(':ip_address', $ipAddress);
        $stmt->execute();
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return ($result['count'] ?? 0) > 0;
    }
    
    private function getFailedTransactionsFromIp($ipAddress) {
        $query = "SELECT COUNT(*) as count FROM transactions 
                  WHERE ip_address = :ip_address 
                  AND status = 'failed' 
                  AND created_at >= DATE_SUB(NOW(), INTERVAL 1 DAY)";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':ip_address', $ipAddress);
        $stmt->execute();
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['count'] ?? 0;
    }
    
    private function isBlacklistedIp($ipAddress) {
        $query = "SELECT COUNT(*) as count FROM blacklisted_ips 
                  WHERE ip_address = :ip_address 
                  AND (expires_at IS NULL OR expires_at > NOW())";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':ip_address', $ipAddress);
        $stmt->execute();
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return ($result['count'] ?? 0) > 0;
    }
    
    private function getUserAverageTransactionAmount($userId) {
        $query = "SELECT AVG(amount) as avg_amount FROM transactions 
                  WHERE user_id = :user_id 
                  AND status = 'completed' 
                  AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':user_id', $userId);
        $stmt->execute();
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['avg_amount'] ?? 0;
    }
    
    private function getTimeSinceLastTransaction($userId) {
        $query = "SELECT created_at FROM transactions 
                  WHERE user_id = :user_id 
                  AND status = 'completed' 
                  ORDER BY created_at DESC 
                  LIMIT 1";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':user_id', $userId);
        $stmt->execute();
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($result) {
            $lastTransactionTime = strtotime($result['created_at']);
            return time() - $lastTransactionTime;
        }
        
        return null;
    }
    
    private function getUserUsualTransactionType($userId) {
        $query = "SELECT transaction_type, COUNT(*) as count FROM transactions 
                  WHERE user_id = :user_id 
                  AND status = 'completed' 
                  AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
                  GROUP BY transaction_type 
                  ORDER BY count DESC 
                  LIMIT 1";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':user_id', $userId);
        $stmt->execute();
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['transaction_type'] ?? null;
    }
    
    /**
     * Log fraud detection results
     */
    public function logFraudCheck($userId, $amount, $transactionType, $result) {
        $query = "INSERT INTO fraud_detection_logs 
                  (user_id, amount, transaction_type, fraud_level, score, details, created_at) 
                  VALUES (:user_id, :amount, :transaction_type, :fraud_level, :score, :details, NOW())";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':user_id', $userId);
        $stmt->bindParam(':amount', $amount);
        $stmt->bindParam(':transaction_type', $transactionType);
        $stmt->bindParam(':fraud_level', $result['fraud_level']);
        $stmt->bindParam(':score', $result['score']);
        $stmt->bindParam(':details', json_encode($result));
        $stmt->execute();
    }
}
?>
```

## Rate Limiting System

### Rate Limiter (security/RateLimiter.php)
```php
<?php
/**
 * Rate Limiting System
 * Prevent abuse through rate limiting
 */

class RateLimiter {
    private $db;
    private $limits;
    
    public function __construct($db) {
        $this->db = $db;
        $this->limits = [
            'login' => ['max_requests' => 5, 'window' => 300], // 5 attempts per 5 minutes
            'withdrawal' => ['max_requests' => 3, 'window' => 3600], // 3 withdrawals per hour
            'api' => ['max_requests' => 100, 'window' => 3600], // 100 API requests per hour
            'payment' => ['max_requests' => 10, 'window' => 3600] // 10 payments per hour
        ];
    }
    
    /**
     * Check if a request is allowed
     */
    public function isAllowed($identifier, $action, $increment = true) {
        if (!isset($this->limits[$action])) {
            return true; // No limit defined
        }
        
        $limit = $this->limits[$action];
        $key = $this->getKey($identifier, $action);
        
        // Check current count
        $currentCount = $this->getCurrentCount($key, $limit['window']);
        
        if ($currentCount >= $limit['max_requests']) {
            return false; // Rate limit exceeded
        }
        
        // Increment count if requested
        if ($increment) {
            $this->incrementCount($key);
        }
        
        return true;
    }
    
    /**
     * Get rate limit info
     */
    public function getRateLimitInfo($identifier, $action) {
        if (!isset($this->limits[$action])) {
            return null;
        }
        
        $limit = $this->limits[$action];
        $key = $this->getKey($identifier, $action);
        $currentCount = $this->getCurrentCount($key, $limit['window']);
        
        return [
            'max_requests' => $limit['max_requests'],
            'window' => $limit['window'],
            'current_count' => $currentCount,
            'remaining' => max(0, $limit['max_requests'] - $currentCount),
            'reset_time' => time() + $limit['window']
        ];
    }
    
    private function getKey($identifier, $action) {
        return "rate_limit:{$action}:{$identifier}";
    }
    
    private function getCurrentCount($key, $window) {
        // For database implementation
        $query = "SELECT count FROM rate_limits 
                  WHERE rate_limit_key = :key 
                  AND expires_at > NOW()";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':key', $key);
        $stmt->execute();
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['count'] ?? 0;
    }
    
    private function incrementCount($key) {
        $window = 3600; // Default 1 hour window
        
        $query = "INSERT INTO rate_limits (rate_limit_key, count, expires_at) 
                  VALUES (:key, 1, DATE_ADD(NOW(), INTERVAL :window SECOND))
                  ON DUPLICATE KEY UPDATE 
                  count = count + 1, 
                  expires_at = DATE_ADD(NOW(), INTERVAL :window SECOND)";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':key', $key);
        $stmt->bindParam(':window', $window);
        $stmt->execute();
    }
}
?>
```

## Blacklist System

### IP and User Blacklisting (security/Blacklist.php)
```php
<?php
/**
 * Blacklist System
 * Manage blacklisted IPs and users
 */

class Blacklist {
    private $db;
    
    public function __construct($db) {
        $this->db = $db;
    }
    
    /**
     * Check if IP is blacklisted
     */
    public function isIpBlacklisted($ipAddress) {
        $query = "SELECT COUNT(*) as count FROM blacklisted_ips 
                  WHERE ip_address = :ip_address 
                  AND (expires_at IS NULL OR expires_at > NOW())";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':ip_address', $ipAddress);
        $stmt->execute();
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return ($result['count'] ?? 0) > 0;
    }
    
    /**
     * Check if user is blacklisted
     */
    public function isUserBlacklisted($userId) {
        $query = "SELECT COUNT(*) as count FROM blacklisted_users 
                  WHERE user_id = :user_id 
                  AND (expires_at IS NULL OR expires_at > NOW())";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':user_id', $userId);
        $stmt->execute();
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return ($result['count'] ?? 0) > 0;
    }
    
    /**
     * Add IP to blacklist
     */
    public function blacklistIp($ipAddress, $reason = '', $duration = null) {
        $expiresAt = $duration ? "DATE_ADD(NOW(), INTERVAL {$duration} SECOND)" : 'NULL';
        
        $query = "INSERT INTO blacklisted_ips (ip_address, reason, expires_at, created_at) 
                  VALUES (:ip_address, :reason, {$expiresAt}, NOW())";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':ip_address', $ipAddress);
        $stmt->bindParam(':reason', $reason);
        $stmt->execute();
    }
    
    /**
     * Add user to blacklist
     */
    public function blacklistUser($userId, $reason = '', $duration = null) {
        $expiresAt = $duration ? "DATE_ADD(NOW(), INTERVAL {$duration} SECOND)" : 'NULL';
        
        $query = "INSERT INTO blacklisted_users (user_id, reason, expires_at, created_at) 
                  VALUES (:user_id, :reason, {$expiresAt}, NOW())";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':user_id', $userId);
        $stmt->bindParam(':reason', $reason);
        $stmt->execute();
    }
    
    /**
     * Remove IP from blacklist
     */
    public function whitelistIp($ipAddress) {
        $query = "DELETE FROM blacklisted_ips WHERE ip_address = :ip_address";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':ip_address', $ipAddress);
        $stmt->execute();
    }
    
    /**
     * Remove user from blacklist
     */
    public function whitelistUser($userId) {
        $query = "DELETE FROM blacklisted_users WHERE user_id = :user_id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':user_id', $userId);
        $stmt->execute();
    }
}
?>
```

## Database Schema for Fraud Detection

### Fraud Detection Tables (fraud-schema.sql)
```sql
-- Fraud detection related tables

-- Rate limiting table
CREATE TABLE IF NOT EXISTS rate_limits (
    id INT AUTO_INCREMENT PRIMARY KEY,
    rate_limit_key VARCHAR(255) UNIQUE NOT NULL,
    count INT DEFAULT 1,
    expires_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_rate_limit_key (rate_limit_key),
    INDEX idx_expires_at (expires_at)
);

-- Blacklisted IPs table
CREATE TABLE IF NOT EXISTS blacklisted_ips (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ip_address VARCHAR(45) NOT NULL,
    reason TEXT,
    expires_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_ip_address (ip_address),
    INDEX idx_expires_at (expires_at)
);

-- Blacklisted users table
CREATE TABLE IF NOT EXISTS blacklisted_users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    reason TEXT,
    expires_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_expires_at (expires_at)
);

-- User IP addresses table (for tracking known IPs)
CREATE TABLE IF NOT EXISTS user_ips (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    ip_address VARCHAR(45) NOT NULL,
    first_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_ip (user_id, ip_address),
    INDEX idx_user_id (user_id),
    INDEX idx_ip_address (ip_address)
);

-- Fraud detection logs table
CREATE TABLE IF NOT EXISTS fraud_detection_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    transaction_type ENUM('deposit', 'withdrawal') NOT NULL,
    fraud_level ENUM('no_risk', 'low_risk', 'medium_risk', 'high_risk') NOT NULL,
    score INT NOT NULL,
    details JSON,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_fraud_level (fraud_level),
    INDEX idx_created_at (created_at)
);

-- Failed login attempts table
CREATE TABLE IF NOT EXISTS failed_login_attempts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(100),
    ip_address VARCHAR(45),
    user_agent TEXT,
    reason VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_ip_address (ip_address),
    INDEX idx_created_at (created_at)
);
```

## Integration with Existing Systems

### Updated Withdrawal Function with Fraud Detection
```php
<?php
// Updated withdraw.php with fraud detection

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../models/WithdrawalRequest.php';
require_once __DIR__ . '/../security/FraudDetector.php';
require_once __DIR__ . '/../security/RateLimiter.php';
require_once __DIR__ . '/../session_config.php';

// Start session
startSecureSession();

header('Content-Type: application/json');

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed. Use POST.'
    ]);
    exit;
}

// Validate user authentication
$user_id = $_SESSION['user_id'] ?? null;
if (!$user_id) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'error' => 'User not authenticated'
    ]);
    exit;
}

// Get input data
$input = json_decode(file_get_contents('php://input'), true);

// Validate input
if (!$input || !isset($input['amount']) || !isset($input['account_details'])) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => 'Amount and account details are required'
    ]);
    exit;
}

$amount = floatval($input['amount']);
$accountDetails = $input['account_details'];
$paymentMethod = $input['payment_method'] ?? 'bank_transfer';
$ipAddress = $_SERVER['REMOTE_ADDR'] ?? null;
$userAgent = $_SERVER['HTTP_USER_AGENT'] ?? null;

// Initialize database connection
$database = new Database();
$db = $database->getConnection();

// Rate limiting check
$rateLimiter = new RateLimiter($db);
if (!$rateLimiter->isAllowed($user_id, 'withdrawal')) {
    Logger::warning('Withdrawal rate limit exceeded', [
        'user_id' => $user_id,
        'ip_address' => $ipAddress
    ]);
    
    http_response_code(429);
    echo json_encode([
        'success' => false,
        'error' => 'Rate limit exceeded. Please try again later.'
    ]);
    exit;
}

// Fraud detection
$fraudDetector = new FraudDetector($db);
$fraudCheck = $fraudDetector->checkTransaction($user_id, $amount, 'withdrawal', $ipAddress, $userAgent);

// Log fraud check
$fraudDetector->logFraudCheck($user_id, $amount, 'withdrawal', $fraudCheck);

// Handle high-risk transactions
if ($fraudCheck['fraud_level'] === 'high_risk') {
    Logger::warning('High-risk withdrawal attempt blocked', [
        'user_id' => $user_id,
        'amount' => $amount,
        'ip_address' => $ipAddress,
        'fraud_score' => $fraudCheck['score']
    ]);
    
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => 'Transaction flagged as high-risk. Please contact support.'
    ]);
    exit;
}

// Handle medium-risk transactions (require additional verification)
if ($fraudCheck['fraud_level'] === 'medium_risk') {
    // Could implement 2FA or email verification here
    Logger::info('Medium-risk withdrawal detected', [
        'user_id' => $user_id,
        'amount' => $amount,
        'ip_address' => $ipAddress,
        'fraud_score' => $fraudCheck['score']
    ]);
}

// Continue with normal withdrawal processing...
// (rest of the existing withdrawal logic)
?>
```

## Frontend Integration

### JavaScript Fraud Detection Integration
```javascript
// Enhanced fraud detection in frontend
class FraudDetection {
    constructor() {
        this.suspiciousPatterns = [
            'roundNumberAmount',
            'rapidTransactions',
            'unusualHours',
            'highAmount'
        ];
    }
    
    // Check for suspicious amount patterns
    checkAmountPattern(amount) {
        const warnings = [];
        
        // Check for round numbers
        if (amount % 1000 === 0 && amount >= 1000) {
            warnings.push('Round number amount detected');
        }
        
        // Check for unusual decimal patterns
        const decimalPart = amount - Math.floor(amount);
        if (decimalPart == 0.99 || decimalPart == 0.00) {
            warnings.push('Unusual decimal pattern detected');
        }
        
        return warnings;
    }
    
    // Check for rapid transactions
    checkRapidTransactions() {
        const lastTransactionTime = localStorage.getItem('lastTransactionTime');
        const currentTime = Date.now();
        
        if (lastTransactionTime && (currentTime - parseInt(lastTransactionTime)) < 30000) {
            return ['Rapid successive transactions detected'];
        }
        
        // Store current transaction time
        localStorage.setItem('lastTransactionTime', currentTime.toString());
        return [];
    }
    
    // Perform client-side fraud checks
    performClientChecks(amount) {
        const warnings = [];
        
        // Check amount patterns
        warnings.push(...this.checkAmountPattern(amount));
        
        // Check rapid transactions
        warnings.push(...this.checkRapidTransactions());
        
        // Check for unusual hours (simplified)
        const hour = new Date().getHours();
        if ((hour >= 0 && hour <= 5) || (hour >= 23)) {
            warnings.push('Transaction at unusual hours detected');
        }
        
        return warnings;
    }
    
    // Show fraud warnings to user
    showFraudWarnings(warnings) {
        if (warnings.length > 0) {
            const warningMessage = 'Potential security concerns detected:\n' + 
                                 warnings.join('\n') + 
                                 '\n\nDo you want to continue?';
            
            return confirm(warningMessage);
        }
        return true;
    }
}

// Usage in withdrawal process
const fraudDetection = new FraudDetection();

function initiateWithdraw() {
    const amount = document.getElementById('withdraw-amount').value;
    const accountDetails = document.getElementById('withdraw-account').value;
    
    // Perform client-side fraud checks
    const fraudWarnings = fraudDetection.performClientChecks(parseFloat(amount));
    
    // Show warnings to user
    if (!fraudDetection.showFraudWarnings(fraudWarnings)) {
        return; // User cancelled
    }
    
    // Continue with normal withdrawal process
    processWithdrawal(amount, accountDetails);
}
```

## Monitoring and Reporting

### Fraud Dashboard (admin/fraud-dashboard.php)
```php
<?php
/**
 * Fraud Dashboard for Admins
 */

require_once __DIR__ . '/../middleware/admin.php';
require_once __DIR__ . '/../db.php';

// Initialize database connection
$database = new Database();
$db = $database->getConnection();

// Get fraud statistics
$statsQuery = "SELECT 
    COUNT(*) as total_checks,
    SUM(CASE WHEN fraud_level = 'high_risk' THEN 1 ELSE 0 END) as high_risk,
    SUM(CASE WHEN fraud_level = 'medium_risk' THEN 1 ELSE 0 END) as medium_risk,
    SUM(CASE WHEN fraud_level = 'low_risk' THEN 1 ELSE 0 END) as low_risk,
    AVG(score) as avg_score
    FROM fraud_detection_logs 
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)";

$statsStmt = $db->prepare($statsQuery);
$statsStmt->execute();
$stats = $statsStmt->fetch(PDO::FETCH_ASSOC);

// Get recent high-risk transactions
$highRiskQuery = "SELECT f.*, u.username, u.email 
                  FROM fraud_detection_logs f
                  JOIN users u ON f.user_id = u.id
                  WHERE f.fraud_level IN ('high_risk', 'medium_risk')
                  ORDER BY f.created_at DESC
                  LIMIT 20";

$highRiskStmt = $db->prepare($highRiskQuery);
$highRiskStmt->execute();
$highRiskTransactions = $highRiskStmt->fetchAll(PDO::FETCH_ASSOC);

// Get blacklisted IPs
$blacklistedIpsQuery = "SELECT * FROM blacklisted_ips 
                        WHERE expires_at IS NULL OR expires_at > NOW()
                        ORDER BY created_at DESC";

$blacklistedIpsStmt = $db->prepare($blacklistedIpsQuery);
$blacklistedIpsStmt->execute();
$blacklistedIps = $blacklistedIpsStmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fraud Dashboard - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container-fluid">
        <h1 class="mt-4">Fraud Detection Dashboard</h1>
        
        <!-- Fraud Statistics -->
        <div class="row">
            <div class="col-md-3">
                <div class="card text-white bg-danger mb-3">
                    <div class="card-header">High Risk</div>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $stats['high_risk'] ?? 0; ?></h5>
                        <p class="card-text">Transactions flagged as high risk</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-white bg-warning mb-3">
                    <div class="card-header">Medium Risk</div>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $stats['medium_risk'] ?? 0; ?></h5>
                        <p class="card-text">Transactions flagged as medium risk</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-white bg-info mb-3">
                    <div class="card-header">Low Risk</div>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $stats['low_risk'] ?? 0; ?></h5>
                        <p class="card-text">Transactions flagged as low risk</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-white bg-primary mb-3">
                    <div class="card-header">Average Score</div>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo number_format($stats['avg_score'] ?? 0, 2); ?></h5>
                        <p class="card-text">Average fraud detection score</p>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Recent High-Risk Transactions -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h5>Recent High-Risk Transactions</h5>
                    </div>
                    <div class="card-body">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>User</th>
                                    <th>Amount</th>
                                    <th>Type</th>
                                    <th>Fraud Level</th>
                                    <th>Score</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($highRiskTransactions as $transaction): ?>
                                <tr>
                                    <td><?php echo $transaction['created_at']; ?></td>
                                    <td><?php echo htmlspecialchars($transaction['username'] . ' (' . $transaction['email'] . ')'); ?></td>
                                    <td><?php echo number_format($transaction['amount'], 2); ?> ETB</td>
                                    <td><?php echo ucfirst($transaction['transaction_type']); ?></td>
                                    <td>
                                        <span class="badge bg-<?php 
                                            echo $transaction['fraud_level'] === 'high_risk' ? 'danger' : 
                                                ($transaction['fraud_level'] === 'medium_risk' ? 'warning' : 'info'); ?>">
                                            <?php echo ucfirst(str_replace('_', ' ', $transaction['fraud_level'])); ?>
                                        </span>
                                    </td>
                                    <td><?php echo $transaction['score']; ?></td>
                                    <td>
                                        <button class="btn btn-sm btn-primary" 
                                                onclick="viewDetails(<?php echo $transaction['id']; ?>)">
                                            View Details
                                        </button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Blacklisted IPs -->
        <div class="row mt-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h5>Blacklisted IPs</h5>
                    </div>
                    <div class="card-body">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>IP Address</th>
                                    <th>Reason</th>
                                    <th>Created</th>
                                    <th>Expires</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($blacklistedIps as $ip): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($ip['ip_address']); ?></td>
                                    <td><?php echo htmlspecialchars($ip['reason']); ?></td>
                                    <td><?php echo $ip['created_at']; ?></td>
                                    <td><?php echo $ip['expires_at'] ? $ip['expires_at'] : 'Never'; ?></td>
                                    <td>
                                        <button class="btn btn-sm btn-success" 
                                                onclick="whitelistIp('<?php echo $ip['ip_address']; ?>')">
                                            Whitelist
                                        </button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        function viewDetails(transactionId) {
            // Implement view details functionality
            alert('View details for transaction ID: ' + transactionId);
        }
        
        function whitelistIp(ipAddress) {
            if (confirm('Are you sure you want to whitelist IP: ' + ipAddress + '?')) {
                // Implement whitelist functionality
                alert('IP ' + ipAddress + ' whitelisted');
            }
        }
    </script>
</body>
</html>
```

## Summary

This enhanced fraud detection system provides:

1. **Comprehensive Fraud Detection**:
   - Amount-based analysis
   - Frequency monitoring
   - IP and device tracking
   - User behavior analysis
   - Time-based pattern detection

2. **Rate Limiting**:
   - Configurable limits per action type
   - Database-based tracking
   - Automatic expiration

3. **Blacklisting System**:
   - IP address blacklisting
   - User account blacklisting
   - Temporary and permanent bans

4. **Monitoring and Reporting**:
   - Admin dashboard
   - Real-time statistics
   - Detailed transaction logs

5. **Integration Points**:
   - Backend API integration
   - Frontend user warnings
   - Session management integration

6. **Security Features**:
   - Multi-layered detection
   - Risk scoring system
   - Automatic blocking of high-risk transactions