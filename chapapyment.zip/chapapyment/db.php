<?php
/**
 * Database Connection Handler
 */

require_once __DIR__ . '/config.php';

// Initialize database connection
function getDBConnection() {
    $database = new Database();
    return $database->getConnection();
}

// Test database connection
function testDBConnection() {
    try {
        $db = getDBConnection();
        if ($db) {
            return ['success' => true, 'message' => 'Database connection successful'];
        } else {
            return ['success' => false, 'message' => 'Failed to connect to database'];
        }
    } catch (Exception $e) {
        return ['success' => false, 'message' => 'Database error: ' . $e->getMessage()];
    }
}
?>
