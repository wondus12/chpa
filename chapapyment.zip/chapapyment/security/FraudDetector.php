<?php
/**
 * Fraud Detection Service
 * Comprehensive fraud detection system for banking transactions
 */

class FraudDetector {
    private $db;
    private $config;
    
    // Fraud detection thresholds
    private const HIGH_AMOUNT_THRESHOLD = 10000;
    private const SUSPICIOUS_AMOUNT_THRESHOLD = 5000;
    private const MAX_DAILY_WITHDRAWALS = 10;
    private const MAX_HOURLY_TRANSACTIONS = 5;
    private const RATE_LIMIT_WINDOW = 3600; // 1 hour
    
    public function __construct($db, $config = []) {
        $this->db = $db;
        $this->config = array_merge([
            'high_amount_threshold' => self::HIGH_AMOUNT_THRESHOLD,
            'suspicious_amount_threshold' => self::SUSPICIOUS_AMOUNT_THRESHOLD,
            'max_daily_withdrawals' => self::MAX_DAILY_WITHDRAWALS,
            'max_hourly_transactions' => self::MAX_HOURLY_TRANSACTIONS
        ], $config);
    }
    
    /**
     * Perform comprehensive fraud check for a transaction
     */
    public function checkTransaction($userId, $amount, $transactionType, $ipAddress = null, $userAgent = null) {
        $fraudScore = 0;
        $warnings = [];
        $details = [];
        
        // 1. Amount-based checks
        $amountCheck = $this->checkAmount($amount);
        if (!$amountCheck['passed']) {
            $fraudScore += $amountCheck['score'];
            $warnings = array_merge($warnings, $amountCheck['warnings']);
            $details['amount_check'] = $amountCheck;
        }
        
        // 2. Frequency-based checks
        $frequencyCheck = $this->checkTransactionFrequency($userId, $transactionType);
        if (!$frequencyCheck['passed']) {
            $fraudScore += $frequencyCheck['score'];
            $warnings = array_merge($warnings, $frequencyCheck['warnings']);
            $details['frequency_check'] = $frequencyCheck;
        }
        
        // 3. IP and device-based checks
        if ($ipAddress) {
            $ipCheck = $this->checkIpAddress($userId, $ipAddress);
            if (!$ipCheck['passed']) {
                $fraudScore += $ipCheck['score'];
                $warnings = array_merge($warnings, $ipCheck['warnings']);
                $details['ip_check'] = $ipCheck;
            }
        }
        
        // 4. User behavior analysis
        $behaviorCheck = $this->checkUserBehavior($userId, $amount);
        if (!$behaviorCheck['passed']) {
            $fraudScore += $behaviorCheck['score'];
            $warnings = array_merge($warnings, $behaviorCheck['warnings']);
            $details['behavior_check'] = $behaviorCheck;
        }
        
        // 5. Time-based checks
        $timeCheck = $this->checkTransactionTiming($userId);
        if (!$timeCheck['passed']) {
            $fraudScore += $timeCheck['score'];
            $warnings = array_merge($warnings, $timeCheck['warnings']);
            $details['time_check'] = $timeCheck;
        }
        
        // Determine fraud level based on score
        $fraudLevel = $this->determineFraudLevel($fraudScore);
        
        return [
            'passed' => $fraudLevel !== 'high_risk',
            'fraud_level' => $fraudLevel,
            'score' => $fraudScore,
            'warnings' => $warnings,
            'details' => $details
        ];
    }
    
    /**
     * Check amount for suspicious patterns
     */
    private function checkAmount($amount) {
        $warnings = [];
        $score = 0;
        
        // Check for high amount
        if ($amount >= $this->config['high_amount_threshold']) {
            $warnings[] = 'High amount transaction detected';
            $score += 50;
        } elseif ($amount >= $this->config['suspicious_amount_threshold']) {
            $warnings[] = 'Moderate amount transaction detected';
            $score += 20;
        }
        
        // Check for round numbers (often indicates automated/bot activity)
        if ($amount % 1000 === 0 && $amount >= 1000) {
            $warnings[] = 'Round number amount detected';
            $score += 15;
        }
        
        // Check for unusual decimal patterns
        $decimalPart = $amount - floor($amount);
        if ($decimalPart == 0.99 || $decimalPart == 0.00) {
            $warnings[] = 'Unusual decimal pattern detected';
            $score += 10;
        }
        
        return [
            'passed' => $score < 30,
            'score' => $score,
            'warnings' => $warnings
        ];
    }
    
    /**
     * Check transaction frequency
     */
    private function checkTransactionFrequency($userId, $transactionType) {
        $warnings = [];
        $score = 0;
        
        // Check hourly transaction count
        $hourlyCount = $this->getTransactionCount($userId, 'hour');
        if ($hourlyCount > $this->config['max_hourly_transactions']) {
            $warnings[] = "High transaction frequency: {$hourlyCount} transactions this hour";
            $score += 30;
        }
        
        // Check daily withdrawal count for withdrawals
        if ($transactionType === 'withdrawal') {
            $dailyWithdrawals = $this->getWithdrawalCount($userId, 'day');
            if ($dailyWithdrawals > $this->config['max_daily_withdrawals']) {
                $warnings[] = "Excessive withdrawals: {$dailyWithdrawals} today";
                $score += 40;
            }
        }
        
        return [
            'passed' => $score < 25,
            'score' => $score,
            'warnings' => $warnings
        ];
    }
    
    /**
     * Check IP address for suspicious activity
     */
    private function checkIpAddress($userId, $ipAddress) {
        $warnings = [];
        $score = 0;
        
        // Check if this is a new IP for the user
        if (!$this->isKnownIpAddress($userId, $ipAddress)) {
            $warnings[] = 'New IP address detected for user';
            $score += 20;
        }
        
        // Check if IP has been associated with failed transactions
        $failedFromIp = $this->getFailedTransactionsFromIp($ipAddress);
        if ($failedFromIp > 3) {
            $warnings[] = "IP address has {$failedFromIp} failed transactions";
            $score += 25;
        }
        
        // Check IP reputation (simplified - in production, use external service)
        if ($this->isBlacklistedIp($ipAddress)) {
            $warnings[] = 'IP address is blacklisted';
            $score += 50;
        }
        
        return [
            'passed' => $score < 30,
            'score' => $score,
            'warnings' => $warnings
        ];
    }
    
    /**
     * Check user behavior patterns
     */
    private function checkUserBehavior($userId, $amount) {
        $warnings = [];
        $score = 0;
        
        // Check if amount is significantly different from user's typical transactions
        $avgAmount = $this->getUserAverageTransactionAmount($userId);
        if ($avgAmount > 0) {
            $deviation = abs($amount - $avgAmount) / $avgAmount;
            if ($deviation > 2) { // More than 200% deviation
                $warnings[] = 'Amount significantly different from user average';
                $score += 25;
            }
        }
        
        // Check time since last transaction
        $timeSinceLast = $this->getTimeSinceLastTransaction($userId);
        if ($timeSinceLast !== null && $timeSinceLast < 30) { // Less than 30 seconds
            $warnings[] = 'Rapid successive transactions detected';
            $score += 20;
        }
        
        return [
            'passed' => $score < 30,
            'score' => $score,
            'warnings' => $warnings
        ];
    }
    
    /**
     * Check transaction timing patterns
     */
    private function checkTransactionTiming($userId) {
        $warnings = [];
        $score = 0;
        
        // Check if transaction is happening at unusual hours
        $hour = date('H');
        if (($hour >= 0 && $hour <= 5) || ($hour >= 23 && $hour <= 24)) {
            $warnings[] = 'Transaction at unusual hours detected';
            $score += 15;
        }
        
        return [
            'passed' => $score < 20,
            'score' => $score,
            'warnings' => $warnings
        ];
    }
    
    /**
     * Determine fraud level based on score
     */
    private function determineFraudLevel($score) {
        if ($score >= 70) {
            return 'high_risk';
        } elseif ($score >= 40) {
            return 'medium_risk';
        } elseif ($score >= 20) {
            return 'low_risk';
        } else {
            return 'no_risk';
        }
    }
    
    /**
     * Database helper methods
     */
    private function getTransactionCount($userId, $period = 'hour') {
        $timeClause = '';
        switch ($period) {
            case 'hour':
                $timeClause = "AND created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)";
                break;
            case 'day':
                $timeClause = "AND created_at >= DATE_SUB(NOW(), INTERVAL 1 DAY)";
                break;
            case 'week':
                $timeClause = "AND created_at >= DATE_SUB(NOW(), INTERVAL 1 WEEK)";
                break;
        }
        
        $query = "SELECT COUNT(*) as count FROM transactions 
                  WHERE user_id = :user_id 
                  AND status = 'completed' 
                  {$timeClause}";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':user_id', $userId);
        $stmt->execute();
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['count'] ?? 0;
    }
    
    private function getWithdrawalCount($userId, $period = 'day') {
        $timeClause = '';
        switch ($period) {
            case 'hour':
                $timeClause = "AND created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)";
                break;
            case 'day':
                $timeClause = "AND created_at >= DATE_SUB(NOW(), INTERVAL 1 DAY)";
                break;
            case 'week':
                $timeClause = "AND created_at >= DATE_SUB(NOW(), INTERVAL 1 WEEK)";
                break;
        }
        
        $query = "SELECT COUNT(*) as count FROM transactions 
                  WHERE user_id = :user_id 
                  AND transaction_type = 'withdrawal' 
                  AND status IN ('completed', 'pending') 
                  {$timeClause}";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':user_id', $userId);
        $stmt->execute();
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['count'] ?? 0;
    }
    
    private function isKnownIpAddress($userId, $ipAddress) {
        $query = "SELECT COUNT(*) as count FROM user_ips 
                  WHERE user_id = :user_id 
                  AND ip_address = :ip_address";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':user_id', $userId);
        $stmt->bindParam(':ip_address', $ipAddress);
        $stmt->execute();
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return ($result['count'] ?? 0) > 0;
    }
    
    private function getFailedTransactionsFromIp($ipAddress) {
        $query = "SELECT COUNT(*) as count FROM transactions 
                  WHERE ip_address = :ip_address 
                  AND status = 'failed' 
                  AND created_at >= DATE_SUB(NOW(), INTERVAL 1 DAY)";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':ip_address', $ipAddress);
        $stmt->execute();
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['count'] ?? 0;
    }
    
    private function isBlacklistedIp($ipAddress) {
        $query = "SELECT COUNT(*) as count FROM blacklisted_ips 
                  WHERE ip_address = :ip_address 
                  AND (expires_at IS NULL OR expires_at > NOW())";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':ip_address', $ipAddress);
        $stmt->execute();
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return ($result['count'] ?? 0) > 0;
    }
    
    private function getUserAverageTransactionAmount($userId) {
        $query = "SELECT AVG(amount) as avg_amount FROM transactions 
                  WHERE user_id = :user_id 
                  AND status = 'completed' 
                  AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':user_id', $userId);
        $stmt->execute();
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['avg_amount'] ?? 0;
    }
    
    private function getTimeSinceLastTransaction($userId) {
        $query = "SELECT created_at FROM transactions 
                  WHERE user_id = :user_id 
                  AND status = 'completed' 
                  ORDER BY created_at DESC 
                  LIMIT 1";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':user_id', $userId);
        $stmt->execute();
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($result) {
            $lastTransactionTime = strtotime($result['created_at']);
            return time() - $lastTransactionTime;
        }
        
        return null;
    }
    
    /**
     * Log fraud detection results
     */
    public function logFraudCheck($userId, $amount, $transactionType, $result) {
        $query = "INSERT INTO fraud_detection_logs 
                  (user_id, amount, transaction_type, fraud_level, score, details, created_at) 
                  VALUES (:user_id, :amount, :transaction_type, :fraud_level, :score, :details, NOW())";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':user_id', $userId);
        $stmt->bindParam(':amount', $amount);
        $stmt->bindParam(':transaction_type', $transactionType);
        $stmt->bindParam(':fraud_level', $result['fraud_level']);
        $stmt->bindParam(':score', $result['score']);
        $stmt->bindParam(':details', json_encode($result));
        $stmt->execute();
    }
}
?>
