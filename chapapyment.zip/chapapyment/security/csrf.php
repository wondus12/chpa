<?php
/**
 * CSRF Protection Implementation
 * Provides functions for generating and validating CSRF tokens
 */

require_once __DIR__ . '/../session_config.php';

/**
 * Generate a CSRF token
 */
function generateCSRFToken() {
    // Start session if not already started
    startSecureSession();
    
    // Generate token if it doesn't exist or if forced regeneration is requested
    if (!isset($_SESSION['csrf_token']) || isset($_GET['regenerate_csrf'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    
    return $_SESSION['csrf_token'];
}

/**
 * Validate a CSRF token
 */
function validateCSRFToken($token) {
    // Start session if not already started
    startSecureSession();
    
    // Check if token exists in session
    if (!isset($_SESSION['csrf_token'])) {
        return false;
    }
    
    // Validate token using hash_equals for timing attack protection
    return hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Generate hidden input field with CSRF token for forms
 */
function csrfField() {
    $token = generateCSRFToken();
    return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars($token) . '">';
}

/**
 * Middleware function to validate CSRF token for POST requests
 */
function validateCSRFMiddleware() {
    // Only validate POST requests
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        return true;
    }
    
    // Get token from request
    $token = $_POST['csrf_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    
    // Validate token
    if (!validateCSRFToken($token)) {
        // Log CSRF attempt
        Logger::security('CSRF token validation failed', [
            'ip' => $_SERVER['REMOTE_ADDR'],
            'user_agent' => $_SERVER['HTTP_USER_AGENT'],
            'request_uri' => $_SERVER['REQUEST_URI']
        ]);
        
        return false;
    }
    
    return true;
}

/**
 * Generate CSRF token for AJAX requests
 */
function getCSRFTokenForAjax() {
    return generateCSRFToken();
}
?>
