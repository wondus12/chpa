<?php
/**
 * Input Validation and Sanitization Library
 * Provides comprehensive input validation and sanitization functions
 */

class InputValidator {
    /**
     * Validate and sanitize email address
     */
    public static function validateEmail($email) {
        $email = filter_var(trim($email), FILTER_SANITIZE_EMAIL);
        if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return $email;
        }
        return false;
    }
    
    /**
     * Validate and sanitize numeric amount
     */
    public static function validateAmount($amount) {
        // Remove any non-numeric characters except decimal point
        $amount = preg_replace('/[^0-9.]/', '', $amount);
        
        // Validate as float
        if (filter_var($amount, FILTER_VALIDATE_FLOAT) !== false) {
            $floatAmount = floatval($amount);
            // Ensure positive amount
            if ($floatAmount > 0) {
                return $floatAmount;
            }
        }
        return false;
    }
    
    /**
     * Validate and sanitize transaction reference
     */
    public static function validateTxRef($txRef) {
        // Remove any potentially dangerous characters
        $txRef = preg_replace('/[^a-zA-Z0-9-_]/', '', $txRef);
        
        // Ensure it's not empty and within reasonable length
        if (!empty($txRef) && strlen($txRef) <= 100) {
            return $txRef;
        }
        return false;
    }
    
    /**
     * Validate and sanitize account details
     */
    public static function validateAccountDetails($accountDetails) {
        // Trim and remove extra whitespace
        $accountDetails = trim(preg_replace('/\s+/', ' ', $accountDetails));
        
        // Ensure it's not empty and within reasonable length
        if (!empty($accountDetails) && strlen($accountDetails) <= 255) {
            return $accountDetails;
        }
        return false;
    }
    
    /**
     * Validate and sanitize username
     */
    public static function validateUsername($username) {
        // Remove any non-alphanumeric characters except underscore and hyphen
        $username = preg_replace('/[^a-zA-Z0-9_-]/', '', $username);
        
        // Ensure it's between 3-30 characters
        if (strlen($username) >= 3 && strlen($username) <= 30) {
            return $username;
        }
        return false;
    }
    
    /**
     * Validate and sanitize phone number
     */
    public static function validatePhoneNumber($phone) {
        // Remove any non-digit characters except + for international format
        $phone = preg_replace('/[^0-9+]/', '', $phone);
        
        // Validate E.164 format (starts with +, 7-15 digits)
        if (preg_match('/^\+[1-9]\d{6,14}$/', $phone)) {
            return $phone;
        }
        
        // Validate Ethiopian phone format (10 digits starting with 09)
        if (preg_match('/^09\d{8}$/', $phone)) {
            return $phone;
        }
        
        return false;
    }
    
    /**
     * Validate and sanitize payment method
     */
    public static function validatePaymentMethod($method) {
        $allowedMethods = ['bank_transfer', 'mobile_money', 'chapa', 'telebirr'];
        if (in_array($method, $allowedMethods)) {
            return $method;
        }
        return false;
    }
    
    /**
     * Validate and sanitize date
     */
    public static function validateDate($date) {
        // Remove any non-date characters
        $date = preg_replace('/[^0-9\-\/: ]/', '', $date);
        
        // Try to parse the date
        $timestamp = strtotime($date);
        if ($timestamp !== false) {
            return date('Y-m-d H:i:s', $timestamp);
        }
        return false;
    }
    
    /**
     * Validate and sanitize string input
     */
    public static function validateString($string, $maxLength = 255) {
        // Trim and sanitize string
        $string = trim(filter_var($string, FILTER_SANITIZE_STRING, FILTER_FLAG_NO_ENCODE_QUOTES));
        
        // Ensure it's not empty and within length limit
        if (!empty($string) && strlen($string) <= $maxLength) {
            return $string;
        }
        return false;
    }
    
    /**
     * Validate and sanitize integer input
     */
    public static function validateInteger($integer) {
        // Remove any non-numeric characters
        $integer = preg_replace('/[^0-9]/', '', $integer);
        
        // Validate as integer
        if (filter_var($integer, FILTER_VALIDATE_INT) !== false) {
            return intval($integer);
        }
        return false;
    }
    
    /**
     * Validate and sanitize URL
     */
    public static function validateUrl($url) {
        $url = filter_var(trim($url), FILTER_SANITIZE_URL);
        if (filter_var($url, FILTER_VALIDATE_URL)) {
            return $url;
        }
        return false;
    }
    
    /**
     * Validate and sanitize JSON input
     */
    public static function validateJson($json) {
        $data = json_decode($json, true);
        if (json_last_error() === JSON_ERROR_NONE) {
            return $data;
        }
        return false;
    }
}
?>
