<?php
/**
 * Chapa Banking App Configuration - Local Development
 */

// Database Configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'chapa_banking');
define('DB_USER', 'root');
define('DB_PASS', '');

// Chapa Configuration (Test Keys)
define('CHAPA_SECRET_KEY', 'CHASECRETKEY-TEST-xxxxxxxxxxxxxxxxxxxx');
define('CHAPA_PUBLIC_KEY', 'CHAPUBK_TEST-xxxxxxxxxxxxxxxxxxxx');

// Domain Configuration
define('DOMAIN_URL', 'http://localhost:8000');

// Security Configuration
define('IS_PRODUCTION', false); // Development mode
define('MIN_DEPOSIT_AMOUNT', 1);
define('MAX_DEPOSIT_AMOUNT', 100000);
define('MIN_WITHDRAWAL_AMOUNT', 50);
define('MAX_WITHDRAWAL_AMOUNT', 50000);

// Session Configuration
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_secure', 0); // Set to 0 for HTTP in development
ini_set('session.cookie_samesite', 'Lax'); // Lax for development

// Error Reporting (Development)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Logging Configuration
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/logs/errors.log');

// Chapa Configuration Function
function getChapaConfig() {
    return [
        'public_key' => CHAPA_PUBLIC_KEY,
        'secret_key' => CHAPA_SECRET_KEY,
        'base_url' => 'https://api.chapa.co/v1/',
        'callback_url' => DOMAIN_URL . '/api/webhook.php',
        'return_url' => DOMAIN_URL . '/chapapymentformfile.html'
    ];
}

// Database Connection Class
class Database {
    private $host = DB_HOST;
    private $db_name = DB_NAME;
    private $username = DB_USER;
    private $password = DB_PASS;
    private $conn;

    public function getConnection() {
        $this->conn = null;
        
        try {
            $this->conn = new PDO(
                "mysql:host=" . $this->host . ";dbname=" . $this->db_name,
                $this->username,
                $this->password
            );
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch(PDOException $exception) {
            echo "Connection error: " . $exception->getMessage();
        }
        
        return $this->conn;
    }
}

// Logger Class
class Logger {
    public static function info($message, $context = []) {
        self::log('INFO', $message, $context);
    }
    
    public static function warning($message, $context = []) {
        self::log('WARNING', $message, $context);
    }
    
    public static function error($message, $context = []) {
        self::log('ERROR', $message, $context);
    }
    
    public static function security($message, $context = []) {
        self::log('SECURITY', $message, $context);
    }
    
    private static function log($level, $message, $context = []) {
        $timestamp = date('Y-m-d H:i:s');
        $logEntry = "[$timestamp] [$level] $message";
        
        if (!empty($context)) {
            $logEntry .= ' Context: ' . json_encode($context);
        }
        
        $logEntry .= PHP_EOL;
        
        // Ensure logs directory exists
        $logDir = __DIR__ . '/logs';
        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }
        
        file_put_contents($logDir . '/application.log', $logEntry, FILE_APPEND | LOCK_EX);
    }
}
?>