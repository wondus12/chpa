# Real-Time Balance Updates Implementation

## Backend Implementation

### Balance API Endpoint (api/balance.php)
```php
<?php
/**
 * Real-time Balance API
 * Retrieve current user balance
 */

require_once __DIR__ . '/../session_config.php';
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../models/User.php';

// Start session
startSecureSession();

header('Content-Type: application/json');

// Validate user authentication
$user_id = $_SESSION['user_id'] ?? null;
if (!$user_id) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'error' => 'User not authenticated'
    ]);
    exit;
}

// Initialize database connection
$database = new Database();
$db = $database->getConnection();

// Get user balance
$user = new User($db);
$userData = $user->getUserById($user_id);

if (!$userData) {
    http_response_code(404);
    echo json_encode([
        'success' => false,
        'error' => 'User not found'
    ]);
    exit;
}

echo json_encode([
    'success' => true,
    'data' => [
        'balance' => floatval($userData['balance']),
        'currency' => 'ETB',
        'last_updated' => $userData['updated_at']
    ]
]);
?>
```

### WebSocket Server for Real-time Updates (websocket/server.php)
```php
<?php
/**
 * WebSocket Server for Real-time Balance Updates
 * Note: This requires the Ratchet library (composer require cboden/ratchet)
 */

require_once __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../config.php';

use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;
use Ratchet\WebSocket\WsServer;
use Ratchet\Http\HttpServer;
use Ratchet\Server\IoServer;

class BalanceUpdateServer implements MessageComponentInterface {
    protected $clients;
    protected $db;
    
    public function __construct() {
        $this->clients = new \SplObjectStorage;
        
        // Initialize database connection
        $database = new Database();
        $this->db = $database->getConnection();
    }
    
    public function onOpen(ConnectionInterface $conn) {
        // Store the new connection
        $this->clients->attach($conn);
        echo "New connection! ({$conn->resourceId})\n";
    }
    
    public function onMessage(ConnectionInterface $from, $msg) {
        $data = json_decode($msg, true);
        
        if ($data && isset($data['action'])) {
            switch ($data['action']) {
                case 'subscribe':
                    // Subscribe to balance updates for a user
                    if (isset($data['user_id'])) {
                        $from->user_id = $data['user_id'];
                        $from->send(json_encode([
                            'type' => 'subscribed',
                            'message' => 'Subscribed to balance updates'
                        ]));
                    }
                    break;
                    
                case 'get_balance':
                    // Get current balance
                    if (isset($data['user_id'])) {
                        $balance = $this->getUserBalance($data['user_id']);
                        $from->send(json_encode([
                            'type' => 'balance_update',
                            'balance' => $balance
                        ]));
                    }
                    break;
            }
        }
    }
    
    public function onClose(ConnectionInterface $conn) {
        // The connection is closed, remove it
        $this->clients->detach($conn);
        echo "Connection {$conn->resourceId} has disconnected\n";
    }
    
    public function onError(ConnectionInterface $conn, \Exception $e) {
        echo "An error has occurred: {$e->getMessage()}\n";
        $conn->close();
    }
    
    // Send balance update to all subscribed clients
    public function sendBalanceUpdate($userId, $newBalance) {
        foreach ($this->clients as $client) {
            if (isset($client->user_id) && $client->user_id == $userId) {
                $client->send(json_encode([
                    'type' => 'balance_update',
                    'balance' => $newBalance,
                    'timestamp' => time()
                ]));
            }
        }
    }
    
    // Get user balance from database
    private function getUserBalance($userId) {
        $query = "SELECT balance FROM users WHERE id = :user_id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':user_id', $userId);
        $stmt->execute();
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result ? floatval($result['balance']) : 0.0;
    }
    
    // Broadcast balance update (to be called after transactions)
    public function broadcastBalanceUpdate($userId, $newBalance) {
        $this->sendBalanceUpdate($userId, $newBalance);
    }
}

// Start the WebSocket server
$server = IoServer::factory(
    new HttpServer(
        new WsServer(
            new BalanceUpdateServer()
        )
    ),
    8080
);

$server->run();
?>
```

### Transaction Processing with Balance Update Notification
```php
<?php
/**
 * Updated transaction processing with real-time balance updates
 */

// In your transaction processing code (e.g., in withdraw.php or verify-payment.php)

// After successfully processing a transaction and updating the user's balance:
function notifyBalanceUpdate($userId, $db) {
    // Get the new balance
    $user = new User($db);
    $userData = $user->getUserById($userId);
    $newBalance = $userData['balance'] ?? 0.0;
    
    // If WebSocket server is available, send update
    // This is a simplified example - in production, you might use a message queue
    try {
        $socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
        if ($socket !== false) {
            $result = socket_connect($socket, '127.0.0.1', 8080);
            if ($result !== false) {
                $message = json_encode([
                    'action' => 'balance_update',
                    'user_id' => $userId,
                    'balance' => $newBalance
                ]);
                socket_write($socket, $message, strlen($message));
                socket_close($socket);
            }
        }
    } catch (Exception $e) {
        // Log error but don't fail the transaction
        error_log("Failed to notify balance update: " . $e->getMessage());
    }
}

// Example usage in withdrawal processing:
// After successfully creating withdrawal request and updating balance:
// notifyBalanceUpdate($user_id, $db);
?>
```

## Frontend Implementation

### WebSocket Client for Real-time Updates
```javascript
// Real-time Balance Updates
class BalanceUpdater {
    constructor() {
        this.ws = null;
        this.isConnected = false;
        this.reconnectAttempts = 0;
        this.maxReconnectAttempts = 5;
        this.balanceElement = document.getElementById('current-balance');
        this.userId = null;
    }
    
    // Initialize WebSocket connection
    init(userId) {
        this.userId = userId;
        
        // Check if WebSocket is supported
        if (!('WebSocket' in window)) {
            console.warn('WebSocket not supported, falling back to polling');
            this.startPolling();
            return;
        }
        
        this.connect();
    }
    
    // Connect to WebSocket server
    connect() {
        try {
            // Use wss:// for production with SSL
            const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
            const wsUrl = `${protocol}//${window.location.host}:8080`;
            
            this.ws = new WebSocket(wsUrl);
            
            this.ws.onopen = () => {
                console.log('Connected to balance update server');
                this.isConnected = true;
                this.reconnectAttempts = 0;
                
                // Subscribe to balance updates
                this.subscribe();
            };
            
            this.ws.onmessage = (event) => {
                const data = JSON.parse(event.data);
                this.handleMessage(data);
            };
            
            this.ws.onclose = () => {
                console.log('WebSocket connection closed');
                this.isConnected = false;
                this.handleDisconnect();
            };
            
            this.ws.onerror = (error) => {
                console.error('WebSocket error:', error);
                this.handleDisconnect();
            };
        } catch (error) {
            console.error('Failed to connect to WebSocket:', error);
            this.handleDisconnect();
        }
    }
    
    // Subscribe to balance updates
    subscribe() {
        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
            this.ws.send(JSON.stringify({
                action: 'subscribe',
                user_id: this.userId
            }));
        }
    }
    
    // Handle incoming messages
    handleMessage(data) {
        switch (data.type) {
            case 'balance_update':
                this.updateBalanceDisplay(data.balance);
                this.showBalanceNotification(data.balance);
                break;
                
            case 'subscribed':
                console.log('Subscribed to balance updates');
                break;
                
            default:
                console.log('Unknown message type:', data.type);
        }
    }
    
    // Update balance display
    updateBalanceDisplay(balance) {
        if (this.balanceElement) {
            // Format balance as currency
            const formattedBalance = parseFloat(balance).toLocaleString('en-ET', {
                style: 'currency',
                currency: 'ETB'
            });
            this.balanceElement.textContent = formattedBalance;
        }
    }
    
    // Show balance update notification
    showBalanceNotification(balance) {
        // Only show notification if there's a significant change
        const currentBalance = parseFloat(this.balanceElement?.textContent?.replace(/[^0-9.-]+/g, '') || 0);
        const difference = Math.abs(balance - currentBalance);
        
        if (difference > 0.01) { // More than 1 cent difference
            const changeType = balance > currentBalance ? 'increased' : 'decreased';
            showToast(`Your balance has ${changeType}. New balance: ${parseFloat(balance).toLocaleString('en-ET', {
                style: 'currency',
                currency: 'ETB'
            })}`, 'info');
        }
    }
    
    // Handle disconnection
    handleDisconnect() {
        if (this.reconnectAttempts < this.maxReconnectAttempts) {
            this.reconnectAttempts++;
            console.log(`Attempting to reconnect... (${this.reconnectAttempts}/${this.maxReconnectAttempts})`);
            
            // Exponential backoff
            const delay = Math.min(1000 * Math.pow(2, this.reconnectAttempts), 30000);
            setTimeout(() => {
                this.connect();
            }, delay);
        } else {
            console.log('Max reconnect attempts reached, falling back to polling');
            this.startPolling();
        }
    }
    
    // Fallback polling mechanism
    startPolling() {
        // Poll every 30 seconds
        this.pollingInterval = setInterval(() => {
            this.fetchBalance();
        }, 30000);
        
        // Fetch balance immediately
        this.fetchBalance();
    }
    
    // Fetch balance via HTTP request
    async fetchBalance() {
        try {
            const response = await fetch('/api/balance.php', {
                method: 'GET',
                credentials: 'same-origin'
            });
            
            if (response.ok) {
                const result = await response.json();
                if (result.success && result.data) {
                    this.updateBalanceDisplay(result.data.balance);
                }
            }
        } catch (error) {
            console.error('Failed to fetch balance:', error);
        }
    }
    
    // Stop balance updates
    stop() {
        if (this.ws) {
            this.ws.close();
        }
        
        if (this.pollingInterval) {
            clearInterval(this.pollingInterval);
        }
    }
}

// Initialize balance updater
const balanceUpdater = new BalanceUpdater();

// Start balance updates when user is authenticated
function startBalanceUpdates(userId) {
    balanceUpdater.init(userId);
}

// Stop balance updates when user logs out
function stopBalanceUpdates() {
    balanceUpdater.stop();
}
```

### Updated HTML for Balance Display
```html
<!-- Add to the top of your banking app for balance display -->
<div class="balance-display card mb-4">
    <div class="card-body">
        <h5 class="card-title">Current Balance</h5>
        <h2 id="current-balance" class="text-primary">
            <!-- Balance will be updated here -->
            ₦0.00
        </h2>
        <small class="text-muted" id="balance-last-updated">
            Last updated: Just now
        </small>
    </div>
</div>

<!-- Add to your existing HTML where needed -->
<script>
// Update the balance display with initial value
document.addEventListener('DOMContentLoaded', function() {
    // Get initial balance from server
    fetch('/api/balance.php')
        .then(response => response.json())
        .then(data => {
            if (data.success && data.data) {
                const balanceElement = document.getElementById('current-balance');
                const formattedBalance = parseFloat(data.data.balance).toLocaleString('en-ET', {
                    style: 'currency',
                    currency: 'ETB'
                });
                balanceElement.textContent = formattedBalance;
                
                // Start real-time updates
                // You would get the user ID from your session management
                const userId = /* get user ID from session */;
                if (userId) {
                    startBalanceUpdates(userId);
                }
            }
        })
        .catch(error => {
            console.error('Failed to load initial balance:', error);
        });
});
</script>
```

### Integration with Transaction Processing
```javascript
// Updated transaction processing with real-time balance updates

// In your deposit processing function
async function initiateDeposit() {
    // ... existing deposit code ...
    
    try {
        // Process the deposit
        const response = await fetch(CHAPA_CONFIG.baseUrl + 'verify-payment.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                tx_ref: txRef,
                payment_type: 'deposit'
            })
        });
        
        const result = await response.json();
        
        if (result.status === 'success') {
            // Show success message
            showPaymentMessage('deposit-success-message', 'Deposit successful!', 'success');
            
            // The backend should have already updated the balance
            // The WebSocket will notify us of the change
            console.log('Deposit processed, waiting for balance update');
        } else {
            showPaymentMessage('deposit-error-message', 'Deposit failed. Please try again.', 'error');
        }
    } catch (error) {
        console.error('Error processing deposit:', error);
        showPaymentMessage('deposit-error-message', 'Unable to process deposit. Please try again.', 'error');
    }
}

// In your withdrawal processing function
async function processWithdrawal(amount, accountDetails) {
    // ... existing withdrawal code ...
    
    try {
        const response = await fetch(CHAPA_CONFIG.baseUrl + 'withdraw.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                amount: amount,
                account_details: accountDetails,
                payment_method: 'bank_transfer'
            })
        });
        
        const result = await response.json();
        
        if (response.ok && result.success) {
            showPaymentMessage('withdraw-success-message', result.message, 'success');
            
            // The backend should have already updated the balance
            // The WebSocket will notify us of the change
            console.log('Withdrawal processed, waiting for balance update');
        } else {
            showPaymentMessage('withdraw-error-message', result.error || 'Withdrawal failed', 'error');
        }
    } catch (error) {
        console.error('Error processing withdrawal:', error);
        showPaymentMessage('withdraw-error-message', 'Unable to process withdrawal. Please try again.', 'error');
    }
}
```

## Server-Side Integration

### Updated User Model with Balance Update Notification
```php
<?php
// models/User.php - Updated with balance update notification

class User {
    private $conn;
    private $table_name = "users";
    
    // ... existing code ...
    
    // Update user balance with notification
    public function updateBalance($user_id, $amount, $operation = 'add') {
        try {
            // Start transaction
            $this->conn->beginTransaction();
            
            if ($operation === 'add') {
                $query = "UPDATE " . $this->table_name . " SET balance = balance + :amount, updated_at = CURRENT_TIMESTAMP WHERE id = :user_id";
            } else {
                $query = "UPDATE " . $this->table_name . " SET balance = balance - :amount, updated_at = CURRENT_TIMESTAMP WHERE id = :user_id";
            }
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':amount', $amount);
            $stmt->bindParam(':user_id', $user_id);
            
            $result = $stmt->execute();
            
            if ($result) {
                // Get the new balance
                $userData = $this->getUserById($user_id);
                $newBalance = $userData['balance'] ?? 0.0;
                
                // Commit transaction
                $this->conn->commit();
                
                // Notify balance update (if WebSocket server is available)
                $this->notifyBalanceUpdate($user_id, $newBalance);
                
                return true;
            } else {
                $this->conn->rollBack();
                return false;
            }
        } catch (Exception $e) {
            $this->conn->rollBack();
            error_log("Balance update failed: " . $e->getMessage());
            return false;
        }
    }
    
    // Notify balance update via WebSocket
    private function notifyBalanceUpdate($userId, $newBalance) {
        // This is a simplified example - in production, you might use a message queue
        try {
            $socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
            if ($socket !== false) {
                $result = socket_connect($socket, '127.0.0.1', 8080);
                if ($result !== false) {
                    $message = json_encode([
                        'action' => 'balance_update',
                        'user_id' => $userId,
                        'balance' => $newBalance
                    ]);
                    socket_write($socket, $message, strlen($message));
                    socket_close($socket);
                }
            }
        } catch (Exception $e) {
            // Log error but don't fail the transaction
            error_log("Failed to notify balance update: " . $e->getMessage());
        }
    }
    
    // ... rest of existing code ...
}
?>
```

## Fallback Mechanisms

### Polling Fallback System
```javascript
// Enhanced polling fallback with smart polling intervals
class SmartPolling {
    constructor() {
        this.pollingInterval = null;
        this.baseInterval = 30000; // 30 seconds
        this.maxInterval = 300000; // 5 minutes
        this.currentInterval = this.baseInterval;
        this.activityTimeout = null;
        this.isActive = false;
    }
    
    // Start smart polling
    start() {
        this.isActive = true;
        this.scheduleNextPoll();
        
        // Reset interval on user activity
        this.bindActivityEvents();
    }
    
    // Schedule next poll
    scheduleNextPoll() {
        if (this.isActive) {
            this.pollingInterval = setTimeout(() => {
                this.poll();
            }, this.currentInterval);
        }
    }
    
    // Poll for updates
    async poll() {
        try {
            const response = await fetch('/api/balance.php', {
                method: 'GET',
                credentials: 'same-origin'
            });
            
            if (response.ok) {
                const result = await response.json();
                if (result.success && result.data) {
                    // Update balance display
                    const balanceElement = document.getElementById('current-balance');
                    if (balanceElement) {
                        const formattedBalance = parseFloat(result.data.balance).toLocaleString('en-ET', {
                            style: 'currency',
                            currency: 'ETB'
                        });
                        balanceElement.textContent = formattedBalance;
                    }
                    
                    // Reset polling interval to base if successful
                    this.currentInterval = this.baseInterval;
                }
            }
        } catch (error) {
            console.error('Polling failed:', error);
            // Increase interval on failure (exponential backoff)
            this.currentInterval = Math.min(this.currentInterval * 1.5, this.maxInterval);
        } finally {
            // Schedule next poll
            this.scheduleNextPoll();
        }
    }
    
    // Bind user activity events to reset polling interval
    bindActivityEvents() {
        const events = ['click', 'keypress', 'scroll', 'mousemove'];
        events.forEach(event => {
            document.addEventListener(event, () => {
                this.resetPollingInterval();
            });
        });
    }
    
    // Reset polling interval to base
    resetPollingInterval() {
        clearTimeout(this.activityTimeout);
        this.currentInterval = this.baseInterval;
        
        // Reset to base interval after 5 minutes of inactivity
        this.activityTimeout = setTimeout(() => {
            this.currentInterval = this.baseInterval;
        }, 300000); // 5 minutes
    }
    
    // Stop polling
    stop() {
        this.isActive = false;
        if (this.pollingInterval) {
            clearTimeout(this.pollingInterval);
        }
        if (this.activityTimeout) {
            clearTimeout(this.activityTimeout);
        }
    }
}

// Use smart polling as fallback
const smartPolling = new SmartPolling();

// Start smart polling when WebSocket is not available
function startSmartPolling() {
    smartPolling.start();
}

// Stop smart polling
function stopSmartPolling() {
    smartPolling.stop();
}
```

## Summary

This real-time balance update system provides:

1. **WebSocket-based Real-time Updates**:
   - Instant balance updates when transactions occur
   - Persistent connections with automatic reconnection
   - Fallback to polling when WebSocket is unavailable

2. **Server-side Integration**:
   - Database transaction safety
   - WebSocket notification system
   - Fallback mechanisms for reliability

3. **Frontend Implementation**:
   - WebSocket client with reconnection logic
   - Smart polling fallback system
   - User activity detection for optimized polling
   - Visual feedback for balance changes

4. **Error Handling and Reliability**:
   - Exponential backoff for failed connections
   - Graceful degradation to polling
   - Transaction safety with database rollbacks
   - Comprehensive error logging

5. **Performance Optimizations**:
   - Efficient WebSocket message handling
   - Smart polling intervals based on user activity
   - Minimal DOM updates
   - Connection reuse where possible

The system ensures users always see their current balance with minimal delay, providing a seamless banking experience.