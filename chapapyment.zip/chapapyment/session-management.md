# Session Management Implementation

## Session Configuration

### Session Security Configuration
Create a session configuration file:

```php
<?php
// session_config.php - Session security configuration

// Session security settings
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_secure', 1); // Only in production with HTTPS
ini_set('session.cookie_samesite', 'Strict');
ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_lifetime', 0);
ini_set('session.use_only_cookies', 1);

// Session name
session_name('chapa_banking_session');

// Session start with security options
function startSecureSession() {
    // Get current session status
    $sessionStatus = session_status();
    
    // Start session if not already started
    if ($sessionStatus === PHP_SESSION_NONE) {
        session_start();
    }
    
    // Regenerate session ID to prevent fixation attacks
    if (!isset($_SESSION['created'])) {
        $_SESSION['created'] = time();
    } else if (time() - $_SESSION['created'] > 1800) {
        // Session started more than 30 minutes ago
        session_regenerate_id(true);
        $_SESSION['created'] = time();
    }
}

// Destroy session securely
function destroySession() {
    // Unset all session variables
    $_SESSION = array();
    
    // Delete session cookie
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    
    // Destroy session
    session_destroy();
}

// Check if user is logged in
function isLoggedIn() {
    return isset($_SESSION['user_id']) && isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true;
}

// Get current user ID
function getCurrentUserId() {
    return $_SESSION['user_id'] ?? null;
}

// Get current user role
function getCurrentUserRole() {
    return $_SESSION['user_role'] ?? 'user';
}

// Require authentication for protected pages
function requireAuth() {
    if (!isLoggedIn()) {
        // Redirect to login page
        header('Location: /login.php');
        exit;
    }
    
    // Check for session timeout
    if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > 1800)) {
        // Last activity was more than 30 minutes ago
        destroySession();
        header('Location: /login.php?timeout=1');
        exit;
    }
    
    // Update last activity timestamp
    $_SESSION['last_activity'] = time();
}

// Require admin authentication
function requireAdmin() {
    requireAuth();
    
    if (getCurrentUserRole() !== 'admin') {
        // Redirect to unauthorized page
        header('Location: /unauthorized.php');
        exit;
    }
}
?>
```

## User Authentication System

### Login System (login.php)
```php
<?php
/**
 * User Login System
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/models/User.php';
require_once __DIR__ . '/session_config.php';
require_once __DIR__ . '/security/csrf.php';

// Start secure session
startSecureSession();

// Redirect if already logged in
if (isLoggedIn()) {
    header('Location: /dashboard.php');
    exit;
}

// Handle login form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate CSRF token
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request. Please try again.';
    } else {
        // Get form data
        $email = $_POST['email'] ?? '';
        $password = $_POST['password'] ?? '';
        
        // Validate input
        if (empty($email) || empty($password)) {
            $error = 'Email and password are required';
        } else {
            // Initialize database connection
            $database = new Database();
            $db = $database->getConnection();
            
            // Get user by email
            $user = new User($db);
            $userData = $user->getUserByEmail($email);
            
            if ($userData && password_verify($password, $userData['password_hash'])) {
                // Login successful
                $_SESSION['user_id'] = $userData['id'];
                $_SESSION['user_email'] = $userData['email'];
                $_SESSION['user_role'] = 'user'; // Set role based on your logic
                $_SESSION['logged_in'] = true;
                $_SESSION['login_time'] = time();
                $_SESSION['last_activity'] = time();
                
                // Log the login
                Logger::info('User login successful', ['user_id' => $userData['id'], 'email' => $email]);
                
                // Redirect to dashboard
                header('Location: /dashboard.php');
                exit;
            } else {
                $error = 'Invalid email or password';
                Logger::warning('Failed login attempt', ['email' => $email]);
            }
        }
    }
}

// Generate CSRF token for form
$csrfToken = generateCSRFToken();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Chapa Banking</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card mt-5">
                    <div class="card-header">
                        <h3 class="text-center">Login to Chapa Banking</h3>
                    </div>
                    <div class="card-body">
                        <?php if (isset($error)): ?>
                            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
                        <?php endif; ?>
                        
                        <form method="POST">
                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
                            
                            <div class="mb-3">
                                <label for="email" class="form-label">Email address</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="password" class="form-label">Password</label>
                                <input type="password" class="form-control" id="password" name="password" required>
                            </div>
                            
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary">Login</button>
                            </div>
                        </form>
                        
                        <div class="text-center mt-3">
                            <a href="/register.php">Don't have an account? Register</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
```

### Registration System (register.php)
```php
<?php
/**
 * User Registration System
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/models/User.php';
require_once __DIR__ . '/session_config.php';
require_once __DIR__ . '/security/csrf.php';

// Start secure session
startSecureSession();

// Redirect if already logged in
if (isLoggedIn()) {
    header('Location: /dashboard.php');
    exit;
}

// Handle registration form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate CSRF token
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request. Please try again.';
    } else {
        // Get form data
        $username = $_POST['username'] ?? '';
        $email = $_POST['email'] ?? '';
        $password = $_POST['password'] ?? '';
        $confirmPassword = $_POST['confirm_password'] ?? '';
        
        // Validate input
        if (empty($username) || empty($email) || empty($password) || empty($confirmPassword)) {
            $error = 'All fields are required';
        } elseif ($password !== $confirmPassword) {
            $error = 'Passwords do not match';
        } elseif (strlen($password) < 8) {
            $error = 'Password must be at least 8 characters long';
        } else {
            // Initialize database connection
            $database = new Database();
            $db = $database->getConnection();
            
            // Check if user already exists
            $user = new User($db);
            $existingUser = $user->getUserByEmail($email);
            
            if ($existingUser) {
                $error = 'Email already registered';
            } else {
                // Hash password
                $passwordHash = password_hash($password, PASSWORD_DEFAULT);
                
                // Create user in database
                $query = "INSERT INTO users (username, email, password_hash) VALUES (:username, :email, :password_hash)";
                $stmt = $db->prepare($query);
                $stmt->bindParam(':username', $username);
                $stmt->bindParam(':email', $email);
                $stmt->bindParam(':password_hash', $passwordHash);
                
                if ($stmt->execute()) {
                    // Registration successful
                    $userId = $db->lastInsertId();
                    
                    // Log the registration
                    Logger::info('User registration successful', ['user_id' => $userId, 'email' => $email]);
                    
                    // Auto-login the user
                    $_SESSION['user_id'] = $userId;
                    $_SESSION['user_email'] = $email;
                    $_SESSION['user_role'] = 'user';
                    $_SESSION['logged_in'] = true;
                    $_SESSION['login_time'] = time();
                    $_SESSION['last_activity'] = time();
                    
                    // Redirect to dashboard
                    header('Location: /dashboard.php');
                    exit;
                } else {
                    $error = 'Registration failed. Please try again.';
                    Logger::error('User registration failed', ['email' => $email]);
                }
            }
        }
    }
}

// Generate CSRF token for form
$csrfToken = generateCSRFToken();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Chapa Banking</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card mt-5">
                    <div class="card-header">
                        <h3 class="text-center">Register for Chapa Banking</h3>
                    </div>
                    <div class="card-body">
                        <?php if (isset($error)): ?>
                            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
                        <?php endif; ?>
                        
                        <form method="POST">
                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
                            
                            <div class="mb-3">
                                <label for="username" class="form-label">Username</label>
                                <input type="text" class="form-control" id="username" name="username" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="email" class="form-label">Email address</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="password" class="form-label">Password</label>
                                <input type="password" class="form-control" id="password" name="password" required>
                                <div class="form-text">Password must be at least 8 characters long</div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="confirm_password" class="form-label">Confirm Password</label>
                                <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                            </div>
                            
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary">Register</button>
                            </div>
                        </form>
                        
                        <div class="text-center mt-3">
                            <a href="/login.php">Already have an account? Login</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
```

### Logout System (logout.php)
```php
<?php
/**
 * User Logout System
 */

require_once __DIR__ . '/session_config.php';
require_once __DIR__ . '/config.php';

// Start session
startSecureSession();

// Log the logout
if (isset($_SESSION['user_id'])) {
    Logger::info('User logout', ['user_id' => $_SESSION['user_id']]);
}

// Destroy session
destroySession();

// Redirect to login page
header('Location: /login.php?logged_out=1');
exit;
?>
```

### Session Middleware (middleware/auth.php)
```php
<?php
/**
 * Authentication Middleware
 * Include this at the top of protected pages
 */

require_once __DIR__ . '/../session_config.php';
require_once __DIR__ . '/../config.php';

// Start secure session
startSecureSession();

// Check authentication
if (!isLoggedIn()) {
    // Redirect to login page
    header('Location: /login.php');
    exit;
}

// Check for session timeout
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > 1800)) {
    // Last activity was more than 30 minutes ago
    destroySession();
    header('Location: /login.php?timeout=1');
    exit;
}

// Update last activity timestamp
$_SESSION['last_activity'] = time();

// Get current user information
$currentUserId = getCurrentUserId();
$currentUserRole = getCurrentUserRole();
?>
```

### Admin Middleware (middleware/admin.php)
```php
<?php
/**
 * Admin Authentication Middleware
 * Include this at the top of admin-only pages
 */

require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/../config.php';

// Check if user is admin
if ($currentUserRole !== 'admin') {
    // Log unauthorized access attempt
    Logger::warning('Unauthorized admin access attempt', [
        'user_id' => $currentUserId,
        'requested_page' => $_SERVER['REQUEST_URI']
    ]);
    
    // Redirect to unauthorized page
    header('Location: /unauthorized.php');
    exit;
}
?>
```

## Frontend Session Management

### JavaScript Session Handling
```javascript
// Session management functions
class SessionManager {
    constructor() {
        this.checkInterval = setInterval(() => this.checkSession(), 60000); // Check every minute
        this.warningShown = false;
    }
    
    // Check session status
    async checkSession() {
        try {
            const response = await fetch('/api/session-status.php', {
                method: 'GET',
                credentials: 'same-origin'
            });
            
            const result = await response.json();
            
            if (!result.authenticated) {
                // Session expired, redirect to login
                this.handleSessionExpired();
            } else if (result.expires_in < 300) { // Less than 5 minutes
                // Show warning about session expiration
                if (!this.warningShown) {
                    this.showSessionWarning(result.expires_in);
                    this.warningShown = true;
                }
            } else {
                this.warningShown = false;
            }
        } catch (error) {
            console.error('Session check failed:', error);
        }
    }
    
    // Handle session expiration
    handleSessionExpired() {
        // Show modal or notification
        if (confirm('Your session has expired. Please log in again.')) {
            window.location.href = '/login.php?timeout=1';
        }
    }
    
    // Show session expiration warning
    showSessionWarning(secondsRemaining) {
        const minutes = Math.floor(secondsRemaining / 60);
        showToast(`Your session will expire in ${minutes} minutes. Please save your work.`, 'warning');
    }
    
    // Extend session
    async extendSession() {
        try {
            const response = await fetch('/api/extend-session.php', {
                method: 'POST',
                credentials: 'same-origin'
            });
            
            const result = await response.json();
            
            if (result.success) {
                console.log('Session extended successfully');
                this.warningShown = false;
            } else {
                console.error('Failed to extend session:', result.error);
            }
        } catch (error) {
            console.error('Session extension failed:', error);
        }
    }
}

// Initialize session manager
const sessionManager = new SessionManager();

// Extend session on user activity
document.addEventListener('click', () => {
    sessionManager.extendSession();
});

document.addEventListener('keypress', () => {
    sessionManager.extendSession();
});
```

### Session Status API (api/session-status.php)
```php
<?php
/**
 * Session Status API
 * Returns current session status
 */

require_once __DIR__ . '/../session_config.php';
require_once __DIR__ . '/../config.php';

// Start session
startSecureSession();

header('Content-Type: application/json');

if (isLoggedIn()) {
    $loginTime = $_SESSION['login_time'] ?? time();
    $lastActivity = $_SESSION['last_activity'] ?? time();
    $sessionTimeout = 1800; // 30 minutes
    $timeRemaining = $sessionTimeout - (time() - $lastActivity);
    
    echo json_encode([
        'authenticated' => true,
        'user_id' => $_SESSION['user_id'],
        'expires_in' => max(0, $timeRemaining),
        'login_time' => $loginTime,
        'last_activity' => $lastActivity
    ]);
} else {
    echo json_encode([
        'authenticated' => false
    ]);
}
?>
```

### Extend Session API (api/extend-session.php)
```php
<?php
/**
 * Extend Session API
 * Extends the current session
 */

require_once __DIR__ . '/../session_config.php';
require_once __DIR__ . '/../config.php';

// Start session
startSecureSession();

header('Content-Type: application/json');

if (isLoggedIn()) {
    // Update last activity timestamp
    $_SESSION['last_activity'] = time();
    
    echo json_encode([
        'success' => true,
        'message' => 'Session extended'
    ]);
} else {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'error' => 'Not authenticated'
    ]);
}
?>
```

## Security Considerations

### Session Security Best Practices

1. **Secure Session Configuration**:
   - HTTP-only cookies
   - Secure cookies (HTTPS only)
   - SameSite attribute
   - Strict mode

2. **Session Regeneration**:
   - Regenerate session ID after login
   - Regenerate periodically during long sessions
   - Regenerate after privilege changes

3. **Session Timeout**:
   - Implement both idle timeout (30 minutes)
   - Implement absolute timeout (8 hours)
   - Warn users before timeout

4. **Session Storage**:
   - Store sessions in secure location
   - Use database storage for production
   - Encrypt sensitive session data

5. **Concurrent Session Management**:
   - Limit concurrent sessions per user
   - Allow users to view active sessions
   - Allow session termination

### Database Session Storage (models/Session.php)
```php
<?php
/**
 * Database Session Storage
 * Store sessions in database for better security
 */

class Session {
    private $db;
    
    public function __construct($db) {
        $this->db = $db;
    }
    
    // Read session data
    public function read($sessionId) {
        $query = "SELECT data FROM sessions WHERE session_id = :session_id AND expires_at > NOW()";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':session_id', $sessionId);
        $stmt->execute();
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result ? $result['data'] : '';
    }
    
    // Write session data
    public function write($sessionId, $data) {
        $query = "INSERT INTO sessions (session_id, data, expires_at) 
                  VALUES (:session_id, :data, DATE_ADD(NOW(), INTERVAL 30 MINUTE))
                  ON DUPLICATE KEY UPDATE 
                  data = :data, 
                  expires_at = DATE_ADD(NOW(), INTERVAL 30 MINUTE)";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':session_id', $sessionId);
        $stmt->bindParam(':data', $data);
        return $stmt->execute();
    }
    
    // Destroy session
    public function destroy($sessionId) {
        $query = "DELETE FROM sessions WHERE session_id = :session_id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':session_id', $sessionId);
        return $stmt->execute();
    }
    
    // Garbage collection
    public function gc($maxlifetime) {
        $query = "DELETE FROM sessions WHERE expires_at < NOW()";
        $stmt = $this->db->prepare($query);
        return $stmt->execute();
    }
}

// Register session handler
// session_set_save_handler(new Session($db), true);
?>
```

## Summary

This session management system provides:

1. **Secure Session Configuration**:
   - HTTP-only, secure cookies
   - SameSite protection
   - Session regeneration

2. **Complete Authentication Flow**:
   - User registration
   - User login/logout
   - Password hashing
   - Session validation

3. **Role-Based Access Control**:
   - User roles (user/admin)
   - Middleware for protected pages
   - Admin-only access control

4. **Frontend Session Management**:
   - Session status checking
   - Automatic session extension
   - Expiration warnings

5. **Security Features**:
   - Session timeout enforcement
   - Activity tracking
   - Secure session storage options

6. **Database Integration**:
   - Database session storage option
   - Session cleanup mechanisms