# Database Implementation Plan

## Database Connection Script

Create a `db.php` file to handle database connections:

```php
<?php
// db.php - Database connection script

class Database {
    private $host = 'localhost';
    private $db_name = 'chapa_banking';
    private $username = 'root';
    private $password = '';
    private $conn;

    public function getConnection() {
        $this->conn = null;
        
        try {
            $this->conn = new PDO(
                "mysql:host=" . $this->host . ";dbname=" . $this->db_name,
                $this->username,
                $this->password
            );
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch(PDOException $exception) {
            echo "Connection error: " . $exception->getMessage();
        }
        
        return $this->conn;
    }
}
?>
```

## Database Setup Script

Create a `setup.sql` file with the database schema:

```sql
-- setup.sql - Database setup script

-- Create database
CREATE DATABASE IF NOT EXISTS chapa_banking;
USE chapa_banking;

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    balance DECIMAL(10, 2) DEFAULT 0.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Transactions table
CREATE TABLE IF NOT EXISTS transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    transaction_type ENUM('deposit', 'withdrawal') NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    status ENUM('pending', 'completed', 'failed', 'cancelled') DEFAULT 'pending',
    tx_ref VARCHAR(100) UNIQUE,
    chapa_tx_ref VARCHAR(100),
    payment_method VARCHAR(50),
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Withdrawal requests table
CREATE TABLE IF NOT EXISTS withdrawal_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    payment_method VARCHAR(50),
    account_details TEXT,
    admin_notes TEXT,
    requested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    processed_at TIMESTAMP NULL,
    processed_by INT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (processed_by) REFERENCES users(id)
);

-- Insert sample data for testing
INSERT INTO users (username, email, password_hash, balance) VALUES 
('testuser', 'test@example.com', '$2y$10$example_hash', 1000.00),
('admin', 'admin@example.com', '$2y$10$admin_hash', 5000.00);
```

## Database Models

### User Model (user.php)
```php
<?php
class User {
    private $conn;
    private $table_name = "users";
    
    public $id;
    public $username;
    public $email;
    public $password_hash;
    public $balance;
    public $created_at;
    public $updated_at;
    
    public function __construct($db) {
        $this->conn = $db;
    }
    
    // Get user by ID
    public function getUserById($id) {
        $query = "SELECT * FROM " . $this->table_name . " WHERE id = :id LIMIT 1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    // Get user by email
    public function getUserByEmail($email) {
        $query = "SELECT * FROM " . $this->table_name . " WHERE email = :email LIMIT 1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':email', $email);
        $stmt->execute();
        
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    // Update user balance
    public function updateBalance($user_id, $amount, $operation = 'add') {
        if ($operation === 'add') {
            $query = "UPDATE " . $this->table_name . " SET balance = balance + :amount WHERE id = :user_id";
        } else {
            $query = "UPDATE " . $this->table_name . " SET balance = balance - :amount WHERE id = :user_id";
        }
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':amount', $amount);
        $stmt->bindParam(':user_id', $user_id);
        
        return $stmt->execute();
    }
}
?>
```

### Transaction Model (transaction.php)
```php
<?php
class Transaction {
    private $conn;
    private $table_name = "transactions";
    
    public $id;
    public $user_id;
    public $transaction_type;
    public $amount;
    public $status;
    public $tx_ref;
    public $chapa_tx_ref;
    public $payment_method;
    public $description;
    public $created_at;
    public $updated_at;
    
    public function __construct($db) {
        $this->conn = $db;
    }
    
    // Create a new transaction
    public function createTransaction($user_id, $type, $amount, $tx_ref, $chapa_tx_ref = null, $payment_method = null, $description = null) {
        $query = "INSERT INTO " . $this->table_name . " 
                  (user_id, transaction_type, amount, tx_ref, chapa_tx_ref, payment_method, description, status) 
                  VALUES (:user_id, :transaction_type, :amount, :tx_ref, :chapa_tx_ref, :payment_method, :description, 'pending')";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->bindParam(':transaction_type', $type);
        $stmt->bindParam(':amount', $amount);
        $stmt->bindParam(':tx_ref', $tx_ref);
        $stmt->bindParam(':chapa_tx_ref', $chapa_tx_ref);
        $stmt->bindParam(':payment_method', $payment_method);
        $stmt->bindParam(':description', $description);
        
        return $stmt->execute();
    }
    
    // Update transaction status
    public function updateStatus($tx_ref, $status) {
        $query = "UPDATE " . $this->table_name . " SET status = :status, updated_at = CURRENT_TIMESTAMP WHERE tx_ref = :tx_ref";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':status', $status);
        $stmt->bindParam(':tx_ref', $tx_ref);
        
        return $stmt->execute();
    }
    
    // Get transaction by reference
    public function getTransactionByRef($tx_ref) {
        $query = "SELECT * FROM " . $this->table_name . " WHERE tx_ref = :tx_ref LIMIT 1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':tx_ref', $tx_ref);
        $stmt->execute();
        
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    // Get user transactions
    public function getUserTransactions($user_id, $limit = 10) {
        $query = "SELECT * FROM " . $this->table_name . " 
                  WHERE user_id = :user_id 
                  ORDER BY created_at DESC 
                  LIMIT :limit";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>
```

### Withdrawal Request Model (withdrawal_request.php)
```php
<?php
class WithdrawalRequest {
    private $conn;
    private $table_name = "withdrawal_requests";
    
    public $id;
    public $user_id;
    public $amount;
    public $status;
    public $payment_method;
    public $account_details;
    public $admin_notes;
    public $requested_at;
    public $processed_at;
    public $processed_by;
    
    public function __construct($db) {
        $this->conn = $db;
    }
    
    // Create a new withdrawal request
    public function createRequest($user_id, $amount, $payment_method, $account_details) {
        $query = "INSERT INTO " . $this->table_name . " 
                  (user_id, amount, payment_method, account_details) 
                  VALUES (:user_id, :amount, :payment_method, :account_details)";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->bindParam(':amount', $amount);
        $stmt->bindParam(':payment_method', $payment_method);
        $stmt->bindParam(':account_details', $account_details);
        
        return $stmt->execute();
    }
    
    // Get withdrawal request by ID
    public function getRequestById($id) {
        $query = "SELECT * FROM " . $this->table_name . " WHERE id = :id LIMIT 1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    // Get all withdrawal requests with optional filters
    public function getAllRequests($status = null, $limit = 50) {
        $query = "SELECT wr.*, u.username, u.email FROM " . $this->table_name . " wr 
                  JOIN users u ON wr.user_id = u.id";
        
        $params = [];
        if ($status) {
            $query .= " WHERE wr.status = :status";
            $params[':status'] = $status;
        }
        
        $query .= " ORDER BY wr.requested_at DESC LIMIT :limit";
        
        $stmt = $this->conn->prepare($query);
        
        foreach ($params as $key => $value) {
            $stmt->bindParam($key, $value);
        }
        
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // Update request status
    public function updateStatus($id, $status, $admin_id = null, $admin_notes = null) {
        $query = "UPDATE " . $this->table_name . " 
                  SET status = :status, processed_at = CURRENT_TIMESTAMP";
        
        $params = [':status' => $status, ':id' => $id];
        
        if ($admin_id) {
            $query .= ", processed_by = :admin_id";
            $params[':admin_id'] = $admin_id;
        }
        
        if ($admin_notes) {
            $query .= ", admin_notes = :admin_notes";
            $params[':admin_notes'] = $admin_notes;
        }
        
        $query .= " WHERE id = :id";
        
        $stmt = $this->conn->prepare($query);
        
        foreach ($params as $key => $value) {
            $stmt->bindParam($key, $value);
        }
        
        return $stmt->execute();
    }
}
?>