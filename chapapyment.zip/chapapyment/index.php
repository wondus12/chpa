<?php
// Main entry point for the banking app
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chapa Banking App - PHP Version</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f5f5f5;
        }
        
        .welcome-container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
        }
        
        .app-links {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin: 30px 0;
        }
        
        .app-link {
            background: #007bff;
            color: white;
            text-decoration: none;
            padding: 20px;
            border-radius: 8px;
            transition: background-color 0.3s;
        }
        
        .app-link:hover {
            background: #0056b3;
            color: white;
            text-decoration: none;
        }
        
        .status-info {
            background: #e9ecef;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
        }
        
        .status-good {
            color: #28a745;
        }
        
        .status-warning {
            color: #ffc107;
        }
    </style>
</head>
<body>
    <div class="welcome-container">
        <h1>🏦 Chapa Banking App</h1>
        <p>PHP-powered banking application with Chapa payment integration</p>
        
        <div class="status-info">
            <h3>System Status</h3>
            <div class="status-good">✅ PHP Server: Running on <?php echo $_SERVER['HTTP_HOST']; ?></div>
            <div class="status-good">✅ Chapa Integration: Ready</div>
            <div class="status-good">✅ Test Mode: Enabled</div>
        </div>
        
        <div class="app-links">
            <a href="chapa-integrated-banking-app.html" class="app-link">
                <h3>🏦 Banking App</h3>
                <p>Main application with deposit/withdraw functionality</p>
            </a>
            
            <a href="test-cases.html" class="app-link">
                <h3>🧪 Test Suite</h3>
                <p>Comprehensive testing interface</p>
            </a>
            
            <a href="api/status.php" class="app-link">
                <h3>📊 API Status</h3>
                <p>Check backend API endpoints</p>
            </a>
            
            <a href="server-verification-setup.md" class="app-link">
                <h3>📖 Documentation</h3>
                <p>Setup and integration guide</p>
            </a>
        </div>
        
        <div class="status-info">
            <h3>Quick Test</h3>
            <p>Try depositing <strong>100 ETB</strong> or withdrawing <strong>500 ETB</strong></p>
            <p>All transactions are in test mode - no real money involved!</p>
        </div>
    </div>
</body>
</html>